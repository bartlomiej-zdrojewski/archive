// Define this file
#ifndef PROGRAM_FUNCTIONS
#define PROGRAM_FUNCTIONS

// Include static librares and definitions
#include "Main.hpp"

// Define functions
string IntToString ( float Number );
string FloatToString ( float Number );
string YearsToString ( float Years );
void Log ( string Information );
void Log ( string SimpleInformation, string Information );
void CreateLog ( );
sf::Color GetTemperatureColor ( float Temperature );
sf::Color GetSpeedColor ( float Temperature );
void AddParticle ( float x, float y, float vx, float vy, float Mass, float Density, float Temperature, float MeltingTemperature, float EvaporationTemperature, float SpecificHeat, float MeltingHeat, float EvaporationHeat );
float SynthesizingSpheresRadius ( float Mass1, float Mass2, float Density1, float Density2 );
float SynthesizingSpheresDensity ( float Mass1, float Mass2, float Density1, float Density2 );
void AnalyzeCollisions ( );

// End of definition
#endif