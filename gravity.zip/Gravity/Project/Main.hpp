// Define this file
#ifndef PROGRAM_MAIN
#define PROGRAM_MAIN

// Include static librares and definitions
#include "Headers.hpp"

// Include classes
#include "Dialog.hpp"

// Include global values
#include "Values.hpp"

// Include functions
#include "Functions.hpp"

// End of definition
#endif