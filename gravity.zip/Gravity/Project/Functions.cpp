// Include static librares and definitions
#include "Main.hpp"

string IntToString ( float Number ) {

	stringstream ss;
	string Text;

	Number = floor ( Number * 10 ) / 10;

	ss << fixed << setprecision(0) << Number;
	ss >> Text;
	
	return Text; }

string FloatToString ( float Number ) {

	stringstream ss;
	string Text;

	Number = floor ( Number * 1000 ) / 1000;

	ss << fixed << setprecision(2) << Number;
	ss >> Text;

	return Text; }

string YearsToString ( float Years ) {

	stringstream ss;
	string Text;

	Years = floor ( Years * 100000 ) / 100000;

	ss << fixed << setprecision(4) << Years;
	ss >> Text;

	return Text; }

void Log ( string Information ) {
	
	string LogInformation;
	ofstream LogFile;

	/*
	int Seconds = (int) ApplicationTime.getElapsedTime().asSeconds() % 60;
	int Minutes = (int) ( ( ApplicationTime.getElapsedTime().asSeconds() - Seconds ) / 60 ) % 60;

	if ( Minutes < 10 && Seconds < 10 ) { LogInformation = "[0" + IntToString ( Minutes ) + ":0" + IntToString ( Seconds ) + "] " + Information + "\n"; }
	if ( Minutes < 10 && Seconds >= 10 ) { LogInformation = "[0" + IntToString ( Minutes ) + ":" + IntToString ( Seconds ) + "] " + Information + "\n"; }
	if ( Minutes >= 10 && Seconds < 10 ) { LogInformation = "[" + IntToString ( Minutes ) + ":0" + IntToString ( Seconds ) + "] " + Information + "\n"; }
	*/
	
	LogInformation = "[" + YearsToString ( Time / 1000 ) + "] " + Information + "\n";

	LogFile.open ( LogsDirectory + "\\Gravity.log", ios::app );
	LogFile << LogInformation;
	LogFile.close(); }

void CreateLog ( ) {

	int LogSerialCode = 1;
	string LogName = LogsDirectory + "\\Gravity #";

	while ( LogName == LogsDirectory + "\\Gravity #" ) {

		ifstream CheckFile( LogsDirectory + "\\Gravity #" + IntToString(LogSerialCode) + ".log" );
		
		if ( !CheckFile ) { LogName = LogsDirectory + "\\Gravity #" + IntToString(LogSerialCode) + ".log"; }
		
		LogSerialCode++; }

	CopyFile ( ( LogsDirectory + "\\Gravity.log" ).c_str(), LogName.c_str(), false ); }

sf::Color GetTemperatureColor ( float Temperature ) {

	int Spectrum = floor ( Temperature / ( 10 / 1.023 ) );
	sf::Color Color;

	if ( Spectrum <= 255 ) { int PartSpectrum = Spectrum % 256; Color = sf::Color( 0, PartSpectrum, 255 ); }
	if ( Spectrum > 255 && Spectrum <= 511 ) { int PartSpectrum = Spectrum % 256; Color = sf::Color( 0, 255, 255 - PartSpectrum ); }
	if ( Spectrum > 511 && Spectrum <= 767 ) { int PartSpectrum = Spectrum % 256; Color = sf::Color( PartSpectrum, 255, 0 ); }
	if ( Spectrum > 767 && Spectrum <= 1023 ) { int PartSpectrum = Spectrum % 256; Color = sf::Color( 255, 255 - PartSpectrum, 0 ); }
	if ( Spectrum > 1023 ) { Color = sf::Color( 255, 0, 0 ); }

	return Color; }

sf::Color GetSpeedColor ( float Temperature ) {

	int Spectrum = floor ( Temperature / ( 10 / 1.023 ) );
	sf::Color Color;

	if ( Spectrum <= 255 ) { int PartSpectrum = Spectrum % 256; Color = sf::Color( 0, PartSpectrum, 255 ); }
	if ( Spectrum > 255 && Spectrum <= 511 ) { int PartSpectrum = Spectrum % 256; Color = sf::Color( 0, 255, 255 - PartSpectrum ); }
	if ( Spectrum > 511 && Spectrum <= 767 ) { int PartSpectrum = Spectrum % 256; Color = sf::Color( PartSpectrum, 255, 0 ); }
	if ( Spectrum > 767 && Spectrum <= 1023 ) { int PartSpectrum = Spectrum % 256; Color = sf::Color( 255, 255 - PartSpectrum, 0 ); }
	if ( Spectrum > 1023 ) { Color = sf::Color( 255, 0, 0 ); }

	return Color; }

void AddParticle ( float x, float y, float vx, float vy, float Mass, float Density, float Temperature, float MeltingTemperature, float EvaporationTemperature, float SpecificHeat, float MeltingHeat, float EvaporationHeat ) {
	
	Particle NewParticle;
	ParticleSerialCode++;

	NewParticle.Name = "Particle #" + IntToString(ParticleSerialCode);
	NewParticle.x = x;
	NewParticle.y = y;
	NewParticle.vx = vx;
	NewParticle.vy = vy;
	NewParticle.Radius = pow( (float) ( ( Mass / Density ) / ( 4 / 3 * PI ) ), (float) ( 1 / 3.0 ) );
	NewParticle.Mass = Mass;
	NewParticle.Density = Density;
	NewParticle.Temperature = Temperature;
	NewParticle.MeltingTemperature = MeltingTemperature;
	NewParticle.EvaporationTemperature = EvaporationTemperature;
	NewParticle.SpecificHeat = SpecificHeat;
	NewParticle.MeltingHeat = MeltingHeat;
	NewParticle.EvaporationHeat = EvaporationHeat;
	NewParticle.PhaseEnergy = 0;
	NewParticle.Destroyed = false;
	NewParticle.Color = GetTemperatureColor(Temperature);
	NewParticle.Orbit.push_back(sf::Vertex(sf::Vector2f(NewParticle.x,NewParticle.y),GetTemperatureColor(NewParticle.Temperature)));

	if ( NewParticle.Temperature < NewParticle.MeltingTemperature ) { NewParticle.Phase = SOLID; }
	if ( NewParticle.Temperature >= NewParticle.MeltingTemperature && NewParticle.Temperature < NewParticle.EvaporationHeat ) { NewParticle.Phase = LIQUID; }
	if ( NewParticle.Temperature >= NewParticle.EvaporationHeat ) { NewParticle.Phase = GAS; }

	Track NewTrack;
	NewTrack.x = 0;
	NewTrack.y = 0;
	
	Particles.push_back(NewParticle);
	Tracks.push_back(NewTrack);
	
	float Speed = sqrt ( pow ( Particles[Particles.size()-1].vx, 2 ) + pow ( Particles[Particles.size()-1].vy, 2 ) );
	float Volume = Particles[Particles.size()-1].Mass / Particles[Particles.size()-1].Density;
	
	Log("Created "+NewParticle.Name+" ( M: "+FloatToString(Particles[Particles.size()-1].Mass)+" kg, D: "+FloatToString(Particles[Particles.size()-1].Density)+" kg/m3, V: "+FloatToString(Volume)+" m3, R: "+FloatToString(Particles[Particles.size()-1].Radius)+" m, Vt: "+FloatToString(Speed)+" m/s, Vx: "+FloatToString(Particles[Particles.size()-1].vx)+" m/s, Vy: "+FloatToString(Particles[Particles.size()-1].vy)+" m/s, T: "+FloatToString(Particles[Particles.size()-1].Temperature)+" K, C: "+FloatToString(Particles[Particles.size()-1].SpecificHeat)+" J/KgK )."); }

float SynthesizingSpheresRadius ( float Mass1, float Mass2, float Density1, float Density2 ) {

	return pow ( (float) ( ( Mass1 / Density1 + Mass2 / Density2 ) / ( 4 / 3 * PI ) ), (float) ( 1 / 3.0 ) ); }

float SynthesizingSpheresDensity ( float Mass1, float Mass2, float Density1, float Density2 ) {
	
	return ( Mass1 + Mass2 ) / ( Mass1 / Density1 + Mass2 / Density2 ); }

void AnalyzeCollisions ( ) {

	for ( int i = 0; i < Collisions.size(); i++ ) {

		Particle * P1;
		Particle * P2;

		int DestroyedFocus;
		int NotDestroyedFocus;

		if ( Particles[Collisions[i].FirstIterator].Mass >= Particles[Collisions[i].SecondIterator].Mass ) {

			P1 = &Particles[Collisions[i].FirstIterator];
			P2 = &Particles[Collisions[i].SecondIterator];
			
			DestroyedFocus = Collisions[i].SecondIterator;
			NotDestroyedFocus = Collisions[i].FirstIterator; }

		if ( Particles[Collisions[i].FirstIterator].Mass < Particles[Collisions[i].SecondIterator].Mass ) {

			P1 = &Particles[Collisions[i].SecondIterator];
			P2 = &Particles[Collisions[i].FirstIterator];
			
			DestroyedFocus = Collisions[i].FirstIterator;
			NotDestroyedFocus = Collisions[i].SecondIterator; }

		if ( P1->Destroyed == false && P2->Destroyed == false ) { 

			float CollisionEnergy = 0.5 * ( ( P1->Mass * P2->Mass ) / ( P1->Mass + P2->Mass ) ) * pow ( abs ( sqrt ( pow ( P1->vx, 2 ) + pow ( P1->vy, 2 ) ) - sqrt ( pow ( P2->vx, 2 ) + pow ( P2->vy, 2 ) ) ), 2 );
			
			float P1_Speed = sqrt ( pow ( P1->vx, 2 ) + pow ( P1->vy, 2 ) ), P1_SpeedX = P1->vx, P1_SpeedY = P1->vy, P1_Density = P1->Density, P1_Volume = P1->Mass / P1->Density, P1_Radius = P1->Radius, P1_Temperature = P1->Temperature, P1_SpecificHeat = P1->SpecificHeat;
			float P2_Speed = sqrt ( pow ( P2->vx, 2 ) + pow ( P2->vy, 2 ) ), P2_Volume = P2->Mass / P2->Density;

			P1->vx = ( P1->vx * P1->Mass + P2->vx * P2->Mass ) / ( P1->Mass + P2->Mass );
			P1->vy = ( P1->vy * P1->Mass + P2->vy * P2->Mass ) / ( P1->Mass + P2->Mass );

			P1->Temperature = ( P1->Temperature * P1->Mass + P2->Temperature * P2->Mass ) / ( P1->Mass + P2->Mass ) + CollisionEnergy / ( P1->Mass * P1->SpecificHeat );
			P1->MeltingTemperature = ( P1->MeltingTemperature * P1->Mass + P2->MeltingTemperature * P2->Mass ) / ( P1->Mass + P2->Mass );
			P1->EvaporationTemperature = ( P1->EvaporationTemperature * P1->Mass + P2->EvaporationTemperature * P2->Mass ) / ( P1->Mass + P2->Mass );
			P1->SpecificHeat = ( P1->SpecificHeat * P1->Mass + P2->SpecificHeat * P2->Mass ) / ( P1->Mass + P2->Mass );
			P1->MeltingHeat = ( P1->MeltingHeat * P1->Mass + P2->MeltingHeat * P2->Mass ) / ( ( P1->Mass + P2->Mass ) / 1000 );
			P1->EvaporationHeat = ( P1->EvaporationHeat * P1->Mass + P2->EvaporationHeat * P2->Mass ) / ( ( P1->Mass + P2->Mass ) / 1000 );
			P1->Color = GetTemperatureColor(P1->Temperature);

			//if ( 

			if ( P1->Temperature < P1->MeltingTemperature ) { P1->Phase = SOLID; }
			if ( P1->Temperature >= P1->MeltingTemperature && P1->Temperature < P1->EvaporationHeat ) { P1->Phase = LIQUID; }
			if ( P1->Temperature >= P1->EvaporationHeat ) { P1->Phase = GAS; }

			P1->Radius = SynthesizingSpheresRadius( P1->Mass, P2->Mass, P1->Density, P2->Density );
			P1->Density = SynthesizingSpheresDensity( P1->Mass, P2->Mass, P1->Density, P2->Density );
			P1->Mass += P2->Mass;

			P2->Destroyed = true;
			if ( Focus == DestroyedFocus ) { Focus = NotDestroyedFocus; }
			
			float Speed = sqrt ( pow ( P1->vx, 2 ) + pow ( P1->vy, 2 ) ), Volume = P1->Mass / P1->Density;
			Log(P2->Name+" crashed into "+P1->Name+" ( [ M: "+FloatToString(P2->Mass)+" kg, D: "+FloatToString(P2->Density)+" kg/m3, V: "+FloatToString(P2_Volume)+" m3, R: "+FloatToString(P2->Radius)+" m, Vt: "+FloatToString(P2_Speed)+" m/s, Vx: "+FloatToString(P2->vx)+" m/s, Vy: "+FloatToString(P2->vy)+" m/s, T: "+FloatToString(P2->Temperature)+" K, C: "+FloatToString(P2->SpecificHeat)+" J/KgK ] crashed into [ M: "+FloatToString(P1->Mass-P2->Mass)+" kg, D: "+FloatToString(P1_Density)+" kg/m3, V: "+FloatToString(P1_Volume)+" m3, R: "+FloatToString(P1_Radius)+" m, Vt: "+FloatToString(P1_Speed)+" m/s, Vx: "+FloatToString(P1_SpeedX)+" m/s, Vy: "+FloatToString(P1_SpeedY)+" m/s, T: "+FloatToString(P1_Temperature)+" K, C: "+FloatToString(P1_SpecificHeat)+" J/KgK ] and changed it into [ M: "+FloatToString(P1->Mass)+" kg, D: "+FloatToString(P1->Density)+" kg/m3, V: "+FloatToString(Volume)+" m3, R: "+FloatToString(P1->Radius)+" m, Vt: "+FloatToString(Speed)+" m/s, Vx: "+FloatToString(P1->vx)+" m/s, Vy: "+FloatToString(P1->vy)+" m/s, T: "+FloatToString(P1->Temperature)+" K, C: "+FloatToString(P1->SpecificHeat)+" J/KgK ] )."); }

		/*

		if ( P1.Mass < P2.Mass && P1.Destroyed == false && P2.Destroyed == false ) { 
			
			float P2_Speed = sqrt ( pow ( P2.vx, 2 ) + pow ( P2.vy, 2 ) ), P2_SpeedX = P2.vx, P2_SpeedY = P2.vy, P2_Density = P2.Density, P2_Volume = P2.Mass / P2.Density, P2_Radius = P2.Radius, P2_Temperature = P2.Temperature, P2_SpecificHeat = P2.SpecificHeat;
			float P1_Speed = sqrt ( pow ( P1.vx, 2 ) + pow ( P2.vy, 2 ) ), P1_Volume = P1.Mass / P1.Density;	
			
			P2.vx = ( P1.vx * P1.Mass + P2.vx * P2.Mass ) / ( P1.Mass + P2.Mass );
			P2.vy = ( P1.vy * P1.Mass + P2.vy * P2.Mass ) / ( P1.Mass + P2.Mass );

			P2.Temperature = ( P1.Temperature * P1.Mass + P2.Temperature * P2.Mass ) / ( P1.Mass + P2.Mass ) + CollisionEnergy / ( P2.Mass * P2.SpecificHeat );
			P2.SpecificHeat = ( P1.SpecificHeat * P1.Mass + P2.SpecificHeat * P2.Mass ) / ( P1.Mass + P2.Mass );
			P2.Color = GetTemperatureColor(P1.Temperature);
			
			if ( P2.Temperature < P2.MeltingTemperature ) { P2.Phase = SOLID; }
			if ( P2.Temperature >= P2.MeltingTemperature && P2.Temperature < P2.EvaporationHeat ) { P2.Phase = LIQUID; }
			if ( P2.Temperature >= P2.EvaporationHeat ) { P2.Phase = GAS; }

			P2.Radius = SynthesizingSpheresRadius( P1.Mass, P2.Mass, P1.Density, P2.Density );
			P2.Density = SynthesizingSpheresDensity( P1.Mass, P2.Mass, P1.Density, P2.Density );
			P2.Mass += P1.Mass;

			P1.Destroyed = true;
			if ( Focus == ( Collisions[i].FirstIterator + 1 ) ) { Focus = Collisions[i].SecondIterator + 1; }

			float Speed = sqrt ( pow ( P2.vx, 2 ) + pow ( P2.vy, 2 ) ), Volume = P2.Mass / P2.Density;
			Log(P1.Name+" crashed into "+P2.Name+" ( [ M: "+FloatToString(P1.Mass)+" kg, D: "+FloatToString(P1.Density)+" kg/m3, V: "+FloatToString(P1_Volume)+" m3, R: "+FloatToString(P1.Radius)+" m, V: "+FloatToString(P1_Speed)+" m/s, Vx: "+FloatToString(P1.vx)+" m/s, Vy: "+FloatToString(P1.vy)+" m/s, T: "+FloatToString(P1.Temperature)+" K, C: "+FloatToString(P1.SpecificHeat)+" J/KgK ] crashed into [ M: "+FloatToString(P2.Mass-P1.Mass)+" kg, D: "+FloatToString(P2_Density)+" kg/m3, V: "+FloatToString(P2_Volume)+" m3, R: "+FloatToString(P2_Radius)+" m, V: "+FloatToString(P2_Speed)+" m/s, Vx: "+FloatToString(P2_SpeedX)+" m/s, Vy: "+FloatToString(P2_SpeedY)+" m/s, T: "+FloatToString(P2_Temperature)+" K, C: "+FloatToString(P2_SpecificHeat)+" J/KgK ] and changed it into [ M: "+FloatToString(P2.Mass)+" kg, D: "+FloatToString(P2.Density)+" kg/m3, V: "+FloatToString(Volume)+" m3, R: "+FloatToString(P2.Radius)+" m, V: "+FloatToString(Speed)+" m/s, Vx: "+FloatToString(P2.vx)+" m/s, Vy: "+FloatToString(P2.vy)+" m/s, T: "+FloatToString(P2.Temperature)+" K, C: "+FloatToString(P2.SpecificHeat)+" J/KgK ] )."); } */ }

	Collisions.clear(); }