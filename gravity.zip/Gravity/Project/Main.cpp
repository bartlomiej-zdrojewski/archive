// Include static librares, definitions and extra code
#include "Main.hpp"

// Application
sf::Clock ApplicationTime;
sf::Clock ElapsedClock;
sf::Clock FPSClock;
sf::Font Font;

float FPS = 60;
float BeforeTime = 0;
float AfterTime = 0;

string ApplicationDirectory;
string LogsDirectory = "Logs";
bool Pause = false;

// Window
int WindowWidth = 800;
int WindowHeight = 600;

// Camera
Track CameraCenter;
int CameraUpdate = 0;
int Focus = -10;
float Area = 1;

// Keys
bool UP = false;
bool DOWN = false;
bool LEFT = false;
bool RIGHT = false;
bool FOCUS = false;
bool Q = false;
bool A = false;
bool Z = false;

// Interface
Vector VectorForce;
bool ShowTracks = false;
int TracksLength = 1000;

// Universe
float Gravity = 0.001;
float Time = 0;
float TimeAcceleration = 1;
float Precision = 0.01;

// Particles
int ParticleSerialCode = 0;
float ParticlesRadiusRatio = 1;

vector<Particle> Particles;
vector<Track> Tracks;
vector<Collision> Collisions;
vector<int> Destroyed;

// Particles properties
string Substance = "Water";
float Mass = 10000;
float Density = 916.70;
float Temperature = 2.73;
float MeltingTemperature = 273;
float EvaporationTemperature = 373;
float SpecificHeat = 2100;
float MeltingHeat = 334;
float EvaporationHeat = 2257;

// Application main function
int main ( ) {	
	
	// Get application directory
	char ApplicationPath[ MAX_PATH ];
    ::GetModuleFileNameA( NULL, ApplicationPath, MAX_PATH );

	char *ApplicationPathInfo;
	ApplicationPathInfo = ApplicationPath;
	PathRemoveFileSpec(ApplicationPathInfo);
	
	ApplicationDirectory = ApplicationPath;

	// Create logs directory
	if ( CreateDirectory( LogsDirectory.c_str(), NULL ) == 0 && GetLastError() != ERROR_ALREADY_EXISTS ) { LogsDirectory = "C:\\WINDOWS\\Temp"; }

	// Delete old temporary log file
	DeleteFile( ( LogsDirectory + "\\Gravity.log" ).c_str() );

	// Create new temporary log file
	Log("Start of the simulation.");

	// Load font
	if ( !Font.loadFromFile("Fonts\\Joystick.ttf") ) { MessageBox( NULL, "Failed to read \"Fonts\\Joystick.ttf\". Reinstall an application or report it on our website.", "Gravity - critical files error", MB_OK | MB_ICONERROR ); return 1; }

	// Load icon
	sf::Image Icon;
	if ( !Icon.loadFromFile("Graphics\\Icon.png") ) { MessageBox( NULL, "Failed to read \"Graphics\\Icon.png\". Reinstall an application or report it on our website.", "Gravity - critical files error", MB_OK | MB_ICONERROR ); return 1; }

	// Create window
	sf::RenderWindow Window( sf::VideoMode( WindowWidth, WindowHeight ), "Gravity" );
	Window.setIcon( 32, 32, Icon.getPixelsPtr() );
	Window.setActive();

	// Set window's propeties
	sf::ContextSettings Settings;
	Settings.antialiasingLevel = 8;

	// Set randomizer's seed
	srand( time( NULL ) );

	// Set camera's position
	CameraCenter.x = 0;
	CameraCenter.y = 0;

	// Create dialogs
	Dialog DialogCreatingPropeties ( Font );
	DialogCreatingPropeties.SetPosition( 20, 20 );
	DialogCreatingPropeties.AddInformation( 100, 10, 10, 255, 30, "Creation properties" );
	DialogCreatingPropeties.AddInformation( 25, 10, 50, 115, 20, "Substance:", DIALOG_LEFT );
	DialogCreatingPropeties.AddInput( 201, 135, 50, 130, 20, "Water", "", DIALOG_ASCII );
	DialogCreatingPropeties.AddInformation( 101, 10, 80, 115, 20, "Mass:", DIALOG_LEFT );
	DialogCreatingPropeties.AddInput( 202, 135, 80, 130, 20, FloatToString(Mass), " Kg", DIALOG_UNSIGNED_FLOAT );
	DialogCreatingPropeties.AddInformation( 103, 10, 110, 115, 20, "Density:", DIALOG_LEFT );
	DialogCreatingPropeties.AddInput( 203, 135, 110, 130, 20, FloatToString(Density), " Kg/m3", DIALOG_UNSIGNED_FLOAT );
	DialogCreatingPropeties.AddInformation( 105, 10, 140, 115, 20, "Temperature:", DIALOG_LEFT );
	DialogCreatingPropeties.AddInput( 204, 135, 140, 130, 20, FloatToString(Temperature), " K", DIALOG_SIGNED_FLOAT );
	DialogCreatingPropeties.AddInformation( 106, 10, 170, 115, 20, "Melting temp:", DIALOG_LEFT );
	DialogCreatingPropeties.AddInput( 205, 135, 170, 130, 20, FloatToString(MeltingTemperature), " K", DIALOG_SIGNED_FLOAT );
	DialogCreatingPropeties.AddInformation( 107, 10, 200, 115, 20, "Evaporation temp:", DIALOG_LEFT );
	DialogCreatingPropeties.AddInput( 206, 135, 200, 130, 20, FloatToString(EvaporationTemperature), " K", DIALOG_SIGNED_FLOAT );
	DialogCreatingPropeties.AddInformation( 108, 10, 230, 115, 20, "Specific heat:", DIALOG_LEFT );
	DialogCreatingPropeties.AddInput( 207, 135, 230, 130, 20, FloatToString(SpecificHeat), " J/KgK", DIALOG_UNSIGNED_FLOAT );
	DialogCreatingPropeties.AddInformation( 109, 10, 260, 115, 20, "Melting heat:", DIALOG_LEFT );
	DialogCreatingPropeties.AddInput( 208, 135, 260, 130, 20, FloatToString(MeltingHeat), " kJ", DIALOG_UNSIGNED_FLOAT );
	DialogCreatingPropeties.AddInformation( 110, 10, 290, 115, 20, "Evaporation heat:", DIALOG_LEFT );
	DialogCreatingPropeties.AddInput( 209, 135, 290, 130, 20, FloatToString(EvaporationHeat), " kJ", DIALOG_UNSIGNED_FLOAT );
	DialogCreatingPropeties.AddButton( 301, 10, 325, 20, 20, "<", false );
	DialogCreatingPropeties.AddButton( 302, 40, 325, 90, 20, "Save", false );
	DialogCreatingPropeties.AddButton( 303, 145, 325, 90, 20, "Rand", false );
	DialogCreatingPropeties.AddButton( 304, 245, 325, 20, 20, ">", false );

	Dialog DialogTimePropeties ( Font );
	DialogTimePropeties.SetPosition( 305, 20 );
	DialogTimePropeties.AddInformation( 100, 10, 10, 180, 30, "Time properties" );
	DialogTimePropeties.AddInformation( 101, 10, 50, 80, 20, "Acceleration:", DIALOG_LEFT );
	DialogTimePropeties.AddInput( 201, 100, 50, 90, 20, FloatToString(TimeAcceleration) );
	DialogTimePropeties.AddInformation( 102, 30, 80, 160, 20, "Pause simulation", DIALOG_LEFT );
	DialogTimePropeties.AddCheckbox( 301, 10, 85, Pause );

	Dialog DialogTracksPropeties (Font);
	DialogTracksPropeties.SetPosition( 515, 20 );
	DialogTracksPropeties.AddInformation( 100, 10, 10, 180, 30, "Tracks properties" );
	DialogTracksPropeties.AddInformation( 102, 10, 50, 90, 20, "Tracks length:", DIALOG_LEFT );
	DialogTracksPropeties.AddInput( 201, 110, 50, 80, 20, IntToString(TracksLength), "", DIALOG_UNSIGNED_INT );
	DialogTracksPropeties.AddInformation( 101, 30, 80, 160, 20, "Show particle's track", DIALOG_LEFT );
	DialogTracksPropeties.AddCheckbox( 301, 10, 85, ShowTracks );

	Dialog DialogCameraPropeties (Font);
	DialogCameraPropeties.SetPosition( 305, 140 );
	DialogCameraPropeties.AddInformation( 100, 10, 10, 200, 30, "Camera properties" );
	DialogCameraPropeties.AddInformation( 101, 10, 50, 80, 20, "Camera's x:", DIALOG_LEFT );
	DialogCameraPropeties.AddInput( 201, 100, 50, 110, 20, IntToString(CameraCenter.x), "", DIALOG_SIGNED_INT );
	DialogCameraPropeties.AddInformation( 102, 10, 80, 80, 20, "Camera's y:", DIALOG_LEFT );
	DialogCameraPropeties.AddInput( 202, 100, 80, 110, 20, IntToString(CameraCenter.y), "", DIALOG_SIGNED_INT );
	DialogCameraPropeties.AddInformation( 103, 10, 110, 80, 20, "Area:", DIALOG_LEFT );
	DialogCameraPropeties.AddInput( 203, 100, 110, 110, 20, IntToString( Area * 100 ), "%", DIALOG_UNSIGNED_FLOAT );
	DialogCameraPropeties.AddInformation( 104, 10, 140, 80, 20, "Focus:", DIALOG_LEFT );
	DialogCameraPropeties.AddInput( 204, 100, 140, 110, 20, "None", "", DIALOG_ASCII );

	// Application main loop
	while ( Window.isOpen() ) {

	sf::Event event;
	
	// Set window's title
	Window.setTitle( ( "Gravity 0.2 ( " + IntToString(FPS) + " FPS ) - " + IntToString(Particles.size()) + " particles" ).c_str() );
	
	// Recive events
	while ( Window.pollEvent(event) ) {

		// Recive dialog events
        bool Dialogs = false;
		
		if ( DialogCreatingPropeties.GetActivity() ) {

			int DialogCreatingPropetiesResponse = DialogCreatingPropeties.Response( Window, event );

			if ( DialogCreatingPropetiesResponse != DIALOG_NONE ) { Dialogs = true; }
			if ( DialogCreatingPropetiesResponse == DIALOG_MOVE ) { AfterTime = FPSClock.restart().asSeconds(); }
			if ( DialogCreatingPropetiesResponse == DIALOG_RETURN || DialogCreatingPropetiesResponse == DIALOG_CLOSE ) { 
				
				Mass = DialogCreatingPropeties.InputFloatResponse(202);
				Density = DialogCreatingPropeties.InputFloatResponse(203);
				Temperature = DialogCreatingPropeties.InputFloatResponse(204);
				MeltingTemperature = DialogCreatingPropeties.InputFloatResponse(205);
				EvaporationTemperature = DialogCreatingPropeties.InputFloatResponse(206);
				SpecificHeat = DialogCreatingPropeties.InputFloatResponse(207);
				MeltingHeat = DialogCreatingPropeties.InputFloatResponse(208);
				EvaporationHeat = DialogCreatingPropeties.InputFloatResponse(209);
				
				if ( Mass <= 0 ) { Mass = 0.01; }
				if ( Density <= 0 ) { Density = 0.01; }
				if ( Temperature < 0 ) { Temperature = 0; }
				if ( MeltingTemperature < 0 ) { MeltingTemperature = 0; }
				if ( EvaporationTemperature < 0 ) { EvaporationTemperature = 0; }
				if ( SpecificHeat <= 0 ) { SpecificHeat = 0.01; }
				if ( MeltingHeat <= 0 ) { MeltingHeat = 0.01; }
				if ( EvaporationHeat <= 0 ) { EvaporationHeat = 0.01; }
				
				DialogCreatingPropeties.SetInput( 202, FloatToString(Mass) );
				DialogCreatingPropeties.SetInput( 203, FloatToString(Density) );
				DialogCreatingPropeties.SetInput( 204, FloatToString(Temperature) );
				DialogCreatingPropeties.SetInput( 205, FloatToString(MeltingTemperature) );
				DialogCreatingPropeties.SetInput( 206, FloatToString(EvaporationTemperature) );
				DialogCreatingPropeties.SetInput( 207, FloatToString(SpecificHeat) );
				DialogCreatingPropeties.SetInput( 208, FloatToString(MeltingHeat) );
				DialogCreatingPropeties.SetInput( 209, FloatToString(EvaporationHeat) ); } }

		if ( DialogTimePropeties.GetActivity() ) {

			int DialogTimePropetiesResponse = DialogTimePropeties.Response( Window, event );

			if ( DialogTimePropetiesResponse != DIALOG_NONE ) { Dialogs = true; }
			if ( DialogTimePropetiesResponse == DIALOG_MOVE ) { AfterTime = FPSClock.restart().asSeconds(); }
			if ( DialogTimePropetiesResponse == DIALOG_RETURN ) { 
				
				TimeAcceleration = DialogTimePropeties.InputFloatResponse(201);
				DialogTimePropeties.SetInput( 201, FloatToString(TimeAcceleration) ); }

			if ( DialogTimePropetiesResponse == DIALOG_CLOSE ) { 
				
				TimeAcceleration = DialogTimePropeties.InputFloatResponse(201);
				DialogTimePropeties.SetInput( 201, FloatToString(TimeAcceleration) ); }

			if ( DialogTimePropetiesResponse == 301 ) { Pause = DialogTimePropeties.CheckboxResponse(301); } }

		if ( DialogTracksPropeties.GetActivity() ) {

			int DialogTracksPropetiesResponse = DialogTracksPropeties.Response( Window, event );

			if ( DialogTracksPropetiesResponse != DIALOG_NONE ) { Dialogs = true; }
			if ( DialogTracksPropetiesResponse == DIALOG_MOVE ) { AfterTime = FPSClock.restart().asSeconds(); }
			if ( DialogTracksPropetiesResponse == DIALOG_TEXT ) { TracksLength = DialogTracksPropeties.InputIntResponse(201); }
			if ( DialogTracksPropetiesResponse == DIALOG_RETURN || DialogTracksPropetiesResponse == DIALOG_CLOSE ) { DialogTracksPropeties.SetInput( 201, IntToString(TracksLength) ); }
			if ( DialogTracksPropetiesResponse == 301 ) { ShowTracks = DialogTracksPropeties.CheckboxResponse(301); } }

		if ( DialogCameraPropeties.GetActivity() ) {

			int DialogCameraPropetiesResponse = DialogCameraPropeties.Response( Window, event );

			if ( DialogCameraPropetiesResponse != DIALOG_NONE ) { Dialogs = true; }
			if ( DialogCameraPropetiesResponse == DIALOG_MOVE ) { AfterTime = FPSClock.restart().asSeconds(); }
			if ( DialogCameraPropetiesResponse == DIALOG_RETURN ) { 
				
				CameraCenter.x = DialogCameraPropeties.InputIntResponse(201);
				CameraCenter.y = DialogCameraPropeties.InputIntResponse(202);
				Area = DialogCameraPropeties.InputIntResponse(203) / 100.00;
				
				string FindFocus = DialogCameraPropeties.InputTextResponse(204);
				Focus = -10;

				for ( int i = 0; i < Particles.size(); i++ ) {

					if ( Particles[i].Name == FindFocus ) { Focus = i; } } } }

		// Recive no-dialog events
		if ( !Dialogs ) {

			sf::Vector2i MousePosition = sf::Mouse::getPosition(Window);

			// Resize window
			if ( event.type == sf::Event::Resized ) { WindowWidth = Window.getSize().x; WindowHeight = Window.getSize().y; }

			// Create particle
			if ( event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left ) { VectorForce.x1 = MousePosition.x; VectorForce.y1 = MousePosition.y; }
			if ( event.type == sf::Event::MouseButtonReleased && event.mouseButton.button == sf::Mouse::Left ) { 
			
				VectorForce.x2 = MousePosition.x; VectorForce.y2 = MousePosition.y;
				AddParticle ( Area * ( VectorForce.x1 - WindowWidth/2 ) + CameraCenter.x, Area * ( VectorForce.y1 - WindowHeight/2 ) + CameraCenter.y, Area * ( VectorForce.x2 - VectorForce.x1 ) / 1, Area * ( VectorForce.y2 - VectorForce.y1 ) / 1, Mass, Density, Temperature, MeltingTemperature, EvaporationTemperature, SpecificHeat, MeltingHeat, EvaporationHeat );
				VectorForce.x1 = 0; VectorForce.y1 = 0; VectorForce.x2 = 0; VectorForce.y2 = 0; }
			 
			// Create dialogs
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Tab ) { DialogCreatingPropeties.SetActivity(true); }
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Q ) { DialogTimePropeties.SetActivity(true); }
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::W ) { DialogTracksPropeties.SetActivity(true); }
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::E ) { DialogCameraPropeties.SetActivity(true); }

			// Change camera position
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Up ) { UP = true; }
			if ( event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::Up ) { UP = false; }
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Down ) { DOWN = true; }
			if ( event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::Down ) { DOWN = false; }
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Left ) { LEFT = true; }
			if ( event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::Left ) { LEFT = false; }
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Right ) { RIGHT = true; }
			if ( event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::Right ) { RIGHT = false; }

			// Change camera's area
			if ( event.type == sf::Event::MouseWheelMoved && event.mouseWheel.delta < 0 && Area < 1000000 ) { Area += 0.1; }
			if ( event.type == sf::Event::MouseWheelMoved && event.mouseWheel.delta > 0 && Area > 0.1 ) { Area -= 0.1; }

			// Manipulate simulation
			if ( event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::Escape ) { Window.close(); }
			if ( event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::BackSlash ) { Particles.clear(); Tracks.clear(); Time = 0; }

			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::C ) { TimeAcceleration += 0.1; DialogTimePropeties.SetInput( 201, FloatToString(TimeAcceleration) );  }
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Z ) { TimeAcceleration -= 0.1; DialogTimePropeties.SetInput( 201, FloatToString(TimeAcceleration) ); }
			
			if ( event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::X ) { 

				bool PauseCheck = Pause;

				if ( PauseCheck == false ) { Pause = true; }
				if ( PauseCheck == true  ) { Pause = false; }
		
				DialogTimePropeties.SetCheckbox( 301, Pause ); }
			
			if ( event.type == sf::Event::KeyReleased && event.key.code == sf::Keyboard::B ) { 

				bool TracksCheck = ShowTracks;

				if ( TracksCheck == false ) { ShowTracks = true; }
				if ( TracksCheck == true  ) { ShowTracks = false; }
		
				DialogTracksPropeties.SetCheckbox( 301, ShowTracks ); }

			// Focus on particle
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Slash ) { Focus = -10; }
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Comma ) { Focus--;  }
			if ( event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Period ) { Focus++; }

			// Close application
			if ( event.type == sf::Event::Closed ) { Window.close(); } } }

	// Change time
	if ( TimeAcceleration < 0.1 ) { TimeAcceleration = 0.1; DialogTimePropeties.SetInput( 201, FloatToString(TimeAcceleration) ); }
	if ( TimeAcceleration > 1000 ) { TimeAcceleration = 1000; DialogTimePropeties.SetInput( 201, FloatToString(TimeAcceleration) ); }

	if ( Pause == false ) {
		
		Time += TimeAcceleration * ( 1 / FPS ) * 2.105; } // = G * 10 ^ 3 [years]

	// Change view
	if ( VectorForce.x1 == 0 && VectorForce.y1 == 0 ) {

		if ( UP    ) { CameraCenter.y -= 500 * Area * ( 1 / FPS ); }
		if ( DOWN  ) { CameraCenter.y += 500 * Area * ( 1 / FPS ); }
		if ( LEFT  ) { CameraCenter.x -= 500 * Area * ( 1 / FPS ); }
		if ( RIGHT ) { CameraCenter.x += 500 * Area * ( 1 / FPS ); } }

	// Normalize
	if ( Area < 0.1 ) { Area = 0.1; }
	if ( Area > 1000000 ) { Area = 1000000; }

	if ( CameraCenter.x > 99999999 ) { CameraCenter.x = 99999999; }
	if ( CameraCenter.x < -99999999 ) { CameraCenter.x = -99999999; }
	if ( CameraCenter.y > 99999999 ) { CameraCenter.y = 99999999; }
	if ( CameraCenter.y < -99999999 ) { CameraCenter.y = -99999999; }

	// Create user's view
	sf::View View;
	
	if ( Particles.size() > 0 ) {

		if ( Focus == -9 ) { Focus = 0; }
		if ( Focus == -11 ) { Focus = Particles.size() - 1; }
		if ( Focus < 0 && Focus != -10 ) { Focus = Particles.size() - 1; }
		if ( Focus == Particles.size() ) { Focus = 0; } }
	
	if ( Focus >= 0 ) { 
		
		CameraCenter.x = Particles[Focus].x;
		CameraCenter.y = Particles[Focus].y;
		
		View.setSize( WindowWidth, WindowHeight ); View.zoom(Area);
		View.setCenter( sf::Vector2f( CameraCenter.x, CameraCenter.y ) ); }

	if ( Focus == -10 ) { 
		
		View.setSize(WindowWidth,WindowHeight); View.zoom(Area);
		View.setCenter( CameraCenter.x, CameraCenter.y ); }

	// Preprocesss dialogs
	if ( DialogCameraPropeties.GetActivity() && CameraUpdate < FPS * 0.1 ) { CameraUpdate++; }
	if ( DialogCameraPropeties.GetActivity() && CameraUpdate >= FPS * 0.1 ) {

		CameraUpdate = 0;

		DialogCameraPropeties.SetInput( 201, IntToString(CameraCenter.x) );
		DialogCameraPropeties.SetInput( 202, IntToString(CameraCenter.y) );
		DialogCameraPropeties.SetInput( 203, IntToString( Area * 100 ) );

		if ( Focus < 0 ) { DialogCameraPropeties.SetInput( 204, "None" ); }
		if ( Focus >= 0 ) { DialogCameraPropeties.SetInput( 204, Particles[Focus].Name ); } }

	// Analyze the trajectory of particles
	if ( Pause == false ) {

	string KeepFocus;

	for( int i = 0; i < Particles.size(); i++ ) {

		Particle &P1 = Particles[i];
		Track &CurrentTrack = Tracks[i];
		
		bool SimpleMove = true;

		CurrentTrack.x = 0;
		CurrentTrack.y = 0;

		for( int j = 0; j < Particles.size(); j++ ) {

			if ( i == j ) { continue; }

			const Particle &P2 = Particles[j];

			float Distance = sqrt( ( P2.x - P1.x ) * ( P2.x - P1.x ) + ( P2.y - P1.y ) * ( P2.y - P1.y ) );

			if ( Distance > ( P1.Radius * ParticlesRadiusRatio + P2.Radius * ParticlesRadiusRatio ) ) {

				P1.vx += TimeAcceleration * ( 1 / FPS ) * P2.Mass / ( Distance * Distance ) * ( P2.x - P1.x ) / ( Distance );
				P1.vy += TimeAcceleration * ( 1 / FPS ) * P2.Mass / ( Distance * Distance ) * ( P2.y - P1.y ) / ( Distance ); }

			else {

				Collision CurrentCollision;
				CurrentCollision.FirstIterator = i;
				CurrentCollision.SecondIterator = j;
				Collisions.push_back(CurrentCollision);

				SimpleMove = false; } }

		if ( SimpleMove ) {

			Tracks[i].x += P1.vx * TimeAcceleration * ( 1 / FPS );
			Tracks[i].y += P1.vy * TimeAcceleration * ( 1 / FPS ); }
		
		P1.Orbit.push_back( sf::Vertex( sf::Vector2f( P1.x, P1.y ), GetSpeedColor( sqrt ( pow ( P1.vx, 2 ) + pow( P1.vy, 2 ) ) ) ) ); }
	
	// Combine the particles that have collided
	AnalyzeCollisions();

	// Keep focus value	
	if ( Focus >= 0 ) { KeepFocus = Particles[Focus].Name; } Focus = -10;

	// Move particles that have survived
	for ( int i = 0; i < Particles.size(); i++ ) {

		Particle &CurrentParticle = Particles[i];

		if ( CurrentParticle.Mass >= 0 && CurrentParticle.Destroyed == false ) {
			
			CurrentParticle.x += Tracks[i].x;
			CurrentParticle.y += Tracks[i].y; }

		if ( CurrentParticle.Mass < 0 || CurrentParticle.x > 999999999 || CurrentParticle.x < -999999999 || CurrentParticle.y > 999999999 || CurrentParticle.y < -999999999 || CurrentParticle.Destroyed == true ) {
			
			Particles.erase( Particles.begin() + i );
			Tracks.erase( Tracks.begin() + i ); } }
	
	// Restore focus value
	for ( int i = 0; i < Particles.size(); i++ ) {

		if ( Particles[i].Name == KeepFocus ) { Focus = i; } } }

	// Clear window
	Window.clear();

	// Reset Time
	sf::Time ElapsedTime = ElapsedClock.getElapsedTime();
	ElapsedClock.restart();	

	// Draw particles that have survived
	for ( int i = 0; i < Particles.size(); i++ ) {

		sf::CircleShape Circle;
		Circle.setFillColor( Particles[i].Color );
		Circle.setRadius( Particles[i].Radius * ParticlesRadiusRatio );
		Circle.setOrigin( Circle.getRadius(), Circle.getRadius() );
		Circle.setPosition( Particles[i].x, Particles[i].y );

		if ( ShowTracks == true ) {

			float TracksVisibility;

			if ( Particles[i].Orbit.size() >= TracksLength ) { TracksVisibility = TracksLength; }
			if ( Particles[i].Orbit.size() < TracksLength ) { TracksVisibility = Particles[i].Orbit.size(); }

			for ( int j = 0; j < TracksLength && j < Particles[i].Orbit.size(); j++ ) {
				
				Particles[i].Orbit[Particles[i].Orbit.size()-1-j].color.a = 255 * ( ( TracksVisibility - j ) / TracksVisibility ); }

			if ( Particles[i].Orbit.size() >= TracksLength ) { 
				
				Window.draw( &Particles[i].Orbit[Particles[i].Orbit.size()-TracksLength], TracksLength, sf::LinesStrip ); }

			if ( Particles[i].Orbit.size() < TracksLength ) { 
				
				Window.draw( &Particles[i].Orbit[0], Particles[i].Orbit.size(), sf::LinesStrip ); } }

		Window.draw(Circle); }

	// Draw indicator of the force vector
	if ( VectorForce.x1 != 0 || VectorForce.y1 != 0 ) {

		sf::Vector2i MousePosition = sf::Mouse::getPosition(Window);
		sf::Vertex Vector[2] = { sf::Vertex( sf::Vector2f( Area * ( VectorForce.x1 - WindowWidth / 2 ) + CameraCenter.x, Area * ( VectorForce.y1 - WindowHeight / 2 ) + CameraCenter.y ) ), sf::Vertex( sf::Vector2f( Area * ( MousePosition.x - WindowWidth / 2 ) + CameraCenter.x, Area * ( MousePosition.y - WindowHeight / 2 ) + CameraCenter.y ) ) };

		float Speed = sqrt ( pow ( ( ( Area * ( MousePosition.x - WindowWidth / 2 ) + CameraCenter.x ) - ( Area * ( VectorForce.x1 - WindowWidth / 2 ) + CameraCenter.x ) ) / 1.00, 2 ) + pow ( ( ( Area * ( MousePosition.y - WindowHeight / 2 ) + CameraCenter.y ) - ( Area * ( VectorForce.y1 - WindowHeight / 2 ) + CameraCenter.y ) ) / 1.00, 2 ) );

		Vector[0].color = sf::Color( 0, 0, 0, 255 );
		Vector[1].color = GetSpeedColor(Speed);

		sf::Text SpeedInfo;
		SpeedInfo.setCharacterSize(25);
		SpeedInfo.setColor( GetSpeedColor(Speed) );
		SpeedInfo.setPosition( sf::Vector2f( ( Area * ( MousePosition.x - WindowWidth / 2 ) + CameraCenter.x ) + Area * 20, ( Area * ( MousePosition.y - WindowHeight / 2 ) + CameraCenter.y ) + Area * 20 ) );
		SpeedInfo.setString( FloatToString( Speed / 2.105 ) + " km/year" );
		SpeedInfo.setFont(Font);
		SpeedInfo.setScale( Area, Area );

		Window.draw( Vector, 2, sf::Lines );
		Window.draw( SpeedInfo ); }

	// Change view into interface
	Window.setView( sf::View( sf::FloatRect( 0, 0, WindowWidth, WindowHeight ) ) );

	// Draw clock
	sf::Text Clock;
	Clock.setPosition( WindowWidth - 165, 15 );
	Clock.setString( YearsToString( Time / 1000 ) + " years" ); // = Time / 10 ^ 3
	Clock.setColor( sf::Color( 255, 255, 255, 175 ) );
	Clock.setFont(Font);
	Clock.setCharacterSize(25);
	Window.draw(Clock);

	// Draw scale
	sf::RectangleShape Scale;
	Scale.setSize( sf::Vector2f( 100, 2 ) );
	Scale.setPosition( 15, WindowHeight - 15 );
	Scale.setFillColor( sf::Color( 255, 255, 255, 175 ) );
	Window.draw(Scale);

	// Draw scale information
	sf::Text ScaleInfo;
	ScaleInfo.setPosition( 15, WindowHeight - 40 );
	ScaleInfo.setString( IntToString( Area * 100 ) + " m" );
	ScaleInfo.setColor( sf::Color( 255, 255, 255, 175 ) );
	ScaleInfo.setCharacterSize(15);
	ScaleInfo.setFont(Font);
	Window.draw(ScaleInfo);

	// Draw dialogs
	DialogCreatingPropeties.Show(Window);
	DialogTracksPropeties.Show(Window);
	DialogCameraPropeties.Show(Window);
	DialogTimePropeties.Show(Window);

	// Change view into user's view
	Window.setView(View);

	// Change FPS
	AfterTime = FPSClock.restart().asSeconds();
    FPS = 1.00 / AfterTime;
	BeforeTime = AfterTime;

	// Send image to window
    Window.display(); }

	// Create final log
	Log("End of the simulation.");
	CreateLog();

	// Close application
	return 0; }

