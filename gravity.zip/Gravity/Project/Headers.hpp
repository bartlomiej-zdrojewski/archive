// Define this file
#ifndef PROGRAM_HEADERS
#define PROGRAM_HEADERS

// Include static librares
#include <SFML\\Graphics.hpp>
#include <windows.h>
#include <shlwapi.h>
#include <sstream>
#include <fstream>
#include <cmath>

// Include classes
#include "Dialog.hpp"

// Incude namespaces
using namespace std;

// Define PI
#define PI 3.14159265358979323846

// Define static symbols
#define GAS			001
#define LIQUID		002
#define SOLID		003

// Define structures
struct Particle {
	
	string Name;
	float x;
	float y;
	float vx;
	float vy;
	float Radius;
	float Mass;
	float Density;
	float Temperature;
	float MeltingTemperature;
	float EvaporationTemperature;
	float SpecificHeat;
	float MeltingHeat;
	float EvaporationHeat;
	int Phase;
	float PhaseEnergy;
	bool Destroyed;
	sf::Color Color;
	vector <sf::Vertex> Orbit; };

struct Track {

	float x;
	float y; };

struct Collision {

	unsigned int FirstIterator;
	unsigned int SecondIterator; };

struct Vector {

	int x1;
	int y1;
	int x2;
	int y2; };

// End of definition
#endif