// Define this file
#ifndef PROGRAM_VALUES
#define PROGRAM_VALUES

// Application
extern sf::Clock ApplicationTime;
extern sf::Clock FPSClock;
extern sf::Font Font;

extern float FPS;
extern float BeforeTime;
extern float AfterTime;

extern string ApplicationDirectory;
extern string LogsDirectory;
extern bool Pause;

// Window
extern int WindowWidth;
extern int WindowHeight;

// Camera
extern Track CameraCenter;
extern int CameraUpdate;
extern int Focus;
extern float Area;

// Keys
extern bool UP;
extern bool DOWN;
extern bool LEFT;
extern bool RIGHT;
extern bool Q;
extern bool A;
extern bool Z;

// Interface
extern Vector VectorForce;
extern bool ShowTracks;
extern int TracksLength;

// Universe
extern float Gravity;
extern float Time;
extern float TimeAcceleration;
extern float Precision;

// Particles
extern int ParticleSerialCode;
extern float ParticlesRadiusRatio;

extern vector<Particle> Particles;
extern vector<Track> Tracks;
extern vector<Collision> Collisions;
extern vector<int> Destroyed;

// Particles properties
extern string Substance;
extern float Mass;
extern float Density;
extern float Temperature;
extern float MeltingTemperature;
extern float EvaporationTemperature;
extern float SpecificHeat;
extern float MeltingHeat;
extern float EvaporationHeat;

// End of definition
#endif