// Define this file
#ifndef CLASS_DIALOG
#define CLASS_DIALOG

// Include static librares and definitions
#include <SFML\\Graphics.hpp>
#include <math.h>
#include <iostream>
#include <iomanip>

// Incude namespaces
using namespace std;

// Define static values
#define DIALOG_LEFT 1
#define DIALOG_CENTER 2
#define DIALOG_RIGHT 3

#define DIALOG_UNSIGNED_INT 4
#define DIALOG_SIGNED_INT 5
#define DIALOG_UNSIGNED_FLOAT 6
#define DIALOG_SIGNED_FLOAT 7
#define DIALOG_ASCII 8

#define DIALOG_NONE 0
#define DIALOG_CLOSE -1
#define DIALOG_MOVE -2
#define DIALOG_TEXT -3
#define DIALOG_RETURN -4

// Define particle class
class Dialog {
	
public:
	
    Dialog ( sf::Font Font ):
		
		Font ( Font ),
		FillColor ( sf::Color ( 255, 255, 255, 0 ) ),
		OutlineColor ( sf::Color ( 255, 255, 255, 100 ) ),

		Activity ( false ),
		Modified ( true ),
		
		X ( 20 ),
		Y ( 20 ),
		Width ( 0 ),
		Height ( 0 ),
		
		InformationsColor ( sf::Color( 255, 255, 255, 200 ) ),

		InputModified ( -1 ),
		InputModifiedComma ( false ),
		InputModifiedMinus ( false ),
		InputsOutlineThickness ( 2 ),
		InputsFillColor ( sf::Color( 255, 255, 255, 175 ) ),
		InputsOutlineColor ( sf::Color( 255, 255, 255, 100 ) ),
		InputsTextColor ( sf::Color( 0, 0, 0, 200 ) ),
		InputsModifiedTextColor ( sf::Color( 0, 0, 200, 200 ) ),

		ButtonsFillColor ( sf::Color( 255, 255, 255, 175 ) ),
		ButtonsOutlineColor ( sf::Color( 255, 255, 255, 100 ) ),
		ButtonsOutlineThickness ( 2 ),
		ButtonsTextColor ( sf::Color( 0, 0, 0, 200 ) ),
		
		CheckboxesCheckedColor ( sf::Color( 255, 255, 255, 175 ) ),
		CheckboxesUncheckedColor ( sf::Color( 0, 0, 0, 200 ) ),
		CheckboxesOutlineColor ( sf::Color( 255, 255, 255, 100 ) ),
		CheckboxesOutlineThickness ( 2 ) { }

public:

	void SetActivity ( bool NewActivity ) {

		Activity = NewActivity; }

	bool GetActivity ( ) {

		if ( Activity == true ) { return true; }

		return false; }

	void SetPosition ( int NewX, int NewY ) {

		X = NewX;
		Y = NewY; }

	int GetPositionX ( ) {

		return X; }

	int GetPositionY ( ) {

		return Y; }

	void SetInformation ( int InformationID, string InformationText ) {

		for ( int i = 0; i < Informations.size(); i++ ) {
			
			if ( Informations[i].ID == InformationID ) { Informations[i].Text = InformationText; } }
		
		Modified = true; }

	void SetInput ( int InputID, string InputText ) {

		for ( int i = 0; i < Inputs.size(); i++ ) {

			if ( Inputs[i].ID == InputID && i != InputModified ) { Inputs[i].Text = InputText; } }
		
		Modified = true; }

	void SetCheckbox ( int CheckboxID, bool Check ) {
		
		for ( int i = 0; i < Checkboxes.size(); i++ ) {

			if ( Checkboxes[i].ID == CheckboxID ) { Checkboxes[i].Checked = Check; } }
		
		Modified = true; }

	string InputTextResponse ( int InputID ) {

		for ( int i = 0; i < Inputs.size(); i++ ) {

			if ( Inputs[i].ID == InputID ) { return Inputs[i].Text; } }

			return ""; }

	int InputIntResponse ( int InputID ) {

		for ( int i = 0; i < Inputs.size(); i++ ) {

			if ( Inputs[i].ID == InputID ) { return StringToInt(Inputs[i].Text); } }

			return 0; }

	float InputFloatResponse ( int InputID ) {

		for ( int i = 0; i < Inputs.size(); i++ ) {

			if ( Inputs[i].ID == InputID ) { return StringToFloat(Inputs[i].Text); } }

			return 0; }

	bool CheckboxResponse ( int CheckboxID ) {

		for ( int i = 0; i < Checkboxes.size(); i++ ) {

			if ( Checkboxes[i].ID == CheckboxID ) { return Checkboxes[i].Checked; } }

			return false; }

	void AddInformation ( int InformationID, int InformationX, int InformationY, int InformationWidth, int InformationHeight, string InformationText, int InformationOrientation = DIALOG_CENTER ) {

		Information NewInformation;

		NewInformation.ID = InformationID;
		NewInformation.x = InformationX;
		NewInformation.y = InformationY;
		NewInformation.Width = InformationWidth;
		NewInformation.Height = InformationHeight;
		NewInformation.Text = InformationText;
		NewInformation.Orientation = InformationOrientation;

		Informations.push_back(NewInformation);

		if ( InformationX + InformationWidth > Width ) { Width = InformationX + InformationWidth + 10; }
		if ( InformationY + InformationHeight > Height ) { Height = InformationY + InformationHeight + 10; }
		
		Modified = true; }

	void AddInput ( int InputID, int InputX, int InputY, int InputWidth, int InputHeight, string InformationDefaultText = "", string InputAdditionalText = "", int InputType = DIALOG_SIGNED_FLOAT ) {

		Input NewInput;

		NewInput.ID = InputID;
		NewInput.x = InputX;
		NewInput.y = InputY;
		NewInput.Width = InputWidth;
		NewInput.Height = InputHeight;
		NewInput.Text = InformationDefaultText;
		NewInput.AdditionalText = InputAdditionalText;
		NewInput.Type = InputType;

		Inputs.push_back(NewInput);

		if ( InputX + InputWidth > Width ) { Width = InputX + InputWidth + 10; }
		if ( InputY + InputHeight > Height ) { Height = InputY + InputHeight + 10; }
		
		Modified = true; }

	void AddButton ( int ButtonID, int ButtonX, int ButtonY, int ButtonWidth, int ButtonHeight, string ButtonText = "", bool Close = false ) {

		Button NewButton;

		NewButton.ID = ButtonID;
		NewButton.x = ButtonX;
		NewButton.y = ButtonY;
		NewButton.Width = ButtonWidth;
		NewButton.Height = ButtonHeight;
		NewButton.Text = ButtonText;
		NewButton.Close = Close;

		Buttons.push_back(NewButton);

		if ( ButtonX + ButtonWidth > Width ) { Width = ButtonX + ButtonWidth + 10; }
		if ( ButtonY + ButtonHeight > Height ) { Height = ButtonY + ButtonHeight + 10; }
		
		Modified = true; }
		
	void AddCheckbox ( int CheckboxID, int CheckboxX, int CheckboxY, bool CheckboxChecked = false ) {

		Checkbox NewCheckbox;

		NewCheckbox.ID = CheckboxID;
		NewCheckbox.x = CheckboxX;
		NewCheckbox.y = CheckboxY;
		NewCheckbox.Checked = CheckboxChecked;

		Checkboxes.push_back(NewCheckbox);

		if ( CheckboxX + 5 > Width ) { Width = CheckboxX + 15; }
		if ( CheckboxY + 5 > Height ) { Height = CheckboxY + 15; }
		
		Modified = true; }

	void Show ( sf::RenderWindow &Window, sf::RenderStates States = sf::BlendAdd ) {

		if ( Activity == true ) {

		if ( Modified == true ) {

		Render.create( Width, Height );
		Render.clear( sf::Color( 0, 0, 0, 0 ) );

		sf::RectangleShape DialogImage;
		DialogImage.setPosition( 2, 2 );
		DialogImage.setSize( sf::Vector2f( Width-4, Height-4 ) );
		DialogImage.setFillColor(FillColor);
		DialogImage.setOutlineColor(OutlineColor);
		DialogImage.setOutlineThickness(2);
		Render.draw( DialogImage, sf::BlendAlpha );

		for ( int i = 0; i < Informations.size(); i++ ) {
			
			sf::Text InformationText;
			InformationText.setString(Informations[i].Text);
			InformationText.setCharacterSize( Informations[i].Height * 0.8 );
			InformationText.setColor(InformationsColor);
			InformationText.setFont(Font);
			
			InformationText.setPosition( Informations[i].x + ( Informations[i].Width - InformationText.getLocalBounds().width ) / 2, Informations[i].y );
			
			if ( Informations[i].Orientation == DIALOG_LEFT ) { InformationText.setPosition( Informations[i].x, Informations[i].y ); }
			if ( Informations[i].Orientation == DIALOG_RIGHT ) { InformationText.setPosition( Informations[i].x + Informations[i].Width - InformationText.getLocalBounds().width, Informations[i].y ); }

			Render.draw(InformationText); }

		for ( int i = 0; i < Inputs.size(); i++ ) {

			sf::RectangleShape InputImage;
			InputImage.setSize( sf::Vector2f( Inputs[i].Width, Inputs[i].Height ) );
			InputImage.setFillColor(InputsFillColor);
			InputImage.setOutlineColor(InputsOutlineColor);
			InputImage.setOutlineThickness(InputsOutlineThickness);
			
			sf::Text InputText;
			InputText.setString( Inputs[i].Text + Inputs[i].AdditionalText );
			InputText.setCharacterSize( Inputs[i].Height * 0.8 );
			InputText.setColor(InputsTextColor);
			InputText.setFont(Font);
			
			if ( InputModified == i ) { InputText.setColor(InputsModifiedTextColor); }

			//if ( InputText.getLocalBounds().width > Inputs[i].Width - 4 ) { InputText.setString( Inputs[i].Text.substr( Inputs[i].Text.length() + Inputs[i].AdditionalText.length() - floor ( ( Inputs[i].Width - 4 ) / InputText.getLocalBounds().width * Inputs[i].Text.length() ), floor ( ( Inputs[i].Width - 4 ) / InputText.getLocalBounds().width * Inputs[i].Text.length() ) ) ); }
			if ( InputText.getLocalBounds().width > Inputs[i].Width - 4 ) { InputText.setString( Inputs[i].Text.substr( Inputs[i].Text.length() + Inputs[i].AdditionalText.length() - floor ( ( Inputs[i].Width - 4 ) / InputText.getLocalBounds().width * ( Inputs[i].Text.length() + Inputs[i].AdditionalText.length() ) ), floor ( ( Inputs[i].Width - 4 ) / InputText.getLocalBounds().width * ( Inputs[i].Text.length() + Inputs[i].AdditionalText.length() ) ) ) ); }

			InputImage.setPosition( Inputs[i].x, Inputs[i].y );
			InputText.setPosition( Inputs[i].x + 2, Inputs[i].y );

			Render.draw(InputImage);
			Render.draw(InputText); }

		for ( int i = 0; i < Buttons.size(); i++ ) {

			sf::RectangleShape ButtonImage;
			ButtonImage.setSize( sf::Vector2f( Buttons[i].Width, Buttons[i].Height ) );
			ButtonImage.setFillColor(ButtonsFillColor);
			ButtonImage.setOutlineColor(ButtonsOutlineColor);
			ButtonImage.setOutlineThickness(ButtonsOutlineThickness);
			
			sf::Text ButtonText;
			ButtonText.setString(Buttons[i].Text);
			ButtonText.setCharacterSize( Buttons[i].Height * 0.8 );
			ButtonText.setColor(ButtonsTextColor);
			ButtonText.setFont(Font);
			
			ButtonImage.setPosition( Buttons[i].x, Buttons[i].y );
			ButtonText.setPosition( Buttons[i].x + ( Buttons[i].Width - ButtonText.getLocalBounds().width ) / 2, Buttons[i].y );

			Render.draw(ButtonImage);
			Render.draw(ButtonText); }

		for ( int i = 0; i < Checkboxes.size(); i++ ) {

			sf::RectangleShape CheckboxImage;
			CheckboxImage.setSize( sf::Vector2f( 10, 10 ) );
			CheckboxImage.setOutlineColor(CheckboxesOutlineColor);
			CheckboxImage.setOutlineThickness(CheckboxesOutlineThickness);
			
			CheckboxImage.setPosition( Checkboxes[i].x, Checkboxes[i].y );

			if ( Checkboxes[i].Checked == true ) { CheckboxImage.setFillColor(CheckboxesCheckedColor); }
			if ( Checkboxes[i].Checked == false ) { CheckboxImage.setFillColor(CheckboxesUncheckedColor); }

			Render.draw(CheckboxImage); }

		Render.display();
		Modified = false; }

		sf::Sprite DialogSprite ( Render.getTexture() );
		DialogSprite.setPosition( X, Y );

		Window.draw( DialogSprite, States ); } }
		
	int Response ( sf::RenderWindow &Window, sf::Event &Event ) {
		
		if ( InputModified != -1 && Event.type == sf::Event::KeyPressed ) {

			if ( Event.key.code == sf::Keyboard::Return ) { InputModified = -1; InputModifiedMinus = false; InputModifiedComma = false; return DIALOG_RETURN; }
			if ( Event.key.code == sf::Keyboard::Delete ) { Inputs[InputModified].Text.clear(); InputModifiedMinus = false; InputModifiedComma = false; }
			if ( Event.key.code == sf::Keyboard::BackSpace && Inputs[InputModified].Text.length() > 0 ) { 
				
				if ( Inputs[InputModified].Text.length() == 1 && Inputs[InputModified].Text[0] == '-' ) {

					InputModifiedMinus = false; }

				if ( Inputs[InputModified].Text[Inputs[InputModified].Text.length()-1] == ',' || Inputs[InputModified].Text[Inputs[InputModified].Text.length()-1] == '.' ) {

					InputModifiedComma = false; }

				Inputs[InputModified].Text = Inputs[InputModified].Text.substr( 0, Inputs[InputModified].Text.length() - 1 ); }
				
				Modified = true;
				return DIALOG_TEXT; }

		if ( InputModified != -1 && Event.type == sf::Event::TextEntered && Event.text.unicode >= 32 && Event.text.unicode <= 126 ) {

			if ( Inputs[InputModified].Type == DIALOG_ASCII ) {
				
				 Inputs[InputModified].Text = Inputs[InputModified].Text + static_cast<char>(Event.text.unicode); }

			if ( Inputs[InputModified].Type == DIALOG_SIGNED_INT || Inputs[InputModified].Type == DIALOG_UNSIGNED_INT || Inputs[InputModified].Type == DIALOG_SIGNED_FLOAT || Inputs[InputModified].Type == DIALOG_UNSIGNED_FLOAT ) {
				
				int SignificantSize = Inputs[InputModified].Text.length();

				if ( InputModifiedMinus == true ) { SignificantSize--; }
				if ( InputModifiedComma == true ) { SignificantSize--; }

				if  ( ( Inputs[InputModified].Type == DIALOG_SIGNED_INT || Inputs[InputModified].Type == DIALOG_SIGNED_FLOAT ) && Inputs[InputModified].Text.length() == 0 ) {

					if ( Event.text.unicode == 45 && InputModifiedMinus == false ) { Inputs[InputModified].Text = Inputs[InputModified].Text + static_cast<char>(Event.text.unicode); InputModifiedMinus = true; } }

				if ( Inputs[InputModified].Type == DIALOG_SIGNED_FLOAT && SignificantSize > 0 ) {

					if ( ( Event.text.unicode == 44 || Event.text.unicode == 46 ) && InputModifiedComma == false ) { Inputs[InputModified].Text = Inputs[InputModified].Text + static_cast<char>(Event.text.unicode); InputModifiedComma = true; } }

				if  ( ( InputModifiedComma == true && SignificantSize < 10 ) || ( InputModifiedComma == false && SignificantSize < 8 ) ) { 

					if ( Event.text.unicode >= 48 && Event.text.unicode <= 57 ) { Inputs[InputModified].Text = Inputs[InputModified].Text + static_cast<char>(Event.text.unicode); } }

			Modified = true;
			return DIALOG_TEXT; } }

		if ( ( Event.type == sf::Event::MouseButtonPressed || Event.type == sf::Event::MouseButtonReleased ) && Event.mouseButton.button == sf::Mouse::Left ) {

			sf::Vector2i MousePosition = sf::Mouse::getPosition(Window);
			InputModified = -1;

			if ( MousePosition.x >= X && MousePosition.x <= X + Width && 
				 MousePosition.y >= Y && MousePosition.y <= Y + Height ) {
				 
				 int MouseX = MousePosition.x - X;
				 int MouseY = MousePosition.y - Y;

				 for ( int i = 0; i < Inputs.size(); i++ ) {
					   
					   if ( MouseX >= Inputs[i].x && MouseX <= Inputs[i].x + Inputs[i].Width && 
						    MouseY >= Inputs[i].y && MouseY <= Inputs[i].y + Inputs[i].Height ) { 
								
								Modified = true;
								InputModified = i;

								InputModifiedMinus = false;
								InputModifiedComma = false;

								if ( Inputs[InputModified].Text.find(",") != string::npos || Inputs[InputModified].Text.find(".") != string::npos ) { InputModifiedComma = true; }
								if ( Inputs[InputModified].Text.find("-") != string::npos ) { InputModifiedMinus = true; }

								return DIALOG_TEXT; } }

				 for ( int i = 0; i < Buttons.size(); i++ ) {
					   
					   if ( MouseX >= Buttons[i].x && MouseX <= Buttons[i].x + Buttons[i].Width && 
						    MouseY >= Buttons[i].y && MouseY <= Buttons[i].y + Buttons[i].Height ) { 
								
								if ( Buttons[i].Close == true ) { Activity = false; }
								while ( Event.type != sf::Event::MouseButtonReleased || Event.mouseButton.button != sf::Mouse::Left ) { Window.pollEvent(Event); }

								return Buttons[i].ID; } }
					  
				 for ( int i = 0; i < Checkboxes.size(); i++ ) {
					   
					   if ( MouseX >= Checkboxes[i].x && MouseX <= Checkboxes[i].x + 10 && 
						    MouseY >= Checkboxes[i].y && MouseY <= Checkboxes[i].y + 10 ) { 
								
								Modified = true;
								bool CheckboxState = Checkboxes[i].Checked;

								if ( CheckboxState == true ) { Checkboxes[i].Checked = false; }
								if ( CheckboxState == false ) { Checkboxes[i].Checked = true; }

								while ( Event.type != sf::Event::MouseButtonReleased || Event.mouseButton.button != sf::Mouse::Left ) { Window.pollEvent(Event); }
								
								return Checkboxes[i].ID; } }

				 sf::Texture WindowTexture;
				 sf::Image WindowImage = Window.capture();
				 WindowTexture.loadFromImage(WindowImage);
				 sf::Sprite WindowSprite(WindowTexture);
				 WindowSprite.setColor( sf::Color( 255, 255, 255, 100 ) );

				 sf::FloatRect VisibleArea ( 0, 0, Window.getSize().x, Window.getSize().y );

				 while ( Event.type != sf::Event::MouseButtonReleased || Event.mouseButton.button != sf::Mouse::Left ) {

					 MousePosition = sf::Mouse::getPosition(Window);

					 X = MousePosition.x;
					 Y = MousePosition.y;
					 
					 Window.clear();
					 Window.setView(sf::View(VisibleArea));
					 Window.draw(WindowSprite);
					 Show(Window);
					 Window.display();

					 Window.pollEvent(Event); }
				 
				 return DIALOG_MOVE; } }

		if ( Event.type == sf::Event::MouseButtonReleased && Event.mouseButton.button == sf::Mouse::Right ) { 
			
			sf::Vector2i MousePosition = sf::Mouse::getPosition(Window);
			
			int MouseX = MousePosition.x - X;
			int MouseY = MousePosition.y - Y;

			if ( MousePosition.x >= X && MousePosition.x <= X + Width && 
				 MousePosition.y >= Y && MousePosition.y <= Y + Height ) {

					 Activity = false;
					 InputModified = -1;

					 return DIALOG_CLOSE; } }

		return DIALOG_NONE; }
		
private:

	float Round ( float Number, int Precision ) {

		int NewNumber = Number * Precision * 10;

		return float ( NewNumber * 1.00 / ( Precision * 10 ) ); }

	int CharToInt ( char Char ) {

		int Number = 0;

		if ( Char == '0' ) { Number = 0; }
		if ( Char == '1' ) { Number = 1; }
		if ( Char == '2' ) { Number = 2; }
		if ( Char == '3' ) { Number = 3; }
		if ( Char == '4' ) { Number = 4; }
		if ( Char == '5' ) { Number = 5; }
		if ( Char == '6' ) { Number = 6; }
		if ( Char == '7' ) { Number = 7; }
		if ( Char == '8' ) { Number = 8; }
		if ( Char == '9' ) { Number = 9; }

		return Number; }

	int StringToInt ( string Text ) {
		
		int Number = 0;
		bool Negative = false;

		for ( int i = 0; i < Text.length(); i++ ) {

			if ( Text[i] == '-' && i == 0 ) { 
				
				Negative = true; }

			if ( ( Text[i] == ',' || Text[i] == '.' ) && i != Text.length()-1 ) {

				if ( CharToInt(Text[i+1]) >= 5 ) { 
					
					Number++; }
				
				break; }
			
			Number = Number * 10;
			Number = Number + CharToInt(Text[i]); }

		if ( Negative ) { Number = Number * -1; }
		
		return Number; }

	float StringToFloat ( string Text ) {
		
		float Number = 0;
		int Precision = 0;
		bool Negative = false;

		for ( int i = 0; i < Text.length(); i++ ) {

			if ( Text[i] == '-' && i == 0 ) { 
				
				Negative = true; }
			
			if ( Precision > 0 ) { 
				
				Precision = Precision + 1; }

			if ( Text[i] == ',' || Text[i] == '.' ) { 
				
				Precision = 1; }

			else {

				if ( Precision == 0 ) {

					Number = Number * 10;
					Number = Number + CharToInt(Text[i]); } 
			
				if ( Precision > 0 ) {
					
					Number = Number + Round ( CharToInt(Text[i]), 1 ) / pow ( 10.00, Precision-1 ); } } }

		if ( Negative ) { Number = Number * -1; }
		
		return Number; }

private:

	struct Information {

		int ID;
		int x;
		int y;
		int Width;
		int Height;
		string Text;
		int Orientation; };

	struct Input {

		int ID;
		int x;
		int y;
		int Width;
		int Height;
		string Text;
		string AdditionalText;
		int Type; };

	struct Button {

		int ID;
		int x;
		int y;
		int Width;
		int Height;
		string Text;
		bool Close; };

	struct Checkbox {

		int ID;
		int x;
		int y;
		bool Checked; };

	sf::Font Font;
	sf::Color FillColor;
	sf::Color OutlineColor;
	sf::RenderTexture Render;

	bool Activity;
	bool Modified;

	int X;
	int Y;
	int Width;
	int Height;

	vector <Information> Informations;
	sf::Color InformationsColor;

	vector <Input> Inputs;
	int InputModified;
	bool InputModifiedComma;
	bool InputModifiedMinus;
	int InputsOutlineThickness;
	sf::Color InputsFillColor;
	sf::Color InputsOutlineColor;
	sf::Color InputsTextColor;
	sf::Color InputsModifiedTextColor;

	vector <Button> Buttons;
	sf::Color ButtonsFillColor;
	sf::Color ButtonsOutlineColor;
	int ButtonsOutlineThickness;
	sf::Color ButtonsTextColor;

	vector <Checkbox> Checkboxes;
	sf::Color CheckboxesCheckedColor;
	sf::Color CheckboxesUncheckedColor;
	sf::Color CheckboxesOutlineColor;
	int CheckboxesOutlineThickness; };

// End of definition
#endif