/*
*
*   Copyright (C) 2015 Bartlomiej Zdrojewski
*
*/

#include <SFML/Graphics.hpp>
#include <fstream>
#include <sstream>
#include <string>

using std::fstream;
using std::ios;
using std::stringstream;
using std::string;

typedef double REAL64;
typedef unsigned short int UINT16;

enum Palette {

	Bicolor,
	Monocolor,
	Multicolor

	};

sf::Color MonocolorPalette ( UINT16 Value, UINT16 Maximum, sf::Color Filter = sf::Color( 255, 255, 255 ) ) {

	REAL64 Ratio = (REAL64) ( Value % Maximum ) / (REAL64) Maximum;

	return sf::Color( sf::Uint8( Ratio * Filter.r ), sf::Uint8( Ratio * Filter.g ), sf::Uint8( Ratio * Filter.b ) ); }

sf::Color MulticolorPalette ( UINT16 Value, UINT16 Maximum ) {
	
	REAL64 Ratio = (REAL64) ( Value % Maximum ) / (REAL64) Maximum;

	if ( Ratio < 0.2 ) {

		return sf::Color( 255, sf::Uint8( ( Ratio / 0.2 ) * 255 ), 0 ); }

	else if ( Ratio >= 0.2 && Ratio < 0.4 ) {

		return sf::Color( sf::Uint8( 255 - ( ( Ratio - 0.2 ) / 0.2 ) * 255 ), 255, 0 ); }

	else if ( Ratio >= 0.4 && Ratio < 0.6 ) {

		return sf::Color( 0, 255, sf::Uint8( ( ( Ratio - 0.4 ) / 0.2 ) * 255 ) ); }

	else if ( Ratio >= 0.6 && Ratio < 0.8 ) {

		return sf::Color( 0, sf::Uint8( 255 - ( ( Ratio - 0.6 ) / 0.2 ) * 255 ), 255 ); }

	else if ( Ratio >= 0.8 ) {

		return sf::Color( sf::Uint8( ( ( Ratio - 0.8 ) / 0.2 ) * 255 ), 0, 255 ); }
	
	return sf::Color( 0, 0, 0 ); }

void JuliaSet ( sf::Image &Image, UINT16 Width, UINT16 Height, REAL64 Real, REAL64 Imaginary, UINT16 Iterations, REAL64 Zoom = 1, REAL64 TranslateX = 0, REAL64 TranslateY = 0, Palette ColorMode = Palette::Bicolor, sf::Color ColorFilter = sf::Color( 255, 255, 255 ), UINT16 ColorMaximum = 100 ) {

	Image.create( Width, Height, sf::Color( 0, 0, 0 ) );

	for ( UINT16 x = 0; x < Width; x++ ) {

		for ( UINT16 y = 0; y < Height; y++ ) {

			REAL64 NewReal = 1.5 * ( x - Width / 2 ) / ( 0.5 * Zoom * Width ) + TranslateX;
			REAL64 NewImaginary = ( y - Height / 2 ) / ( 0.5 * Zoom * Height ) + TranslateY;

			UINT16 Iterarion = 0;

			while ( Iterarion < Iterations && ( NewReal * NewReal + NewImaginary * NewImaginary ) <= 4 ) {

				REAL64 OldReal = NewReal;
				REAL64 OldImaginary = NewImaginary;

				NewReal = OldReal * OldReal - OldImaginary * OldImaginary + Real;
				NewImaginary = 2 * OldReal * OldImaginary + Imaginary;

				Iterarion++; }
			
			if ( ColorMode == Palette::Bicolor ) {

				if ( ( NewReal * NewReal + NewImaginary * NewImaginary ) <= 4 ) {

					Image.setPixel( x, y, ColorFilter ); } }

			else if ( ColorMode == Palette::Monocolor ) {

				Image.setPixel( x, y, MonocolorPalette( Iterarion, ColorMaximum + 1, ColorFilter ) ); }

			else if ( ColorMode == Palette::Multicolor ) {

				Image.setPixel( x, y, MulticolorPalette( Iterarion, ColorMaximum + 1 ) ); } } } }

void SaveFractal ( sf::Image &Image ) {
	
	fstream File;
	string FilePath;

	stringstream Stream;
	UINT16 Number = 0;

	do {

		Number++;

		Stream << Number;
		Stream >> FilePath;

		FilePath = "Saves/Fractal " + FilePath + ".png";

		File.close();
		Stream.clear();

		File.open( FilePath, ios::in ); }

	while ( File.is_open() );

	File.close();

	Image.saveToFile( FilePath ); }

UINT16 StringToInt ( string Input ) {

	stringstream Stream;
	UINT16 Output;

	Stream << Input;
	Stream >> Output;

	return Output; }

REAL64 StringToReal ( string Input ) {

	stringstream Stream;
	REAL64 Output;

	Stream << Input;
	Stream >> Output;

	return Output; }

sf::Color StringToColor ( string Input ) {

	sf::Color Output = sf::Color( 0, 0, 0 );

	for ( size_t i = 0; i < 2; i++ ) {

		if ( Input[i] >= 48 && Input[i] <= 57 ) {

			Output.r = Output.r * 16 + Input[i] - 48; }

		else if ( Input[i] >= 97 && Input[i] <= 102 ) {

			Output.r = Output.r * 16 + 10 + Input[i] - 97; }

		else {

			Output.r = Output.r * 16 + 0; } }

	for ( size_t i = 2; i < 4; i++ ) {

		if ( Input[i] >= 48 && Input[i] <= 57 ) {

			Output.g = Output.g * 16 + Input[i] - 48; }

		else if ( Input[i] >= 97 && Input[i] <= 102 ) {

			Output.g = Output.g * 16 + 10 + Input[i] - 97; }

		else {

			Output.g = Output.g * 16 + 0; } }

	for ( size_t i = 4; i < 6; i++ ) {

		if ( Input[i] >= 48 && Input[i] <= 57 ) {

			Output.b = Output.b * 16 + Input[i] - 48; }

		else if ( Input[i] >= 97 && Input[i] <= 102 ) {

			Output.b = Output.b * 16 + 10 + Input[i] - 97; }

		else {

			Output.b = Output.b * 16 + 0; } }

	return Output; }

int main ( ) {

	sf::Image FractalImage;
	sf::Texture FractalTexture;
	sf::Sprite FractalSprite;

	sf::Texture InterfaceTexture;
	sf::Sprite InterfaceSprite;
	sf::Font InterfaceFont;
	sf::Text InterfaceText [9];

	REAL64 Real = -0.70;
	REAL64 Imaginary = 0.27015;
	UINT16 Iterations = 200;
	REAL64 Zoom = 1.00;
	REAL64 TranslateX = 0.00;
	REAL64 TranslateY = 0.00;
	Palette ColorMode = Palette::Monocolor;
	sf::Color ColorFilter = sf::Color( 255, 255, 255 );
	UINT16 ColorMaximum = 200;

	sf::Clock IterationClock;
	sf::Time IterationTime = sf::milliseconds( 100 );
	UINT16 Iteration = Iterations;

	bool FractalUpdate = true;
	bool InterfaceUpdate = true;
	UINT16 Selected = 9;

	if ( InterfaceTexture.loadFromFile( "Data/Interface.png" ) ) {

		InterfaceSprite.setTexture( InterfaceTexture );
		InterfaceSprite.setPosition( 700, 0 ); }

	else {

		fstream File( "Crash.txt", ios::app );

		File << "[CRASH] Failed to load file \"Data\\Interface.png\".\n";
		File.close();

		return 0; }

	if ( InterfaceFont.loadFromFile( "Data/Font.ttf" ) ) {

		for ( size_t i = 0; i < 9; i++ ) {

			InterfaceText[i].setFont( InterfaceFont );
			InterfaceText[i].setColor( sf::Color( 34, 34, 34 ) );
			InterfaceText[i].setCharacterSize( 15 ); }

		InterfaceText[0].setPosition( 820, 25 );
		InterfaceText[0].setString( "-0.7" );
		
		InterfaceText[1].setPosition( 820, 67 );
		InterfaceText[1].setString( "0.27015" );

		InterfaceText[2].setPosition( 820, 110 );
		InterfaceText[2].setString( "200" );

		InterfaceText[3].setPosition( 820, 175 );
		InterfaceText[3].setString( "1.00" );

		InterfaceText[4].setPosition( 820, 217 );
		InterfaceText[4].setString( "0.00" );

		InterfaceText[5].setPosition( 820, 260 );
		InterfaceText[5].setString( "0.00" );

		InterfaceText[6].setPosition( 841, 325 );
		InterfaceText[6].setString( "Monocolor" );

		InterfaceText[7].setPosition( 820, 367 );
		InterfaceText[7].setString( "ffffff" );

		InterfaceText[8].setPosition( 820, 410 );
		InterfaceText[8].setString( "200" ); }

	else {

		fstream File( "Crash.txt", ios::app );

		File << "[CRASH] Failed to load file \"Data\\Font.ttf\".\n";
		File.close();

		return 0; }

	sf::RenderWindow Window ( sf::VideoMode( 950, 525 ), L"Fraktal - Zbi�r Julii", sf::Style::Close );

	while ( Window.isOpen() ) {

		sf::Event Event;

		while ( Window.pollEvent( Event ) ) {

			if ( Event.type == sf::Event::MouseButtonReleased && Event.mouseButton.button == sf::Mouse::Left ) {

				sf::Vector2i MousePosition = sf::Mouse::getPosition( Window );

				if ( MousePosition.x >= 815 && MousePosition.x <= 938 && MousePosition.y >= 19 && MousePosition.y <= 44 ) {

					Selected = 0; }

				else if ( MousePosition.x >= 815 && MousePosition.x <= 938 && MousePosition.y >= 61 && MousePosition.y <= 86 ) {

					Selected = 1; }

				else if ( MousePosition.x >= 815 && MousePosition.x <= 938 && MousePosition.y >= 104 && MousePosition.y <= 129 ) {

					if ( MousePosition.x >= 918 && MousePosition.x <= 936 && MousePosition.y >= 109 && MousePosition.y <= 123 ) {
						
						if ( InterfaceText[2].getString().getSize() == 0 ) {

							InterfaceUpdate = true;
							FractalUpdate = true;

							InterfaceText[2].setString( "0" ); }

						Iteration = 0; }

					Selected = 2; }

				else if ( MousePosition.x >= 815 && MousePosition.x <= 938 && MousePosition.y >= 169 && MousePosition.y <= 194 ) {

					Selected = 3; }

				else if ( MousePosition.x >= 815 && MousePosition.x <= 938 && MousePosition.y >= 122 && MousePosition.y <= 236 ) {

					Selected = 4; }

				else if ( MousePosition.x >= 815 && MousePosition.x <= 938 && MousePosition.y >= 254 && MousePosition.y <= 279 ) {

					Selected = 5; }

				else if ( MousePosition.x >= 818 && MousePosition.x <= 836 && MousePosition.y >= 324 && MousePosition.y <= 338 ) {
					
					if ( InterfaceText[6].getString() == "Bicolor" ) {

						InterfaceText[6].setPosition( 837, 325 );
						InterfaceText[6].setString( "Multicolor" ); }

					else if ( InterfaceText[6].getString() == "Monocolor" ) {

						InterfaceText[6].setPosition( 849, 325 );
						InterfaceText[6].setString( "Bicolor" ); }

					else if ( InterfaceText[6].getString() == "Multicolor" ) {

						InterfaceText[6].setPosition( 841, 325 );
						InterfaceText[6].setString( "Monocolor" ); }
					
					InterfaceUpdate = true; }

				else if ( MousePosition.x >= 913 && MousePosition.x <= 931 && MousePosition.y >= 324 && MousePosition.y <= 338 ) {
					
					if ( InterfaceText[6].getString() == "Bicolor" ) {

						InterfaceText[6].setPosition( 841, 325 );
						InterfaceText[6].setString( "Monocolor" ); }

					else if ( InterfaceText[6].getString() == "Monocolor" ) {

						InterfaceText[6].setPosition( 837, 325 );
						InterfaceText[6].setString( "Multicolor" ); }

					else if ( InterfaceText[6].getString() == "Multicolor" ) {

						InterfaceText[6].setPosition( 849, 325 );
						InterfaceText[6].setString( "Bicolor" ); }
					
					InterfaceUpdate = true; }

				else if ( MousePosition.x >= 815 && MousePosition.x <= 938 && MousePosition.y >= 361 && MousePosition.y <= 386 ) {

					Selected = 7; }

				else if ( MousePosition.x >= 815 && MousePosition.x <= 938 && MousePosition.y >= 404 && MousePosition.y <= 429 ) {

					Selected = 8; }

				else if ( MousePosition.x >= 711 && MousePosition.x <= 938 && MousePosition.y >= 461 && MousePosition.y <= 481 ) {

					Iteration = Iterations;
					InterfaceUpdate = true;
					FractalUpdate = true;

					Selected = 9; }

				else if ( MousePosition.x >= 711 && MousePosition.x <= 938 && MousePosition.y >= 493 && MousePosition.y <= 513 ) {

					SaveFractal( FractalImage );

					Selected = 9; }
				
				else {

					Selected = 9; } }

			if ( Event.type == sf::Event::KeyReleased && Event.key.code == sf::Keyboard::BackSpace ) {

				if ( Selected >= 0 && Selected <= 8 ) {

					if ( InterfaceText[ Selected ].getString().getSize() > 0 ) {

						InterfaceText[ Selected ].setString( InterfaceText[ Selected ].getString().substring( 0, InterfaceText[ Selected ].getString().getSize() - 1 ) );
						
						if ( Selected == 2 ) {

							if ( InterfaceText[2].getString().getSize() == 0 ) {

								Iteration = 0;
								Iterations = 0; }

							else {

								Iteration = StringToInt( InterfaceText[2].getString() );
								Iterations = StringToInt( InterfaceText[2].getString() ); } }

						if ( InterfaceText[ Selected ].getString().getSize() > 0 && Selected != 7 ) {

							if ( InterfaceText[ Selected ].getString()[ InterfaceText[ Selected ].getString().getSize() - 1 ] != '.' ) {

								InterfaceUpdate = true; } } } } }

			if ( Event.type == sf::Event::TextEntered ) {

				if ( Event.text.unicode == 45 ) {

					if ( Selected == 0 ) {

						if ( InterfaceText[0].getString().getSize() == 0 ) {

							InterfaceText[0].setString( InterfaceText[0].getString() + static_cast <char> ( Event.text.unicode ) );
							
							InterfaceUpdate = true; } }

					if ( Selected == 1 ) {

						if ( InterfaceText[1].getString().getSize() == 0 ) {

							InterfaceText[1].setString( InterfaceText[1].getString() + static_cast <char> ( Event.text.unicode ) );
							
							InterfaceUpdate = true; } }
					
					if ( Selected == 4 ) {

						if ( InterfaceText[4].getString().getSize() == 0 ) {

							InterfaceText[4].setString( InterfaceText[4].getString() + static_cast <char> ( Event.text.unicode ) );
							
							InterfaceUpdate = true; } }

					if ( Selected == 5 ) {

						if ( InterfaceText[5].getString().getSize() == 0 ) {

							InterfaceText[5].setString( InterfaceText[5].getString() + static_cast <char> ( Event.text.unicode ) );
							
							InterfaceUpdate = true; } } }

				if ( Event.text.unicode == 44 || Event.text.unicode == 46 ) {

					if ( Selected == 0 ) {

						if ( InterfaceText[0].getString().getSize() > 0 && InterfaceText[0].getString().getSize() < 13 && InterfaceText[0].getString().find( "." ) == sf::String::InvalidPos ) {

							if ( InterfaceText[0].getString()[ InterfaceText[0].getString().getSize() - 1 ] != '-' ) {

								InterfaceText[0].setString( InterfaceText[0].getString() + '.' ); } } }

					if ( Selected == 1 ) {

						if ( InterfaceText[1].getString().getSize() > 0 && InterfaceText[1].getString().getSize() < 13 && InterfaceText[1].getString().find( "." ) == sf::String::InvalidPos ) {

							if ( InterfaceText[1].getString()[ InterfaceText[1].getString().getSize() - 1 ] != '-' ) {

								InterfaceText[1].setString( InterfaceText[1].getString() + '.' ); } } }

					if ( Selected == 3 ) {

						if ( InterfaceText[3].getString().getSize() > 0 && InterfaceText[3].getString().getSize() < 13 && InterfaceText[3].getString().find( "." ) == sf::String::InvalidPos ) {

							InterfaceText[3].setString( InterfaceText[3].getString() + '.' ); } }

					if ( Selected == 4 ) {

						if ( InterfaceText[4].getString().getSize() > 0 && InterfaceText[4].getString().getSize() < 13 && InterfaceText[4].getString().find( "." ) == sf::String::InvalidPos ) {

							if ( InterfaceText[4].getString()[ InterfaceText[4].getString().getSize() - 1 ] != '-' ) {

								InterfaceText[4].setString( InterfaceText[4].getString() + '.' ); } } }

					if ( Selected == 5 ) {

						if ( InterfaceText[5].getString().getSize() > 0 && InterfaceText[5].getString().getSize() < 13 && InterfaceText[5].getString().find( "." ) == sf::String::InvalidPos ) {

							if ( InterfaceText[5].getString()[ InterfaceText[5].getString().getSize() - 1 ] != '-' ) {
								
								InterfaceText[5].setString( InterfaceText[5].getString() + '.' ); } } } }

				if ( Event.text.unicode >= 48 && Event.text.unicode <= 57 ) {

					if ( Selected == 0 ) {

						if ( InterfaceText[0].getString().getSize() < 14 ) {

							InterfaceText[0].setString( InterfaceText[0].getString() + static_cast <char> ( Event.text.unicode ) );
							
							InterfaceUpdate = true; } }

					if ( Selected == 1 ) {

						if ( InterfaceText[1].getString().getSize() < 14 ) {

							InterfaceText[1].setString( InterfaceText[1].getString() + static_cast <char> ( Event.text.unicode ) );
							
							InterfaceUpdate = true; } }

					if ( Selected == 2 ) {

						if ( InterfaceText[2].getString().getSize() < 12 ) {

							InterfaceText[2].setString( InterfaceText[2].getString() + static_cast <char> ( Event.text.unicode ) );
							
							Iteration = StringToInt( InterfaceText[2].getString() );
							Iterations = StringToInt( InterfaceText[2].getString() );

							InterfaceUpdate = true; } }

					if ( Selected == 3 ) {

						if ( InterfaceText[3].getString().getSize() < 14 ) {

							InterfaceText[3].setString( InterfaceText[3].getString() + static_cast <char> ( Event.text.unicode ) );
							
							InterfaceUpdate = true; } }

					if ( Selected == 4 ) {

						if ( InterfaceText[4].getString().getSize() < 14 ) {

							InterfaceText[4].setString( InterfaceText[4].getString() + static_cast <char> ( Event.text.unicode ) );
							
							InterfaceUpdate = true; } }

					if ( Selected == 5 ) {

						if ( InterfaceText[5].getString().getSize() < 14 ) {

							InterfaceText[5].setString( InterfaceText[5].getString() + static_cast <char> ( Event.text.unicode ) );
							
							InterfaceUpdate = true; } }

					if ( Selected == 7 ) {

						if ( InterfaceText[7].getString().getSize() < 6 ) {

							InterfaceText[7].setString( InterfaceText[7].getString() + static_cast <char> ( Event.text.unicode ) );
							
							if ( InterfaceText[7].getString().getSize() == 6 ) {

								InterfaceUpdate = true; } } }

					if ( Selected == 8 ) {

						if ( InterfaceText[8].getString().getSize() < 14 ) {

							InterfaceText[8].setString( InterfaceText[8].getString() + static_cast <char> ( Event.text.unicode ) );
							
							InterfaceUpdate = true; } } }

				if ( Event.text.unicode >= 97 && Event.text.unicode <= 102 ) {

					if ( Selected == 7 ) {

						if ( InterfaceText[7].getString().getSize() < 6 ) {

							InterfaceText[7].setString( InterfaceText[7].getString() + static_cast <char> ( Event.text.unicode ) );
							
							if ( InterfaceText[7].getString().getSize() == 6 ) {

								InterfaceUpdate = true; } } } } }

			if ( Event.type == sf::Event::Closed ) {

				Window.close(); } }
		
		Window.clear();

		if ( InterfaceUpdate ) {

			if ( InterfaceText[0].getString().getSize() == 0 ) {

				InterfaceText[0].setString( "0.00" ); }

			if ( InterfaceText[0].getString()[ InterfaceText[0].getString().getSize() - 1 ] == '.' ) {

				InterfaceText[0].setString( InterfaceText[0].getString() + "0" ); }

			if ( InterfaceText[1].getString().getSize() == 0 ) {

				InterfaceText[1].setString( "0.00" ); }

			if ( InterfaceText[1].getString()[ InterfaceText[1].getString().getSize() - 1 ] == '.' ) {

				InterfaceText[1].setString( InterfaceText[1].getString() + "0" ); }

			if ( InterfaceText[2].getString().getSize() == 0 ) {

				InterfaceText[2].setString( "0" ); }

			if ( InterfaceText[3].getString().getSize() == 0 ) {

				InterfaceText[3].setString( "1.00" ); }

			if ( InterfaceText[3].getString()[ InterfaceText[3].getString().getSize() - 1 ] == '.' ) {

				InterfaceText[3].setString( InterfaceText[3].getString() + "0" ); }

			if ( InterfaceText[4].getString().getSize() == 0 ) {

				InterfaceText[4].setString( "0.00" ); }

			if ( InterfaceText[4].getString()[ InterfaceText[4].getString().getSize() - 1 ] == '.' ) {

				InterfaceText[4].setString( InterfaceText[4].getString() + "0" ); }

			if ( InterfaceText[5].getString().getSize() == 0 ) {

				InterfaceText[5].setString( "0.00" ); }

			if ( InterfaceText[5].getString()[ InterfaceText[5].getString().getSize() - 1 ] == '.' ) {

				InterfaceText[5].setString( InterfaceText[5].getString() + "0" ); }

			if ( InterfaceText[7].getString().getSize() < 6 ) {

				InterfaceText[7].setString( InterfaceText[7].getString() + sf::String( "ffffff" ).substring( InterfaceText[7].getString().getSize() ) ); }

			if ( InterfaceText[8].getString().getSize() == 0 ) {

				InterfaceText[8].setString( "0" ); }

			Real = StringToReal( InterfaceText[0].getString() );
			Imaginary = StringToReal( InterfaceText[1].getString() );
			Iterations = StringToInt( InterfaceText[2].getString() );
			Zoom = StringToReal( InterfaceText[3].getString() );
			TranslateX = StringToReal( InterfaceText[4].getString() );
			TranslateY = StringToReal( InterfaceText[5].getString() );
			ColorFilter = StringToColor( InterfaceText[7].getString() );
			ColorMaximum = StringToInt( InterfaceText[8].getString() );

			if ( InterfaceText[6].getString() == "Bicolor" ) {

				ColorMode = Palette::Bicolor; }

			else if ( InterfaceText[6].getString() == "Monocolor" ) {

				ColorMode = Palette::Monocolor; }

			else if ( InterfaceText[6].getString() == "Multicolor" ) {

				ColorMode = Palette::Multicolor; }

			InterfaceUpdate = false; }

		if ( FractalUpdate ) {
			
			JuliaSet( FractalImage, 700, 525, Real, Imaginary, Iterations, Zoom, TranslateX, TranslateY, ColorMode, ColorFilter, ColorMaximum );

			FractalTexture.loadFromImage( FractalImage );
			FractalSprite.setTexture( FractalTexture );
			
			FractalUpdate = false; }

		if ( Iteration < Iterations && IterationClock.getElapsedTime() > IterationTime ) {
			
			JuliaSet( FractalImage, 700, 525, Real, Imaginary, Iteration, Zoom, TranslateX, TranslateY, ColorMode, ColorFilter, ColorMaximum );
			
			FractalTexture.loadFromImage( FractalImage );
			FractalSprite.setTexture( FractalTexture );

			Iteration++;
			IterationClock.restart(); }

		Window.draw( FractalSprite );
		Window.draw( InterfaceSprite );

		for ( size_t i = 0; i < 9; i++ ) {

			Window.draw( InterfaceText[i] ); }

		Window.display(); } }