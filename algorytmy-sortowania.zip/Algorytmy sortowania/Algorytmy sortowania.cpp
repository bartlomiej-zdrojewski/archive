//
//  Title:  Sorting algorithms - practical side
//  Author: Bartlomiej Zdrojewski
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <ctime>
#include <conio.h>

using namespace std;

typedef unsigned char UINT8;
typedef signed char INT8;
typedef unsigned short int UINT16;
typedef signed short int INT16;
typedef unsigned long int UINT32;
typedef signed long int INT32;
typedef unsigned long long int UINT64;
typedef signed long long int INT64;
typedef float REAL32;
typedef double REAL64;

struct Input {

	enum Type {

		Console,
		File,
		Random
		
		}; };

struct Sort {

	enum Type {

		Bubble,
		Insertion,
		Selection,
		Counting,
		Merge,
		Heap,
		Quick
		
		}; };

struct Output {
	
	enum Type {

		Console,
		File

		}; };

struct Command {

	enum Type {

		None,
		Help,
		Select,

		}; };

bool Menu ( Input::Type &InputType, Sort::Type &SortType, Output::Type &OutputType, Command::Type &CommandType, INT8 &Cursor );
void Results ( Sort::Type SortType, clock_t Start, clock_t Stop );
void Clear ( );

void Swap ( INT64 &A, INT64 &B );
INT64 Min ( INT64 * Data, UINT64 Size );
INT64 Max ( INT64 * Data, UINT64 Size );

void BubbleSort ( INT64 * Data, UINT64 Size );
void InsertionSort ( INT64 * Data, UINT64 Size );
void SelectionSort ( INT64 * Data, UINT64 Size );
void CountingSort ( INT64 * Data, UINT64 Size );
void MergeSort ( INT64 * Data, UINT64 Left, UINT64 Right );
void HeapSort ( INT64 * Data, UINT64 Size );
void QuickSort ( INT64 * Data, UINT64 Left, UINT64 Right );

int main ( ) {
    
	bool Finish = false;
	INT8 Cursor = 12;

	Input::Type InputType = Input::Console;
	Sort::Type SortType = Sort::Bubble;
	Output::Type OutputType = Output::Console;
	Command::Type CommandType = Command::None;

	do {
		
		Menu( InputType, SortType, OutputType, CommandType, Cursor );

		do {

			switch ( _getch() ) {

				case ',': {
					
					Cursor--;

					break; }

				case '.': {
					
					Cursor++;

					break; }

				case '/': {

					CommandType = Command::Help;

					break; }

				case 13: {

					CommandType = Command::Select;

					break; } } }

		while ( Menu( InputType, SortType, OutputType, CommandType, Cursor ) );

		if ( Cursor != 13 ) {

			UINT64 Size = 64;
			INT64 * Data = new INT64 [64];

			if ( InputType == Input::Console ) {

				cout << "\n ALGORYTMY SORTOWANIA - STRONA PRAKTYCZNA\n";

				cout << "\n  Ilosc elementow:\n\n   ";
				cin >> Size;

				cout << "\n  Elementy:\n\n";
				Data = new INT64 [ (size_t) Size ];

				for ( UINT64 i = 0; i < Size; i++ ) {

					cout << "   [" << i << "]: ";
					cin >> Data[i]; } }

			if ( InputType == Input::File ) {

				fstream File;
				string FileName, FileLine;
				vector <INT64> FileData;				

				while ( !File.is_open() ) {

					Clear();

					cout << "\n ALGORYTMY SORTOWANIA - STRONA PRAKTYCZNA\n";
					
					cout << "\n  Nazwa pliku wejscia:\n\n   ";
					cin >> FileName;

					File.open( FileName.c_str(), ios::in );

					if ( !File.is_open() ) {

						cout << "\n  Podany plik nie istnieje. Sprawdz czy podales wlasciwe rozszerzenie pliku.";
						_getch(); } }

				while ( getline( File, FileLine ) ) {

					stringstream Stream;
					INT64 Value;

					Stream << FileLine;
					Stream >> Value;

					FileData.push_back( Value ); }

				Size = FileData.size();
				Data = new INT64 [ (size_t) Size ];

				for ( UINT64 i = 0; i < Size; i++ ) {

					Data[ (size_t) i ] = FileData[ (size_t) i ]; }

				File.close(); }

			if ( InputType == Input::Random ) {

				INT64 Minimum;
				INT64 Maximum;

				cout << "\n ALGORYTMY SORTOWANIA - STRONA PRAKTYCZNA\n";

				cout << "\n  Ilosc elementow:\n\n   ";
				cin >> Size;

				cout << "\n  Wartosc minimalna:\n\n   ";
				cin >> Minimum;

				cout << "\n  Wartosc maksymalna:\n\n   ";
				cin >> Maximum;

				if ( Minimum > Maximum ) {

					Swap( Minimum, Maximum ); }

				srand( (UINT32) time( NULL ) );
				Data = new INT64 [ (size_t) Size ];

				for ( UINT64 i = 0; i < Size; i++ ) {

					Data[i] = Minimum + ( rand() % (UINT32) ( Maximum - Minimum + 1 ) ); } }
			
			Clear();

			cout << "\n ALGORYTMY SORTOWANIA - STRONA PRAKTYCZNA\n";
			cout << "\n  Sortowanie...";

			clock_t Start = clock();

			switch ( SortType ) {

				case Sort::Bubble: {

					BubbleSort( Data, Size );

					break; }

				case Sort::Insertion: {

					InsertionSort( Data, Size );

					break; }

				case Sort::Selection: {

					SelectionSort( Data, Size );

					break; }

				case Sort::Counting: {

					CountingSort( Data, Size );

					break; }

				case Sort::Merge: {

					MergeSort( Data, 0, Size - 1 );

					break; }

				case Sort::Heap: {

					HeapSort( Data, Size );

					break; }

				case Sort::Quick: {

					QuickSort( Data, 0, Size );

					break; } }

			clock_t Stop = clock();

			Clear();

			if ( OutputType == Output::Console ) {

				Results( SortType, Start, Stop );

				cout << "\n\n  Wynik sortowania:\n";

				for ( UINT64 i = 0; i < Size; i++ ) {

					cout << "\n   [" << i << "]: " << Data[ (size_t) i ]; } }

			if ( OutputType == Output::File ) {
				
				fstream File;
				string FileName;

				while ( !File.is_open() ) {

					Clear();

					cout << "\n ALGORYTMY SORTOWANIA - STRONA PRAKTYCZNA\n";
					
					cout << "\n  Nazwa pliku wyjscia:\n\n   ";
					cin >> FileName;

					File.open( FileName.c_str(), ios::out );

					if ( !File.is_open() ) {

						cout << "\n  Nie mozna stworzyc danego pliku. Sprawdz zgodnosc nazwy ze standardem.";
						
						_getch(); } }
				
				Clear();

				cout << "\n ALGORYTMY SORTOWANIA - STRONA PRAKTYCZNA\n";
				cout << "\n  Zapisywanie...";

				for ( UINT64 i = 0; i < Size; i++ ) {

					File << Data[i] << endl; }

				Clear();

				Results( SortType, Start, Stop );

				File.close(); }

			delete Data;

			_getch(); }

		else {

			Finish = true; } }

	while ( !Finish );

	return 0; }

bool Menu ( Input::Type &InputType, Sort::Type &SortType, Output::Type &OutputType, Command::Type &CommandType, INT8 &Cursor ) {

	Clear();

	if ( Cursor < 0 ) {
		
		Cursor = 0; }

	if ( Cursor > 13 ) {

		Cursor = 13; }
	
	if ( CommandType == Command::Help ) {

		switch ( Cursor ) {

			case 3: {
				
				system( "start http://pl.wikipedia.org/wiki/Sortowanie_b%C4%85belkowe" );
				
				break; }

			case 4: {
				
				system( "start http://pl.wikipedia.org/wiki/Sortowanie_przez_wstawianie" );
				
				break; }

			case 5: {
				
				system( "start http://pl.wikipedia.org/wiki/Sortowanie_przez_wybieranie" );
				
				break; }

			case 6: {
				
				system( "start http://pl.wikipedia.org/wiki/Sortowanie_przez_zliczanie" );
				
				break; }

			case 7: {
				
				system( "start http://pl.wikipedia.org/wiki/Sortowanie_przez_scalanie" );

				break; }

			case 8: {
				
				system( "start http://pl.wikipedia.org/wiki/Sortowanie_przez_kopcowanie" );
				
				break; }

			case 9: {
				
				system( "start http://pl.wikipedia.org/wiki/Sortowanie_szybkie" );
				
				break; } }

		CommandType = Command::None; }

	if ( CommandType == Command::Select ) {

		switch ( Cursor ) {

			case 0: {
				
				InputType = Input::Console;
				
				break; }

			case 1: {
				
				InputType = Input::File;
				
				break; }

			case 2: {
				
				InputType = Input::Random;
				
				break; }

			case 3: {
				
				SortType = Sort::Bubble;
				
				break; }

			case 4: {
				
				SortType = Sort::Insertion;
				
				break; }

			case 5: {
				
				SortType = Sort::Selection;
				
				break; }

			case 6: {
				
				SortType = Sort::Counting;
				
				break; }

			case 7: {
				
				SortType = Sort::Merge;

				break; }

			case 8: {
				
				SortType = Sort::Heap;

				break; }

			case 9: {
				
				SortType = Sort::Quick;
				
				break; }

			case 10: {
				
				OutputType = Output::Console;
				
				break; }

			case 11: {
				
				OutputType = Output::File;
				
				break; }

			case 12: {
				
				CommandType = Command::None;

				return false;
				
				break; }
			
			case 13: {

				CommandType = Command::None;

				return false;
				
				break; } }
		
		CommandType = Command::None; }

	cout << "\n ALGORYTMY SORTOWANIA - STRONA PRAKTYCZNA\n\n  Wejscie danych:            Wyjscie danych:\n";

	if ( Cursor == 0 ) {

		cout << "\n   > Konsola"; }

	else if ( InputType == Input::Console ) {

		cout << "\n   + Konsola"; }

	else {

		cout << "\n   - Konsola"; }

	if ( Cursor == 10 ) {

		cout << "                  > Konsola"; }

	else if ( OutputType == Output::Console ) {

		cout << "                  + Konsola"; }

	else {

		cout << "                  - Konsola"; }

	if ( Cursor == 1 ) {

		cout << "\n   > Plik"; }

	else if ( InputType == Input::File ) {

		cout << "\n   + Plik"; }

	else {

		cout << "\n   - Plik"; }

	if ( Cursor == 11 ) {
		
		cout << "                     > Plik"; }

	else if ( OutputType == Output::File ) {

		cout << "                     + Plik"; }

	else {

		cout << "                     - Plik"; }

	if ( Cursor == 2 ) {

		cout << "\n   > Losowe"; }

	else if ( InputType == Input::Random ) {

		cout << "\n   + Losowe"; }

	else {

		cout << "\n   - Losowe"; }

	cout << "\n                             Sterowanie:\n  Algorytm sortowania:";

	if ( Cursor == 12 ) {

		cout << "\n                              > Rozpocznij"; }

	else {

		cout << "\n                              - Rozpocznij"; }

	if ( Cursor == 3 ) {
		
		cout << "\n   > Babelkowe"; }

	else if ( SortType == Sort::Bubble ) {

		cout << "\n   + Babelkowe"; }

	else {

		cout << "\n   - Babelkowe"; }

	if ( Cursor == 13 ) {

		cout << "                > Zakoncz"; }

	else {

		cout << "                - Zakoncz"; }

	if ( Cursor == 4 ) {
		
		cout << "\n   > Przez wstawianie"; }

	else if ( SortType == Sort::Insertion ) {

		cout << "\n   + Przez wstawianie"; }

	else {

		cout << "\n   - Przez wstawianie"; }

	if ( Cursor == 5 ) {
		
		cout << "\n   > Przez wybieranie"; }

	else if ( SortType == Sort::Selection ) {

		cout << "\n   + Przez wybieranie"; }

	else {

		cout << "\n   - Przez wybieranie"; }

	if ( Cursor == 6 ) {
		
		cout << "\n   > Przez zliczanie"; }

	else if ( SortType == Sort::Counting ) {

		cout << "\n   + Przez zliczanie"; }

	else {

		cout << "\n   - Przez zliczanie"; }

	if ( Cursor == 7 ) {
		
		cout << "\n   > Przez scalanie"; }

	else if ( SortType == Sort::Merge ) {

		cout << "\n   + Przez scalanie"; }

	else {

		cout << "\n   - Przez scalanie"; }

	if ( Cursor == 8 ) {
		
		cout << "\n   > Przez kopcowanie"; }

	else if ( SortType == Sort::Heap ) {

		cout << "\n   + Przez kopcowanie"; }

	else {

		cout << "\n   - Przez kopcowanie"; }

	if ( Cursor == 9 ) {
		
		cout << "\n   > Szybkie"; }

	else if ( SortType == Sort::Quick ) {

		cout << "\n   + Szybkie"; }

	else {

		cout << "\n   - Szybkie"; }

	cout << "\n\n  -----------------------------------\n    <   - poprzednia opcja\n    >   - nastepna opcja\n  ENTER - wybor opcji\n    ?   - informacje o sortowaniu";

	return true; }

void Results ( Sort::Type SortType, clock_t Start, clock_t Stop ) {
	
	cout << "\n ALGORYTMY SORTOWANIA - STRONA PRAKTYCZNA\n";
	cout << "\n  Algorytm sortowania:\n\n   ";

	switch ( SortType ) {

		case Sort::Bubble: {
						
			cout << "Babelkowe";
			
			break; }

		case Sort::Insertion: {
						
			cout << "Przez wstawianie";

			break; }

		case Sort::Selection: {
						
			cout << "Przez wybieranie";

			break; }

		case Sort::Counting: {
						
			cout << "Przez zliczanie";

			break; }

		case Sort::Merge: {
						
			cout << "Przez scalanie";

			break; }

		case Sort::Heap: {
						
			cout << "Przez kopcowanie";

			break; }

		case Sort::Quick: {
						
			cout << "Szybkie";

			break; } }

	cout << "\n\n  Czas sortowania:\n\n   ";
	cout << (REAL32) ( (REAL32) ( Stop - Start ) / (REAL32) CLOCKS_PER_SEC ) << " sekund"; }

void Clear ( ) {

	system( "cls" );
	system( "color 7" ); }

void Swap ( INT64 &A, INT64 &B ) {

	INT64 C = A;

	A = B;
	B = C; }

INT64 Min ( INT64 * Data, UINT64 Size ) {

	if ( Size > 0 ) {

		INT64 Minimum = Data[0];

		for ( UINT64 i = 1; i < Size; i++  ) {

			if ( Data[i] < Minimum ) {

				Minimum = Data[i]; } }

		return Minimum; }

	else {

		return 0; } }

INT64 Max ( INT64 * Data, UINT64 Size ) {

	if ( Size > 0 ) {

		INT64 Maximum = Data[0];

		for ( UINT64 i = 1; i < Size; i++  ) {

			if ( Data[i] > Maximum ) {

				Maximum = Data[i]; } }

		return Maximum; }

	else {

		return 0; } }

void BubbleSort ( INT64 * Data, UINT64 Size ) {

	// ALGORYTM KLASYCZNY

	for ( UINT64 i = Size; i > 1; i-- ) {

		for ( UINT64 j = 0; j < i; j++ ) {

			if ( Data[j] > Data[j+1] ) {

				Swap( Data[j], Data[j+1] ); } } }	

	/*

	// ALGORYTM ZOPTYMALIZOWANY

	bool Change;

	for ( UINT64 i = Size; i > 1; i-- ) {
		
		Change = false;

		for ( UINT64 j = 0; j < i; j++ ) {

			if ( Data[j] > Data[j+1] ) {

				Swap( Data[j], Data[j+1] );
				
				Change = true; } }
		
		if ( !Change ) {
			
			break; } }
	
	*/

	}

void InsertionSort ( INT64 * Data, UINT64 Size ) {

	for( UINT64 i = 1; i < Size; i++ ) {

		INT64 Value = Data[i];
		UINT64 j;

		for ( j = i; j > 0; j-- ) {

			if ( Data[j-1] > Value ) {

				Data[j] = Data[j-1]; }

			else {

				break; }

			Data[j-1] = Value; } } }

void SelectionSort ( INT64 * Data, UINT64 Size ) {

	for ( UINT64 i = 0; i < Size; i++ ) {

		UINT64 Minimum = i;

		for ( UINT64 j = ( i + 1 ); j < Size; j++ ) {

			if ( Data[j] < Data[ Minimum ] ) {

				Minimum = j; } }

		Swap( Data[i], Data[ Minimum ] ); } }

void CountingSort ( INT64 * Data, UINT64 Size ) {

	INT64 Minimum = Min( Data, Size );
	INT64 Maximum = Max( Data, Size );
	UINT64 Range = Maximum - Minimum + 1;
	UINT64 Element = 0;

	UINT64 * Amount = new UINT64 [ (size_t) Range ];

	for ( UINT64 i = 0; i < Range; i++ ) {

		Amount[i] = 0; }

	for ( UINT64 i = 0; i < Size; i++ ) {

		Amount[ Data[i] - Minimum ]++; }

	for ( UINT64 i = 0; i < Range; i++ ) {

		while( Amount[i] > 0 ) {

			Data[ Element ] = (INT64) i + Minimum;
			
			Element++;
			Amount[i]--; } } }

void MergeSort ( INT64 * Data, UINT64 Left, UINT64 Right ) {
	
	INT64 * Temp = new INT64 [ (size_t) ( Right - Left + 1 ) ];
	UINT64 Division = ( Left + Right + 1 ) / 2;

	if ( ( Division - Left ) > 1 ) {
		
		MergeSort( Data, Left, Division - 1 ); }

	if ( ( Right - Division ) > 0 ) {
		
		MergeSort( Data, Division, Right ); }
	
	UINT64 j = Left;
	UINT64 k = Division;
	
	for( UINT64 i = 0; i < ( Right - Left + 1 ); i++ ) {

		if ( ( j == Division ) || ( ( k <= Right ) && ( Data[j] > Data[k] ) ) ) {

			Temp[i] = Data[k];
			
			k++; }

		else {

			Temp[i] = Data[j];
			
			j++; } }
	
	for( UINT64 i = 0; i < ( Right - Left + 1 ); i++ ) {
		
		Data[ i + Left ] = Temp[i]; } }

void HeapSort ( INT64 * Data, UINT64 Size ) {
	
	for ( UINT64 i = 1; i < Size; i++ ) {

		UINT64 Son = i;
		UINT64 Parent = ( i - 1 ) / 2;
		INT64 Value = Data[i];

		while ( Son > 0 ) {

			if ( Data[ Parent ] < Value ) {

				Data[ Son ] = Data[ Parent ];

				Son = Parent;
				Parent = ( Son - 1 ) / 2; }
			
			else { 
				
				break; } }

		Data[ Son ] = Value; }

	for ( UINT64 i = ( Size - 1 ); i > 0; i-- ) {

		Swap( Data[0], Data[i] );

		UINT64 Parent = 0;
		UINT64 Son = 1;
		UINT64 Next;

		while ( Son < i ) {

			if ( ( Son + 1 ) < i && Data[ Son + 1 ] > Data[ Son ] ) {

				Next = Son + 1; }

			else {

				Next = Son; }

			if ( Data[ Next ] <= Data[ Parent ] ) {

				break; }

			Swap( Data[ Parent ], Data[ Next ] );

			Parent = Next;
			Son = 2 * Parent + 1; } } }

void QuickSort ( INT64 * Data, UINT64 Left, UINT64 Right ) {
	
    if( Left < Right ) {
        
		INT64 Value = Data[ Left ];
		UINT64 i = Left;
		UINT64 j = Left + 1;

		while ( j < Right ) {

			if( Data[j] <= Value ) {
				
				i++;

				Swap( Data[i], Data[j] ); }

			j++; }

    Swap( Data[i], Data[ Left ] );
	
	QuickSort( Data, Left, i );  
	QuickSort( Data, i + 1, Right ); } }
