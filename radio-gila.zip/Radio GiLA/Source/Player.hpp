#ifndef RADIO_GILA_PLAYER
#define RADIO_GILA_PLAYER

#include "Config.hpp"
#include "Mutex.hpp"
#include "Playlist.hpp"
#include "Settings.hpp"
#include "Threads.hpp"

class Player {

	public:

		Player ( Playlist * PlaylistPointer, Tracks * TracksPointer, Settings * SettingsPointer ) : ManageThread ( &Player::Manage, this ) {

			this->PlaylistPointer = PlaylistPointer;
			this->TracksPointer = TracksPointer;
			this->SettingsPointer = SettingsPointer;

			Enabled = false;
			Interrupted = false;

			PlaylistTimestamp = 0; }

		~ Player ( ) {
			
			Disable(); }

		void Enable ( );
		void Disable ( );
		bool IsEnabled ( );

		void Mute ( );
		void Unmute ( );
		bool IsMuted ( );

		void SetVolume ( REAL32 Volume );
		REAL32 GetVolume ( );

		void PlaySingleTrack ( std::string Title, std::string Artist, std::string Album );
		void StopSingleTrack ( );
		bool IsSingleTrackPlaying ( );
	
	private:

		void Manage ( );

	private:

		Playlist * PlaylistPointer;
		Tracks * TracksPointer;
		Settings * SettingsPointer;

		sf::Music Music;
		sf::Music SingleMusic;
		sf::Thread ManageThread;

		bool Enabled;
		bool Interrupted;

		UINT64 PlaylistTimestamp;

	};

#endif