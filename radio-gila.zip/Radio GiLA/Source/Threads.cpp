#include "Threads.hpp"

ExternalDataStruct ExternalData;
sf::Thread CreateTrackThread ( CreateTrack );
sf::Thread UpdateSettingsThread ( UpdateSettings );

void CreateTrack ( ) {
	
	Track Data;
	sf::Music File;
	sf::Texture Cover;
	
	*ExternalData.InterfaceInterrupted = true;
	*ExternalData.InterfaceStatus = L"Trwa zapisywanie �cie�ki...";
	
	for ( size_t i = 0; i < 7; i++ ) {

		if ( ExternalData.InterfaceField[i].getSize() == 0 ) {
			
			*ExternalData.InterfaceInterrupted = false;
			*ExternalData.InterfaceStatus = L"�adne pole nie mo�e pozosta� puste!";
			
			return; } }
	
	for ( size_t i = 0; i < ExternalData.InterfaceField[4].getSize(); i++ ) {

		if ( ExternalData.InterfaceField[4][i] >= 48 && ExternalData.InterfaceField[4][i] <= 57 ) {

			Data.Year = Data.Year * 10;
			Data.Year = Data.Year + ( ExternalData.InterfaceField[4][i] - 48 ); }

		else {

			*ExternalData.InterfaceInterrupted = false;
			*ExternalData.InterfaceStatus = L"Podany rok jest niepoprawny!";

			return; } }
	
	if ( !FileExists( ExternalData.InterfaceField[5] ) ) {

		*ExternalData.InterfaceInterrupted = false;
		*ExternalData.InterfaceStatus = L"Podana �cie�ka do pliku jest niepoprawna!";
		
		return; }
	
	if ( !FileExists( ExternalData.InterfaceField[6] ) ) {

		*ExternalData.InterfaceInterrupted = false;
		*ExternalData.InterfaceStatus = L"Podana �cie�ka do ok�adki jest niepoprawna!";
		
		return; }
	
	CRC32 CRC32;
	std::string FileName;

	FileName = CRC32.Generate( ExternalData.InterfaceField[1] + " - " + ExternalData.InterfaceField[0] + " ( " + ExternalData.InterfaceField[2] + " )" );

	if ( !FileCopy( ExternalData.InterfaceField[5], ExternalData.SettingsPointer->GetTextParameter( Settings::TracksPath ) + FileName + FileExtension( ExternalData.InterfaceField[5] ) ) ) {

		*ExternalData.InterfaceInterrupted = false;
		*ExternalData.InterfaceStatus = L"Kopiowanie pliku nie powiod�o si�. Sprawd� ustawienia i uprawnienia aplikacji.";
		
		return; }
	
	if ( !FileCopy( ExternalData.InterfaceField[6], ExternalData.SettingsPointer->GetTextParameter( Settings::CoversPath ) + FileName + FileExtension( ExternalData.InterfaceField[6] ) ) ) {

		*ExternalData.InterfaceInterrupted = false;
		*ExternalData.InterfaceStatus = L"Kopiowanie ok�adki nie powiod�o si�. Sprawd� ustawienia i uprawnienia aplikacji.";
		
		return; }
	
	if ( !File.openFromFile( ExternalData.SettingsPointer->GetTextParameter( Settings::TracksPath ) + FileName + FileExtension( ExternalData.InterfaceField[5] ) ) ) {

		*ExternalData.InterfaceInterrupted = false;
		*ExternalData.InterfaceStatus = L"Wczytywanie pliku nie powiod�o si�. Prawdopodobnie posiada on nieob�ugiwany format.";
		
		return; }
	
	if ( !Cover.loadFromFile( ExternalData.SettingsPointer->GetTextParameter( Settings::CoversPath ) + FileName + FileExtension( ExternalData.InterfaceField[6] ) ) ) {

		*ExternalData.InterfaceInterrupted = false;
		*ExternalData.InterfaceStatus = L"Wczytywanie ok�adki nie powiod�o si�. Prawdopodobnie posiada ona nieob�ugiwany format.";
		
		return; }
	
	Data.Title = ExternalData.InterfaceField[0];
	Data.Artist = ExternalData.InterfaceField[1];
	Data.Album = ExternalData.InterfaceField[2];
	Data.Genre = ExternalData.InterfaceField[3];
	Data.Lenght = (UINT64) ( File.getDuration().asSeconds() >= 1.00f ? File.getDuration().asSeconds() : 1.00f );
	Data.Quality = File.getSampleRate();
	Data.Rate = ExternalData.TrackCopy->Rate;
	Data.Playcount = ExternalData.TrackCopy->Playcount;
	Data.IsPlaylist = ExternalData.TrackCopy->IsPlaylist;
	Data.TrackPath = FileName + FileExtension( ExternalData.InterfaceField[5] );
	Data.CoverPath = FileName + FileExtension( ExternalData.InterfaceField[6] );
	Data.DataPath = FileName;

	if ( ExternalData.TracksPointer->Create( Data ) ) {

		ExternalData.TracksPointer->Reload();
		*ExternalData.FilteredTracks = ExternalData.TracksPointer->Search( ExternalData.FilterText->getString() ); }

	else {

		*ExternalData.InterfaceInterrupted = false;
		*ExternalData.InterfaceStatus = L"Zapisywanie �cie�ki nie powiod�o si�. Sprawd� ustawienia i uprawnienia aplikacji.";

		return; }

	*ExternalData.InterfaceInterrupted = false;
	*ExternalData.InterfaceStatus = L"�cie�ka zosta�a zapisana pomy�lnie."; }

void UpdateSettings ( ) {

	*ExternalData.InterfaceInterrupted = true;

	ExternalData.PlaylistPointer->LoadFromFile( ExternalData.SettingsPointer->GetTextParameter( Settings::DataPath ) + "Playlist" );
	ExternalData.TracksPointer->Reload();

	*ExternalData.InterfaceInterrupted = false; }

bool FileExists ( std::string Path ) {

	std::fstream File ( Path, std::ios::in );

	if ( !File.is_open() ) {

		return false; }

	File.close();

	return true; }

bool FileCopy ( std::string InputPath, std::string OutputPath ) {

	if ( InputPath == OutputPath ) {

		return true; }

	std::fstream InputFile ( InputPath, std::ios::in | std::ios::binary );
	std::fstream OutputFile ( OutputPath, std::ios::out | std::ios::binary );

	if ( !InputFile.is_open() || !OutputFile.is_open() ) {

		return false; }
	
	InputFile.seekg( 0, std::ios::end );

	size_t Size = (size_t) InputFile.tellg();

	InputFile.seekg( 0, std::ios::beg );
	
	char * Data = new char [ Size ];

	InputFile.read( Data, Size );
	OutputFile.write( Data, Size );

	delete Data;

	InputFile.close();
	OutputFile.close();

	return true; }

std::string FileExtension ( std::string Path ) {

	size_t Begin = Path.find_last_of( "." );

	if ( Begin != std::string::npos ) {

		return Path.substr( Begin ); }

	return ""; }