#include "Timeline.hpp"

Timeline::Timeline ( Playlist * PlaylistPointer, Settings * SettingsPointer ){

	this->PlaylistPointer = PlaylistPointer;
	this->SettingsPointer = SettingsPointer;

	Tracking = true;

	PlaylistTimestamp = 0;

	SelectedPlaylistElement = NULL;

	Begin = SettingsPointer->GetTime() - 1800;
	End = SettingsPointer->GetTime() + 1800; }

void Timeline::SetTracking ( bool Tracking ) {

	this->Tracking = Tracking; }

bool Timeline::GetTracking ( ) {

	return Tracking; }

void Timeline::SetBegin ( UINT64 Time ) {

	Begin = Time;

	PlaylistTimestamp = 0; }

UINT64 Timeline::GetBegin ( ) {

	return Begin; }

void Timeline::SetEnd ( UINT64 Time ) {

	End = Time;
	
	PlaylistTimestamp = 0; }

UINT64 Timeline::GetEnd ( ) {

	return End; }

bool Timeline::SetScope ( std::string Scope ) {

	std::string ScopeLeft;
	std::string ScopeRight;
	std::string ScopeBuffer;
	std::vector <UINT64> ScopeBegin;
	std::vector <UINT64> ScopeEnd;

	size_t Dash = Scope.find( "-" );

	if ( Dash == std::string::npos ) {

		return false; }

	ScopeLeft = Scope.substr( 0, Dash );
	ScopeRight = Scope.substr( Dash + 1 );
	
	UINT64 ScopeLeftMonthLength [12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	for ( size_t i = 0; i < ScopeLeft.size(); i++ ) {

		if ( ScopeLeft[i] != ' ' && ScopeLeft[i] != ':' && ScopeLeft[i] != '.' ) {

			ScopeBuffer = ScopeBuffer + ScopeLeft[i]; }

		else {

			UINT64 Number;

			if ( !Convert( ScopeBuffer, Number ) ) {

				return false; }

			ScopeBuffer.clear();
			ScopeBegin.push_back( Number ); } }
	
	if ( ScopeBegin.size() != 5 ) {

		return false; }
	
	if ( ScopeBegin[4] < 1970 || ScopeBegin[4] > 10000 || ScopeBegin[3] == 0 || ScopeBegin[3] > 12 ) {

        return false; }

    if ( ScopeBegin[4] % 400 == 0 || ( ScopeBegin[4] % 100 != 0 && ScopeBegin[4] % 4 == 0 ) ) {

        ScopeLeftMonthLength[1] = 29; }
              
    if ( ScopeBegin[2] > ScopeLeftMonthLength[ ScopeBegin[3] - 1 ] ) {
               
        return false; }
	
	if ( ScopeBegin[0] > 23 || ScopeBegin[1] > 59 ) {

		return false; }

	UINT64 ScopeRightMonthLength [12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	
	if ( ScopeRight.size() > 0 ) {

		if ( ScopeRight[0] != ' ' ) {

			return false; }

		ScopeRight = ( ScopeRight + " " ).substr( 1 ); }

	for ( size_t i = 0; i < ScopeRight.size(); i++ ) {

		if ( ScopeRight[i] != ' ' && ScopeRight[i] != ':' && ScopeRight[i] != '.' ) {

			ScopeBuffer = ScopeBuffer + ScopeRight[i]; }

		else {

			UINT64 Number;

			if ( !Convert( ScopeBuffer, Number ) ) {

				return false; }

			ScopeBuffer.clear();
			ScopeEnd.push_back( Number ); } }
	
	if ( ScopeEnd.size() != 5 ) {

		return false; }
	
	if ( ScopeEnd[4] < 1970 || ScopeEnd[4] > 10000 || ScopeEnd[3] == 0 || ScopeEnd[3] > 12 ) {

        return false; }
	
    if ( ScopeEnd[4] % 400 == 0 || ( ScopeEnd[4] % 100 != 0 && ScopeEnd[4] % 4 == 0 ) ) {

        ScopeRightMonthLength[1] = 29; }
              
    if ( ScopeEnd[2] > ScopeRightMonthLength[ ScopeEnd[3] - 1 ] ) {
               
        return false; }
	
	if ( ScopeEnd[0] > 23 || ScopeEnd[1] > 59 ) {

		return false; }

	struct tm * TimeStructure = new struct tm;

	TimeStructure->tm_hour = (int) ScopeBegin[0];
	TimeStructure->tm_min = (int) ScopeBegin[1];
	TimeStructure->tm_sec = 0;
	TimeStructure->tm_mday = (int) ScopeBegin[2];
	TimeStructure->tm_mon = (int) ScopeBegin[3] - 1;
	TimeStructure->tm_year = (int) ScopeBegin[4] - 1900;
	TimeStructure->tm_isdst = -1;

	UINT64 BeginCopy = (UINT64) mktime( TimeStructure );

	TimeStructure->tm_hour = (int) ScopeEnd[0];
	TimeStructure->tm_min = (int) ScopeEnd[1];
	TimeStructure->tm_sec = 0;
	TimeStructure->tm_mday = (int) ScopeEnd[2];
	TimeStructure->tm_mon = (int) ScopeEnd[3] - 1;
	TimeStructure->tm_year = (int) ScopeEnd[4] - 1900;
	TimeStructure->tm_isdst = -1;

	UINT64 EndCopy = (UINT64) mktime( TimeStructure );

	delete TimeStructure;

	if ( ( EndCopy - BeginCopy ) > ( 3600 * 24 ) || ( EndCopy - BeginCopy ) < ( 60 * 5 ) ) {

		return false; }

	Begin = BeginCopy;
	End = EndCopy;

	PlaylistTimestamp = 0;

	return true; }

std::string Timeline::GetScope ( ) {

	std::string Buffer;
	std::string Result;

	struct tm * TimeStructure = new struct tm;
	time_t ScopeBegin = Begin;
	time_t ScopeEnd = End;

	localtime_s( TimeStructure, &ScopeBegin );

	Convert( TimeStructure->tm_hour, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + ":";

	Convert( TimeStructure->tm_min, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + " ";

	Convert( TimeStructure->tm_mday, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + ".";

	Convert( TimeStructure->tm_mon + 1, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + ".";

	Convert( TimeStructure->tm_year + 1900, Buffer );
	Result = Result + Buffer + " - ";

	localtime_s( TimeStructure, &ScopeEnd );

	Convert( TimeStructure->tm_hour, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + ":";

	Convert( TimeStructure->tm_min, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + " ";

	Convert( TimeStructure->tm_mday, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + ".";

	Convert( TimeStructure->tm_mon + 1, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + ".";

	Convert( TimeStructure->tm_year + 1900, Buffer );
	Result = Result + Buffer;

	delete TimeStructure;

	return Result; }

void Timeline::SetCenter ( UINT64 Time ) {

	UINT64 Difference = End - Begin;

	Begin = Time - Difference / 2;
	End = Time + Difference / 2;
	
	PlaylistTimestamp = 0; }

UINT64 Timeline::GetCenter ( ) {

	return Begin + ( End - Begin ); }

void Timeline::Render ( sf::RenderWindow &Window, sf::Vector2f Position, sf::Vector2f Size ) {

	if ( Tracking ) {

		SetCenter( SettingsPointer->GetTime() ); }	

	sf::Vertex Line [2] = { sf::Vertex( sf::Vector2f( Position.x, Position.y ), sf::Color( 0, 100, 200 ) ), sf::Vertex( sf::Vector2f( Position.x, Position.y + Size.y ), sf::Color( 0, 100, 200 ) ) };
	sf::Vector2f Mouse ( (REAL32) sf::Mouse::getPosition( Window ).x, (REAL32) sf::Mouse::getPosition( Window ).y );

	Line[0].position.x += (REAL32) ( ( 5 * 60 ) - Begin % ( 5 * 60 ) ) * Size.x / (REAL32) ( End - Begin );
	Line[1].position.x += (REAL32) ( ( 5 * 60 ) - Begin % ( 5 * 60 ) ) * Size.x / (REAL32) ( End - Begin );

	for ( size_t i = 0; i < ( ( End - Begin ) / ( 5 * 60 ) + 1 ); i++ ) {

		Window.draw( Line, 2, sf::Lines );

		Line[0].position.x += ( 5.00f * 60.00f ) * Size.x / (REAL32) ( End - Begin );
		Line[1].position.x += ( 5.00f * 60.00f ) * Size.x / (REAL32) ( End - Begin ); }

	if ( Begin <= SettingsPointer->GetTime() && End >= SettingsPointer->GetTime() ) {
		
		Line[0].position.x = Position.x + Size.x * ( (REAL32) ( SettingsPointer->GetTime() - Begin ) / (REAL32) ( End - Begin ) );
		Line[1].position.x = Position.x + Size.x * ( (REAL32) ( SettingsPointer->GetTime() - Begin ) / (REAL32) ( End - Begin ) );

		Line[0].color = sf::Color( 200, 0, 0 );
		Line[1].color = sf::Color( 200, 0, 0 );

		Window.draw( Line, 2, sf::Lines ); }

	if ( PlaylistPointer->GetTimestamp() != PlaylistTimestamp ) {

		PlaylistElements.clear();

		for ( size_t i = 0; i < PlaylistPointer->GetSize(); i++ ) {
			
			if ( ( ( Begin < (*PlaylistPointer)[i]->Input ) && ( End > (*PlaylistPointer)[i]->Input ) ) || ( ( Begin < ( (*PlaylistPointer)[i]->Input + (*PlaylistPointer)[i]->Lenght ) ) && ( End > ( (*PlaylistPointer)[i]->Input + (*PlaylistPointer)[i]->Lenght ) ) ) || ( ( Begin >= (*PlaylistPointer)[i]->Input ) && ( End <= ( (*PlaylistPointer)[i]->Input + (*PlaylistPointer)[i]->Lenght ) ) ) ) {

				PlaylistElements.push_back( (*PlaylistPointer)[i] ); } }

		PlaylistTimestamp = PlaylistPointer->GetTimestamp(); }

	SelectedPlaylistElement = NULL;

	for ( size_t i = 0; i < PlaylistElements.size(); i++ ) {
		
		sf::Vertex Block [4];
		REAL32 BlockLength, BlockBegin, BlockEnd;
		
		BlockLength = ( Size.x * PlaylistElements[i]->Lenght ) / ( End - Begin );
		BlockBegin = ( Size.x * (INT64) ( PlaylistElements[i]->Input - Begin ) ) / ( End - Begin );
		BlockEnd = BlockBegin + BlockLength;

		if ( BlockBegin < 0 ) {

			BlockBegin = 0; }

		if ( BlockEnd > Size.x ) {

			BlockEnd = Size.x; }

		if ( Mouse.x > ( Position.x + BlockBegin ) && Mouse.x < ( Position.x + BlockBegin + BlockLength ) && Mouse.y > Position.y && Mouse.y < ( Position.y + Size.y ) ) {

			SelectedPlaylistElement = PlaylistElements[i]; }

		Block[0] = sf::Vertex( sf::Vector2f( Position.x + BlockBegin, Position.y ), SelectedPlaylistElement == PlaylistElements[i] ? sf::Color( 255, 255, 255, 100 ) : sf::Color( 0, 0, 255, 100 ) );
		Block[1] = sf::Vertex( sf::Vector2f( Position.x + BlockEnd, Position.y ), SelectedPlaylistElement == PlaylistElements[i] ? sf::Color( 255, 255, 255, 100 ) : sf::Color( 0, 0, 255, 100 ) );
		Block[2] = sf::Vertex( sf::Vector2f( Position.x + BlockEnd, Position.y + Size.y ), SelectedPlaylistElement == PlaylistElements[i] ? sf::Color( 255, 255, 255, 100 ) : sf::Color( 0, 0, 255, 100 ) );
		Block[3] = sf::Vertex( sf::Vector2f( Position.x + BlockBegin, Position.y + Size.y ), SelectedPlaylistElement == PlaylistElements[i] ? sf::Color( 255, 255, 255, 100 ) : sf::Color( 0, 0, 255, 100 ) );

		Window.draw( Block, 4, sf::Quads ); } }

Playlist::Element * Timeline::GetSelectedPlaylistElement ( ) {

	return SelectedPlaylistElement; }

void Timeline::Convert ( UINT64 Value, std::string &Text ) {

	Text.clear();

	do {

		Text = (char) ( Value % 10 + 48 ) + Text;
		Value = Value / 10; }

	while ( Value != 0 ); }

bool Timeline::Convert ( std::string Text, UINT64 &Value ) {

	Value = 0;

	if ( Text.size() == 0 ) {

		return false; }

	for ( size_t i = 0; i < Text.size(); i++ ) {

		if ( Text[i] >= 48 && Text[i] <= 57 ) {

			Value = Value * 10;
			Value = Value + ( Text[i] - 48 ); }

		else {

			return false; } }

	return true; }