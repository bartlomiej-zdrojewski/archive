#ifndef RADIO_GILA_PLAYLIST
#define RADIO_GILA_PLAYLIST

#include "Config.hpp"
#include "Mutex.hpp"
#include "Settings.hpp"

class Playlist {

	public:

		struct Element {

			std::string Title;
			std::string Artist;
			std::string Album;
			UINT64 Lenght;
			UINT64 Begin;
			UINT64 Input;

			};

	public:

		Playlist ( Settings * SettingsPointer );

		Element * operator [] ( size_t i ) {

			return &Elements[i]; }
		
		void Clear ( );
		size_t GetSize ( );

		bool CreateElement ( Element Data );
		bool CreateElement ( Element Data, size_t &Index );
		void DeleteElement ( Element * Data );

		bool LoadFromFile ( std::string FilePath );
		bool SaveToFile ( std::string FilePath );

		void SetTimestamp ( UINT64 Timestamp );
		UINT64 GetTimestamp ( );

	private:

		void SortElements ( );

		bool Convert ( std::string Text, UINT64 &Value );

	private:
		
		Settings * SettingsPointer;

		std::vector <Element> Elements;

	};


#endif