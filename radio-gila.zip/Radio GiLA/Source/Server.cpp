#include "Server.hpp"

Server::Server ( std::string URL ) {

	Host.setHost( URL );

	SetTimeout( 10 ); }

void Server::SetTimeout ( UINT64 Time ) {

	Timeout = sf::seconds( (REAL32) Time ); }

UINT64 Server::GetTimeout ( ) {

	return (UINT64) ( Timeout.asSeconds() ); }

UINT64 Server::GetTracksTimestamp ( ) {

	try {

		return GetTimestamp( "TRACKS" ); }

	catch ( Error Exception ) {

		throw Exception; } }

UINT64 Server::GetPlaylistTimestamp ( ) {

	try {

		return GetTimestamp( "PLAYLIST" ); }

	catch ( Error Exception ) {

		throw Exception; } }

UINT64 Server::GetSettingsTimestamp ( ) {

	try {

		return GetTimestamp( "SETTINGS" ); }

	catch ( Error Exception ) {

		throw Exception; } }

std::string Server::GetTracks ( ) {

	sf::Http::Request Request;
	sf::Http::Response Response;

	Request.setUri( "/update.php" );
	Request.setMethod( sf::Http::Request::Post );
	Request.setBody( "command=GET&argument=TRACKS" );

	Response = Host.sendRequest( Request, Timeout );

	if ( Response.getStatus() != sf::Http::Response::Ok ) {

		// UPS!

		}

	return Response.getBody(); }

std::string Server::GetPlaylist ( ) {

	sf::Http::Request Request;
	sf::Http::Response Response;

	Request.setUri( "/update.php" );
	Request.setMethod( sf::Http::Request::Post );
	Request.setBody( "command=GET&argument=PLAYLIST" );

	Response = Host.sendRequest( Request, Timeout );

	if ( Response.getStatus() != sf::Http::Response::Ok ) {

		// UPS!

		}

	if ( Response.getBody() == "PLAYLIST NOT FOUND" ) {

		// UPS!

		}

	return Response.getBody(); }

std::string Server::GetSettings ( ) {

	sf::Http::Request Request;
	sf::Http::Response Response;

	Request.setUri( "/update.php" );
	Request.setMethod( sf::Http::Request::Post );
	Request.setBody( "command=GET&argument=TRACKS" );

	Response = Host.sendRequest( Request, Timeout );

	if ( Response.getStatus() != sf::Http::Response::Ok ) {

		// UPS!

		}

	if ( Response.getBody() == "SETTINGS NOT FOUND" ) {

		// UPS!

		}

	return Response.getBody(); }

UINT64 Server::GetTimestamp ( std::string Argument ) {

	UINT64 Timestamp;
	sf::Http::Request Request;
	sf::Http::Response Response;

	Request.setUri( "/update.php" );
	Request.setMethod( sf::Http::Request::Post );
	Request.setBody( "command=GET&argument=" + Argument + "TIMESTAMP" );

	Response = Host.sendRequest( Request, Timeout );

	if ( Response.getStatus() != sf::Http::Response::Ok ) {

		// UPS!

		}

	if ( !Convert( Response.getBody(), Timestamp ) ) {

		if ( Response.getBody() == "COMMAND UNKNOWN" ) {

			// UPS!
			
			}

		else {

			// UPS!
			
			} }

	return Timestamp; }

bool Server::Convert ( std::string Text, UINT64 &Value ) {

	Value = 0;

	if ( Text.size() == 0 ) {

		return false; }

	for ( size_t i = 0; i < Text.size(); i++ ) {

		if ( Text[i] >= 48 && Text[i] <= 57 ) {

			Value = Value * 10;
			Value = Value + ( Text[i] - 48 ); }

		else {

			return false; } }

	return true; }