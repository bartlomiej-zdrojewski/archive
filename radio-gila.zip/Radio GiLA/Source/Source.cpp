#include "RadioGila.hpp"

int main ( ) {
	
	//Server RadioGilaServer ( "http://radiogila.byethost24.com/" );

	//cout << RadioGilaServer.GetTracksTimestamp();

	//Playlist a( "Bill Gates vs Steve Jobs\nEpic Rap Battles of History\nEpic Rap Battles of History 2\n100\n20\n1431561600\nStill Alive\nValve\nPortal\n120\n0\n1431584100\nMonster\nImagine Dragons\nSingles\n20\n5\n1431588900\nBanana\nSystem of a Down\nSome Songs\n240\n23\n1431598500\nStill Alive\nValve\nPortal\n120\n0\n1438146000\nStill Alive\nValve\nPortal\n120\n0\n1438146120\nBanana\nSystem of a Down\nSome Songs\n263\n0\n1438146375\nBanana\nSystem of a Down\nSome Songs\n263\n0\n1438146638", 0 );

	//Playlist a ( RadioGilaServer.GetPlaylist(), 1438145000 );

	//cout << a.GetSize();

	// ------------------

	Interface * InterfacePointer;
	Playlist * PlaylistPointer;
	Tracks * TracksPointer;
	Player * PlayerPointer;
	Algorithm * AlgorithmPointer;
	Settings * SettingsPointer;

	SettingsPointer = new Settings ( );
	PlaylistPointer = new Playlist ( SettingsPointer );
	TracksPointer = new Tracks ( SettingsPointer );
	PlayerPointer = new Player ( PlaylistPointer, TracksPointer, SettingsPointer );
	AlgorithmPointer = new Algorithm ( PlaylistPointer, TracksPointer, SettingsPointer );
	InterfacePointer = new Interface ( sf::Vector2f( 800.00f, 600.00f ), PlaylistPointer, TracksPointer, PlayerPointer, SettingsPointer );

	sf::RenderWindow Window ( sf::VideoMode( 800, 600 ), "Radio Gila", sf::Style::Default );

	Window.setFramerateLimit( 60 );
	//Window.setIcon( 32, 32, NULL );

	PlayerPointer->Enable();

	while ( Window.isOpen() ) {
		
		sf::Event Event;

		while ( Window.pollEvent( Event ) ) {
			
			InterfacePointer->Update( Window, Event );

			if ( Event.type == sf::Event::Resized ) {
				
				sf::Vector2u Size ( Event.size.width, Event.size.height );

				if ( Size.x < 800 ) {

					Size.x = 800; }

				if ( Size.y < 600 ) {

					Size.y = 600; }

				if ( Size.x != Event.size.width || Size.y != Event.size.height ) {

					Window.setSize( Size ); }
				
				InterfacePointer->SetSize( sf::Vector2f( Size ) );
				Window.setView( sf::View( sf::FloatRect( 0.00f, 0.00f, (REAL32) Event.size.width, (REAL32) Event.size.height ) ) ); }

			if ( Event.type == sf::Event::Closed ) {

				Window.close(); } }
		
		if ( !AlgorithmPointer->IsPerformed() ) {
			
			AlgorithmPointer->Perform(); }

		Window.clear( sf::Color::White );

		InterfacePointer->Render( Window );

		Window.display(); }
	
	PlayerPointer->Disable();

	delete InterfacePointer;
	delete PlaylistPointer;
	delete TracksPointer;
	delete PlayerPointer;
	delete AlgorithmPointer;
	delete SettingsPointer; }