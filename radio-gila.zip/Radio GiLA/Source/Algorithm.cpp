#include "Algorithm.hpp"

Algorithm::Algorithm ( Playlist * PlaylistPointer, Tracks * TracksPointer, Settings * SettingsPointer ) {

	this->PlaylistPointer = PlaylistPointer;
	this->TracksPointer = TracksPointer;
	this->SettingsPointer = SettingsPointer; }

void Algorithm::SetActivationTime ( UINT64 Hour, UINT64 Minute, UINT64 Second ) {

	SettingsPointer->SetNumericParameter( Settings::AlgorithmActivationHour, Hour % 24 );
	SettingsPointer->SetNumericParameter( Settings::AlgorithmActivationMinute, Minute % 60 );
	SettingsPointer->SetNumericParameter( Settings::AlgorithmActivationSecond, Second % 60 ); }

UINT64 Algorithm::GetActivationTime ( ) {

	return ( SettingsPointer->GetNumericParameter( Settings::AlgorithmActivationHour ) * 3600 + SettingsPointer->GetNumericParameter( Settings::AlgorithmActivationMinute ) * 60 + SettingsPointer->GetNumericParameter( Settings::AlgorithmActivationSecond ) ); }

bool Algorithm::IsPerformed ( ) {

	time_t TimeData = SettingsPointer->GetTime() - GetActivationTime();
	time_t TimestampData = GetTimestamp() - GetActivationTime();
	
	struct tm * TimeStructure = new struct tm;
	struct tm * TimestampStructure = new struct tm;
	
	localtime_s( TimeStructure, &TimeData );
	localtime_s( TimestampStructure, &TimestampData );
	
	if ( TimestampStructure->tm_mday == TimeStructure->tm_mday && TimestampStructure->tm_mon == TimeStructure->tm_mon && TimestampStructure->tm_year == TimeStructure->tm_year ) {

		delete TimeStructure;
		delete TimestampStructure;

		return true; }

	delete TimeStructure;
	delete TimestampStructure;

	return false; }

void Algorithm::Perform ( ) {

	LoadIntervals( "Algorithm" );

	std::vector <UINT64> EmptyIntervals;

	time_t TimeData = SettingsPointer->GetTime();
	struct tm * TimeStructure = new struct tm;
	
	localtime_s( TimeStructure, &TimeData );

	TimeStructure->tm_hour = 0;
	TimeStructure->tm_min = 0;
	TimeStructure->tm_sec = 0;

	if ( PlaylistPointer->GetSize() > 0 ) {

		size_t PlaylistIndex = 0;

		for ( size_t i = 0; i < ( Intervals.size() / 2 ); i++ ) {

			UINT64 IntervalBegin = mktime( TimeStructure ) + Intervals[i*2];
			UINT64 IntervalEnd = mktime( TimeStructure ) + Intervals[i*2+1];

			while ( PlaylistIndex < PlaylistPointer->GetSize() ) {

				if ( (*PlaylistPointer)[PlaylistIndex]->Input >= IntervalEnd ) {

					break; }

				if ( ( ( (*PlaylistPointer)[PlaylistIndex]->Input + (*PlaylistPointer)[PlaylistIndex]->Lenght ) ) > IntervalBegin ) {

					if ( (*PlaylistPointer)[PlaylistIndex]->Input <= IntervalBegin ) {

						IntervalBegin = (*PlaylistPointer)[PlaylistIndex]->Input + (*PlaylistPointer)[PlaylistIndex]->Lenght; }

					else {

						EmptyIntervals.push_back( IntervalBegin );
						EmptyIntervals.push_back( (*PlaylistPointer)[PlaylistIndex]->Input );

						IntervalBegin = (*PlaylistPointer)[PlaylistIndex]->Input + (*PlaylistPointer)[PlaylistIndex]->Lenght; }

					if ( IntervalBegin >= IntervalEnd ) {

						break; } }

				PlaylistIndex++; }

			if ( IntervalBegin < IntervalEnd ) {

				EmptyIntervals.push_back( IntervalBegin );
				EmptyIntervals.push_back( IntervalEnd ); } } }

	else {

		EmptyIntervals = Intervals; }

	delete TimeStructure;
	
	if ( TracksPointer->GetSize() > 0 ) {
		
		std::vector <size_t> LatestTracks;
		std::vector <REAL64> PreferredTracks;
		
		if ( PlaylistPointer->GetSize() > 0 && TracksPointer->GetSize() > 25 ) {

			size_t Index = PlaylistPointer->GetSize() - 1;

			while ( Index > 0 && LatestTracks.size() < 25 ) {

				if ( ( ( (*PlaylistPointer)[Index]->Input + (*PlaylistPointer)[Index]->Lenght ) ) <= SettingsPointer->GetTime() ) {
					
					LatestTracks.push_back( Index ); }

				Index--; }
			
			std::reverse( LatestTracks.begin(), LatestTracks.end() ); }
		
		for ( size_t i = 0; i < TracksPointer->GetSize(); i++ ) {

			PreferredTracks.push_back( ( (*TracksPointer)[i]->Rate + 1.00 ) * ( 1.00 / ( (*TracksPointer)[i]->Playcount + 1.00 ) ) ); }

		for ( size_t i = 0; i < ( EmptyIntervals.size() / 2 ); i++ ) {
			
			bool Ready = false;
			size_t Index = 0;
			Playlist::Element Data;

			UINT64 IntervalBegin = EmptyIntervals[i*2];
			UINT64 IntervalEnd = EmptyIntervals[i*2+1];
			UINT64 IntervalLegth = IntervalEnd - IntervalBegin;

			if ( ( IntervalEnd - IntervalBegin ) < 10 ) {

				continue; }
			
			for ( size_t j = 0; j < TracksPointer->GetSize(); j++ ) {

				bool LatestTrack = false;

				if ( !(*TracksPointer)[j]->IsPlaylist ) {

					continue; }

				for ( size_t k = 0; k < LatestTracks.size(); k++ ) {
					
					if ( j == LatestTracks[k] ) {

						LatestTrack = true;

						break; } }

				if ( !LatestTrack ) {
					
					if ( Ready ) {
						
						if ( PreferredTracks[j] > PreferredTracks[Index] ) {

							Index = j; } }

					else {
						
						Ready = true;
						Index = j; } } }

			if ( !Ready ) {
				
				Index = LatestTracks[0];

				LatestTracks.erase( LatestTracks.begin() ); }

			if ( LatestTracks.size() == 25 ) {
				
				for ( size_t j = 0; j < ( LatestTracks.size() - 1 ); j++ ) {

					LatestTracks[j] = LatestTracks[j+1]; }

				LatestTracks[ LatestTracks.size() - 1 ] = Index; }

			else {
				
				LatestTracks.push_back( Index ); }

			if ( IntervalLegth > (*TracksPointer)[Index]->Lenght ) {

				EmptyIntervals[i*2]= EmptyIntervals[i*2] + (*TracksPointer)[Index]->Lenght;

				i--; }

			Data.Title = (*TracksPointer)[Index]->Title;
			Data.Artist = (*TracksPointer)[Index]->Artist;
			Data.Album = (*TracksPointer)[Index]->Album;
			Data.Lenght = IntervalLegth <= (*TracksPointer)[Index]->Lenght ? IntervalLegth : (*TracksPointer)[Index]->Lenght;
			Data.Begin = 0;
			Data.Input = IntervalBegin;

			PlaylistPointer->CreateElement( Data ); } }
	
	SetTimestamp( SettingsPointer->GetTime() ); }

bool Algorithm::LoadIntervals ( std::string FilePath ) {

	std::fstream File ( FilePath, std::ios::in );

	if ( File.is_open() ) {

		Intervals.clear();

		while ( !File.eof() ) {

			UINT64 IntervalBegin;
			UINT64 IntervalEnd;

			File >> IntervalBegin;
			File >> IntervalEnd;

			if ( !File.fail() ) {

				if ( IntervalBegin <= IntervalEnd ) {

					bool Conflict = false;

					for ( size_t i = 0; i < ( Intervals.size() / 2 ); i++ ) {

						if ( ( ( IntervalBegin < Intervals[2*i] ) && ( IntervalEnd > Intervals[2*i] ) ) || ( ( IntervalBegin < Intervals[2*i+1] ) && ( IntervalEnd > Intervals[2*i+1] ) ) || ( ( IntervalBegin >= Intervals[2*i] ) && ( IntervalEnd <= Intervals[2*i+1] ) ) ) {

							Conflict = true;

							break; } }

					if ( !Conflict ) {

						Intervals.push_back( IntervalBegin );
						Intervals.push_back( IntervalEnd ); } } } }

		SortIntervals();

		File.close();

		return true; }

	return false; }

void Algorithm::SetTimestamp ( UINT64 Timestamp ) {
	
	SettingsPointer->SetNumericParameter( Settings::AlgorithmTimestamp, Timestamp ); }

UINT64 Algorithm::GetTimestamp ( ) {

	return SettingsPointer->GetNumericParameter( Settings::AlgorithmTimestamp ); }

void Algorithm::SortIntervals ( ) {

	for ( size_t i = 1; i < ( Intervals.size() / 2 ); i++ ) {

		UINT64 Value = Intervals[i*2];
		
		for ( size_t j = i; j > 0; j-- ) {

			if ( Intervals[j*2-2] > Value ) {

				Intervals[j*2] = Intervals[j*2-2]; }

			else {

				break; }

			Intervals[j*2-2] = Value; } } }