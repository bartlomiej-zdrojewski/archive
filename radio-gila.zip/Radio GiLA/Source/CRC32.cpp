#include "CRC32.hpp"

CRC32::CRC32 ( ) {

	GenerateLookupTable(); }

CRC32::~CRC32 ( ) {

	delete LookupTable; }

std::string CRC32::Generate ( std::string Data ) {
	
	std::string Result;
	UINT32 Checksum = 0xFFFFFFFF;

	for ( size_t i = 0; i < Data.size(); i++ ) {

		Checksum = LookupTable[ ( Checksum ^ Data[i] ) & 0xFF ] ^ ( Checksum >> 8 ); }

	Checksum = ~Checksum;

	while ( Checksum > 0 ) {

		if ( Checksum % 16 < 10 ) {

			Result = Result + (char) ( Checksum % 16 + 48 ); }

		else {

			Result = Result + (char) ( Checksum % 16 + 55 ); }

		Checksum = Checksum / 16; }

	std::reverse( Result.begin(), Result.end() );

	return Result; }

void CRC32::GenerateLookupTable ( ) {

	LookupTable = new UINT32 [ 256 ];

	for ( size_t i = 0; i < 256; i++ ) {

		UINT32 Checksum = i;

		for ( size_t j = 0; j < 8; j++ ) {

			Checksum = ( Checksum >> 1 ) ^ ( ( Checksum & 0x1u ) ? 0xEDB88320 : 0 ); }

		LookupTable[i] = Checksum; } }