#ifndef RADIO_GILA_SERVER
#define RADIO_GILA_SERVER

#include "Config.hpp"
#include "Playlist.hpp"

class Server {

	public:

		struct Error {

			std::string Type;
			std::string Value;

			};

	public:
		
		Server ( std::string URL );

		void SetTimeout ( UINT64 Time );
		UINT64 GetTimeout ( );

		UINT64 GetTracksTimestamp ( );
		UINT64 GetPlaylistTimestamp ( );
		UINT64 GetSettingsTimestamp ( );
		
		std::string GetTracks ( );
		std::string GetPlaylist ( );
		std::string GetSettings ( );

	private:
		
		UINT64 GetTimestamp ( std::string Argument );

		bool Convert ( std::string Text, UINT64 &Value );

	private:

		sf::Http Host;
		sf::Time Timeout;

		};

#endif