#include "Settings.hpp"

Settings::Settings ( ) {
	
	NumericParameters.resize( Settings::NumericParametersCount );
	TextParameters.resize( Settings::TextParametersCount );

	if ( !LoadFromFile( "Settings" ) ) {		

		SetNumericParameter( Settings::AlgorithmActivationHour, 3 );
		SetNumericParameter( Settings::AlgorithmActivationMinute, 0 );
		SetNumericParameter( Settings::AlgorithmActivationSecond, 0 );

		SetNumericParameter( Settings::PlayerMuted, 0 );
		SetNumericParameter( Settings::PlayerVolume, 100 );

		SetNumericParameter( Settings::ServerRefresh, 10 );
		SetNumericParameter( Settings::ServerTimeout, 10 );
		SetNumericParameter( Settings::ServerSynchronization, 1 );

		SetNumericParameter( Settings::AlgorithmTimestamp, 0 );
		SetNumericParameter( Settings::PlaylistTimestamp, 0 );
		SetNumericParameter( Settings::TracksTimestamp, 0 );
		SetNumericParameter( Settings::SettingsTimestamp, GetTime() );

		SetNumericParameter( Settings::TimeCorrection, 0 );

		SetTextParameter( Settings::TracksPath, "Tracks/" );
		SetTextParameter( Settings::DataPath, "Data/" );
		SetTextParameter( Settings::CoversPath, "Covers/" );
		SetTextParameter( Settings::GraphicsPath, "Graphics/" );
		
		SetTextParameter( Settings::ServerURL, "" );

		SaveToFile( "Settings" ); } }

UINT64 Settings::GetTime ( ) {

	return ( time( NULL ) + (INT64) GetNumericParameter( Settings::TimeCorrection ) ); }

void Settings::SetNumericParameter ( NumericParameter Parameter, UINT64 Value ) {
	
	switch ( Parameter ) {

		case Settings::AlgorithmActivationHour:

			if ( Value > 23 ) {

				Value = 23; }

			break;

		case Settings::AlgorithmActivationMinute:

			if ( Value > 59 ) {

				Value = 59; }

			break;

		case Settings::AlgorithmActivationSecond:

			if ( Value > 59 ) {

				Value = 59; }

			break;

		case Settings::PlayerVolume:

			if ( Value == 0 ) {

				Value = 1; }

			if ( Value > 100 ) {

				Value = 100; }

			break; }

	NumericParameters[ Parameter ] = Value;
	NumericParameters[ NumericParameter::SettingsTimestamp ] = GetTime();
	
	SaveToFile ( "Settings" ); }

UINT64 Settings::GetNumericParameter ( NumericParameter Parameter ) {

	return NumericParameters[ Parameter ]; }

void Settings::SetTextParameter ( TextParameter Parameter, std::string Value ) {

	TextParameters[ Parameter ] = Value.substr( 0, 256 );
	NumericParameters[ NumericParameter::SettingsTimestamp ] = GetTime();
	
	SaveToFile ( "Settings" ); }

std::string Settings::GetTextParameter ( TextParameter Parameter ) {

	return TextParameters[ Parameter ]; }

bool Settings::SaveToFile ( std::string FilePath ) {

	std::fstream File ( FilePath, std::ios::out );

	if ( File.is_open() ) {

		for ( size_t i = 0; i < Settings::NumericParametersCount; i++ ) {

			File << GetNumericParameter( static_cast <Settings::NumericParameter> ( i ) ) << std::endl; }

		for ( size_t i = 0; i < Settings::TextParametersCount; i++ ) {

			File << GetTextParameter( static_cast <Settings::TextParameter> ( i ) ) << std::endl; }

		File.close();

		return true; }

	return false; }

bool Settings::LoadFromFile ( std::string FilePath ) {

	std::fstream File ( FilePath, std::ios::in );

	if ( File.is_open() ) {

		UINT64 NumericValue;
		std::string TextValue;

		std::vector <UINT64> NumericValues;
		std::vector <std::string> TextValues;

		for ( size_t i = 0; i < Settings::NumericParametersCount; i++ ) {

			File >> NumericValue;

			if ( !File.fail() ) {

				NumericValues.push_back( NumericValue ); }

			else {

				return false; } }

		File.ignore( std::numeric_limits <std::streamsize>::max(), '\n' );

		for ( size_t i = 0; i < Settings::TextParametersCount; i++ ) {

			std::getline( File, TextValue );

			if ( !File.fail() ) {

				TextValues.push_back( TextValue ); }

			else {

				return false; } }

		NumericParameters = NumericValues;
		TextParameters = TextValues;

		File.close();

		return true; }

	return false; }