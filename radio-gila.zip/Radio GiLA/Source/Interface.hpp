#ifndef RADIO_GILA_INTERFACE
#define RADIO_GILA_INTERFACE

#include "CRC32.hpp"
#include "Config.hpp"
#include "Player.hpp"
#include "Playlist.hpp"
#include "Settings.hpp"
#include "Threads.hpp"
#include "Timeline.hpp"
#include "Tracks.hpp"

enum class Tab {

	Playlist,
	Tracks,
	Settings,
	Web

	};

enum class Time {

	Seconds,
	Minutes,
	Hours,
	Day,
	Month,
	Year

	};

class Interface {

	public:

		Interface ( sf::Vector2f Size, Playlist * PlaylistPointer, Tracks * TracksPointer, Player * PlayerPointer, Settings * SettingsPointer );
		~ Interface ( );

		void SetSize ( sf::Vector2f Size );
		sf::Vector2f GetSize ( );

		void SetActiveTab ( Tab ActiveTab );
		Tab GetActiveTab ( );

		UINT64 GetTime ( );
		std::string GetTime ( Time Unit );

		void Update ( sf::RenderWindow &Window, sf::Event Event );
		void Render ( sf::RenderWindow &Window );

	private:

		void Render ( sf::RenderWindow &Window, sf::Vector2f Position, sf::Vector2f Size, sf::Color Color );

		void RenderPlaylistTab ( sf::RenderWindow &Window );
		void RenderTracksTab ( sf::RenderWindow &Window );
		void RenderTracksTabSpecialMode ( sf::RenderWindow &Window );
		void RenderSettingsTab ( sf::RenderWindow &Window );
		void RenderWebTab ( sf::RenderWindow &Window );

		void RenderTabsBar ( sf::RenderWindow &Window );
		void RenderStatusBar ( sf::RenderWindow &Window );
		void RenderNavigationBar ( sf::RenderWindow &Window );
		void RenderSearchBar ( sf::RenderWindow &Window );

		void RecalculateLayout ( );
		
		REAL32 Integral ( REAL32 Value );
		std::string ClockStyle ( UINT64 Time );
		std::string DateStyle ( UINT64 Time );

		void Convert ( UINT64 Value, std::string &Text );
		bool Convert ( std::string Text, UINT64 &Value );
		
		bool ConvertDate ( std::string Text, UINT64 &Value );
		bool ConvertTime ( std::string Text, UINT64 &ValueBegin, UINT64 &ValueLength );

	private:
		
		sf::Vector2f Size;
		
		CRC32 CRC32;

		Playlist * PlaylistPointer;
		Tracks * TracksPointer;
		Player * PlayerPointer;
		Settings * SettingsPointer;
		Timeline * TimelinePointer;

		bool Interrupted;
		bool StatusOnline;
		bool StatusOnAir;

		sf::String Months [12];

		Tab ActiveTab;
		REAL32 TracksTabScroll;

		Track * SelectedTrack;
		Track * HighlightedTrack;
		Playlist::Element * SelectedPlaylistElement;
		Track * SelectedPlaylistElementTrack;

		sf::String PlaylistFieldText [2];
		sf::String TimelineScope;

		size_t CoverIconSelected;
		size_t PlaylistFieldSelected;
		size_t PlaylistFieldHighlighted;
		size_t NavigationIconSelected;

		bool PlaylistTimeError;
		bool PlaylistDateError;
		bool NavigationError; 

		std::vector <Track*> FilteredTracks;

		bool EditMode;
		bool EditModeEntryHighlighted;

		sf::String EditModeStatus;
		sf::String EditModeHeaderText [7];
		sf::String EditModeFieldText [7];
		
		size_t EditModeFieldSelected;
		size_t EditModeFieldHighlighted;
		
		Track EditModeTrackCopy;
		Track EditModeTrackDefault;

		sf::String SettingsFieldText [9];

		size_t SettingsFieldSelected;
		size_t SettingsFieldHighlighted;

		sf::Vector2f TabsBarPosition;
		sf::Vector2f TabsBarSize;

		sf::Vector2f StatusBarPosition;
		sf::Vector2f StatusBarSize;

		sf::Vector2f NavigationBarPosition;
		sf::Vector2f NavigationBarSize;

		sf::Vector2f SearchBarPosition;
		sf::Vector2f SearchBarSize;

		sf::Font ThinFont;
		sf::Font RegularFont;
		sf::Font BoldFont;

		sf::Texture DefaultCover;
		sf::Texture PlaylistIconTexture;
		sf::Texture TracksIconTexture;
		sf::Texture SettingIconTexture;
		sf::Texture WebIconTexture;
		
		sf::Texture PerviousIconTexture;
		sf::Texture StarsIconTexture;
		sf::Texture GearsIconTexture;
		sf::Texture GoIconTexture;
		sf::Texture NextIconTexture;
		sf::Texture TrackingIconTexture;
		sf::Texture AddIconTexture;

		sf::Text StatusSprite;
		sf::Text TimeSprite;
		sf::Text DateSprite;
		sf::Text NavigationSprite;
		sf::Text SearchSprite;
		sf::Text TracksCountSprite;

		sf::Sprite PlaylistIconSprite;
		sf::Sprite TracksIconSprite;
		sf::Sprite SettingsIconSprite;
		sf::Sprite WebIconSprite;

	};

#endif