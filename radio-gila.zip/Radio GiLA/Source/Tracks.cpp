#include "Tracks.hpp"

Tracks::Tracks ( Settings * SettingsPointer ) {

	this->SettingsPointer = SettingsPointer;

	DefaultCover.loadFromFile( SettingsPointer->GetTextParameter( Settings::CoversPath ) + "DefaultCover.jpg" );
	DefaultCover.setSmooth( true );

	Reload(); }

size_t Tracks::GetSize ( ) {

	return List.size(); }

bool Tracks::Reload ( ) {

	DIR * Directory;
	struct dirent * File;
    
	std::vector <Track> PreList;

    if ( Directory = opendir( SettingsPointer->GetTextParameter( Settings::DataPath ).c_str() ) ) {
		
        while ( File = readdir( Directory ) ) {

			if ( strcmp( File->d_name, "." ) != 0 && strcmp( File->d_name, ".." ) != 0 && strcmp( File->d_name, "Playlist" ) != 0 && strcmp( File->d_name, "Playlist [BACKUP]" ) != 0 && strcmp( File->d_name, "Algorithm" ) != 0 ) {
				
				std::fstream DataFile ( ( SettingsPointer->GetTextParameter( Settings::DataPath ) + File->d_name ), std::ios::in );

				if ( DataFile.is_open() ) {

					Track Details;
					std::string IsPlaylist;

					std::getline( DataFile, Details.Title );
					std::getline( DataFile, Details.Artist );
					std::getline( DataFile, Details.Album );
					std::getline( DataFile, Details.Genre );

					DataFile >> Details.Year;
					DataFile >> Details.Lenght;
					DataFile >> Details.Quality;
					DataFile >> Details.Rate;		// R > 10 => R = 10
					DataFile >> Details.Playcount;

					DataFile.ignore( std::numeric_limits <std::streamsize>::max(), '\n' );
					std::getline( DataFile, IsPlaylist );

					if ( IsPlaylist == "TRUE" ) {

						Details.IsPlaylist = true; }

					else {

						Details.IsPlaylist = false; }

					std::getline( DataFile, Details.TrackPath );
					std::getline( DataFile, Details.CoverPath );

					if ( !DataFile.fail() ) {

						Details.DataPath = File->d_name;

						if ( !Details.Cover.loadFromFile( SettingsPointer->GetTextParameter( Settings::CoversPath ) + Details.CoverPath ) ) {

							Details.Cover = DefaultCover; }

						else {

							Details.Cover.setSmooth( true ); }
						
						PreList.push_back( Details ); }
					
					DataFile.close(); } } }
        
        closedir( Directory ); }

	else {

		return false; }

	Mutex.lock();

	List.clear();

	for ( size_t i = 0; i < PreList.size(); i++ ) {

		List.push_back( PreList[i] );
		
		for ( size_t j = i + 1; j < PreList.size(); j++ ) {

			if ( PreList[i].Title == PreList[j].Title && PreList[i].Artist == PreList[j].Artist && PreList[i].Album == PreList[j].Album ) {

				List.pop_back();

				break; } } }

	Mutex.unlock();

	return true; }

bool Tracks::Create ( Track Data ) {

	std::fstream DataFile ( SettingsPointer->GetTextParameter( Settings::DataPath ) + Data.DataPath, std::ios::out );

	if ( DataFile.is_open() ) {

		DataFile << Data.Title << std::endl;
		DataFile << Data.Artist << std::endl;
		DataFile << Data.Album << std::endl;
		DataFile << Data.Genre << std::endl;
		DataFile << Data.Year << std::endl;
		DataFile << Data.Lenght << std::endl;
		DataFile << Data.Quality << std::endl;
		DataFile << Data.Rate << std::endl;
		DataFile << Data.Playcount << std::endl;

		if ( Data.IsPlaylist ) {

			DataFile << "TRUE" << std::endl; }

		else {

			DataFile << "FALSE" << std::endl; }

		DataFile << Data.TrackPath << std::endl;
		DataFile << Data.CoverPath << std::endl;

		DataFile.close(); }

	else {

		return false; }

	SetTimestamp( SettingsPointer->GetTime() );

	return true; }

std::vector <Track*> Tracks::Search ( std::string Filter ) {

	Filter = ToUpper( Filter );

	if ( Filter != "" ) {

		std::vector <Track*> Result;

		for ( size_t i = 0; i < List.size(); i++ ) {

			bool Match = false;

			if ( ToUpper( List[i].Title ).find( Filter ) != std::string::npos ) {

				Match = true; }

			else if ( ToUpper( List[i].Artist ).find( Filter ) != std::string::npos ) {

				Match = true; }

			else if ( ToUpper( List[i].Album ).find( Filter ) != std::string::npos ) {

				Match = true; }

			else if ( ToUpper( List[i].Genre ).find( Filter ) != std::string::npos ) {

				Match = true; }

			else {

				std::string Text;

				Convert( List[i].Year, Text );

				if ( Text.find( Filter ) != std::string::npos ) {

					Match = true; } }

			if ( Match ) {

				Result.push_back( &List[i] ); } }

		return Result; }

	else {

		std::vector <Track*> Result;

		for ( size_t i = 0; i < List.size(); i++ ) {

			Result.push_back( &List[i] ); }

		return Result; } }

Track * Tracks::Search ( std::string Title, std::string Artist, std::string Album ) {

	for ( size_t i = 0; i < List.size(); i++ ) {

		if ( List[i].Title == Title && List[i].Artist == Artist && List[i].Album == Album ) {

			return &List[i]; } }

	return NULL; }

void Tracks::SetTimestamp ( UINT64 Timestamp ) {

	return SettingsPointer->SetNumericParameter( Settings::TracksTimestamp, Timestamp ); }

UINT64 Tracks::GetTimestamp ( ) {

	return SettingsPointer->GetNumericParameter( Settings::TracksTimestamp ); }

std::string Tracks::ToUpper ( std::string Text ) {

	for ( size_t i = 0; i < Text.size(); i++ ) {

		Text[i] = toupper( Text[i] ); }

	return Text; }

std::string Tracks::ToLower ( std::string Text ) {

	for ( size_t i = 0; i < Text.size(); i++ ) {

		Text[i] = tolower( Text[i] ); }

	return Text; }

void Tracks::Convert ( UINT64 Value, std::string &Text ) {

	Text.clear();

	do {

		Text = (char) ( Value % 10 + 48 ) + Text;
		Value = Value / 10; }

	while ( Value != 0 ); }

bool Tracks::Convert ( std::string Text, UINT64 &Value ) {

	Value = 0;

	if ( Text.size() == 0 ) {

		return false; }

	for ( size_t i = 0; i < Text.size(); i++ ) {

		if ( Text[i] >= 48 && Text[i] <= 57 ) {

			Value = Value * 10;
			Value = Value + ( Text[i] - 48 ); }

		else {

			return false; } }

	return true; }