#include "Player.hpp"

void Player::Enable ( ) {
	
	if ( !Enabled ) {

		ManageThread.launch(); }
		
	Enabled = true; }

void Player::Disable ( ) {

	StopSingleTrack();

	if ( Enabled ) {

		Enabled = false;

		ManageThread.wait(); } }

bool Player::IsEnabled ( ) {

	return Enabled; }

void Player::Mute ( ) {

	Music.setVolume( 0 );
	SingleMusic.setVolume( 0 );

	SettingsPointer->SetNumericParameter( Settings::PlayerMuted, 1 ); }

void Player::Unmute ( ) {

	Music.setVolume( GetVolume() );
	SingleMusic.setVolume( GetVolume() );
	
	SettingsPointer->SetNumericParameter( Settings::PlayerMuted, 0 ); }

bool Player::IsMuted ( ) {

	return ( SettingsPointer->GetNumericParameter( Settings::PlayerMuted ) != 0 ); }

void Player::SetVolume ( REAL32 Volume ) {

	if ( !IsMuted() ) {

		Music.setVolume( Volume );
		SingleMusic.setVolume( Volume ); }
	
	SettingsPointer->SetNumericParameter( Settings::PlayerVolume, (UINT64) Volume ); }

REAL32 Player::GetVolume ( ) {

	return (REAL32) ( SettingsPointer->GetNumericParameter( Settings::PlayerVolume ) ); }

void Player::PlaySingleTrack ( std::string Title, std::string Artist, std::string Album ) {

	Track * TrackPointer = TracksPointer->Search( Title, Artist, Album );

	SingleMusic.stop();

	while ( Interrupted );

	if ( TrackPointer ) {

		if ( SingleMusic.openFromFile( SettingsPointer->GetTextParameter( Settings::TracksPath ) + TrackPointer->TrackPath ) ) {

			Interrupted = true; } } }

void Player::StopSingleTrack ( ) {

	SingleMusic.stop(); }

bool Player::IsSingleTrackPlaying ( ) {

	return Interrupted; }

void Player::Manage ( ) {

	bool Playable;
	size_t PlaylistIndex;
	Playlist::Element PlaylistElement;

	while ( Enabled ) {
		
		Mutex.lock();
		
		if ( PlaylistPointer->GetSize() > 0 ) {
			
			if ( PlaylistPointer->GetTimestamp() != PlaylistTimestamp ) {
				
				for ( PlaylistIndex = 0; PlaylistIndex < PlaylistPointer->GetSize(); PlaylistIndex++ ) {				

					if ( (*PlaylistPointer)[ PlaylistIndex ]->Input >= SettingsPointer->GetTime() ) {

						break; } }
				
				if ( PlaylistIndex > 0 ) {

					if ( ( (*PlaylistPointer)[ PlaylistIndex - 1 ]->Input + (*PlaylistPointer)[ PlaylistIndex - 1 ]->Lenght ) > SettingsPointer->GetTime() ) {

						PlaylistIndex--; } }
				
				PlaylistTimestamp = PlaylistPointer->GetTimestamp(); }
			
			if ( PlaylistPointer->GetSize() != PlaylistIndex ) {
				
				if ( (*PlaylistPointer)[ PlaylistIndex ]->Title != PlaylistElement.Title || (*PlaylistPointer)[ PlaylistIndex ]->Artist != PlaylistElement.Artist ||
					 (*PlaylistPointer)[ PlaylistIndex ]->Album != PlaylistElement.Album || (*PlaylistPointer)[ PlaylistIndex ]->Begin != PlaylistElement.Begin || 
					 (*PlaylistPointer)[ PlaylistIndex ]->Input != PlaylistElement.Input || (*PlaylistPointer)[ PlaylistIndex ]->Lenght != PlaylistElement.Lenght ) {
					
					Playable = false;
					PlaylistElement = *(*PlaylistPointer)[ PlaylistIndex ];
					
					Track * TrackPointer = TracksPointer->Search( PlaylistElement.Title, PlaylistElement.Artist, PlaylistElement.Album );

					if ( TrackPointer ) {
					
						TrackPointer->Playcount = TrackPointer->Playcount + 1;
						TracksPointer->Create( *TrackPointer );
						
						if ( Music.openFromFile( SettingsPointer->GetTextParameter( Settings::TracksPath ) + TrackPointer->TrackPath ) ) {

							Playable = true; } } }
				
				if ( Music.getStatus() == sf::Music::Status::Stopped && Playable ) {
					
					if ( PlaylistElement.Input <= SettingsPointer->GetTime() ) {
						
						Music.play();
						Music.setPlayingOffset( sf::seconds( (REAL32) ( PlaylistElement.Begin + SettingsPointer->GetTime() - PlaylistElement.Input ) ) ); } }
				
				if ( ( PlaylistElement.Input + PlaylistElement.Lenght ) <= SettingsPointer->GetTime() ) {
					
					Music.stop();

					PlaylistIndex++; } } }

		else {

			if ( Music.getStatus() == sf::Music::Status::Playing ) {

				Music.stop(); } }
		
		Mutex.unlock();

		if ( Interrupted ) {

			Music.stop();
			SingleMusic.play();
			
			while ( SingleMusic.getStatus() != sf::Music::Status::Stopped ) {

				sf::sleep( sf::milliseconds( 10 ) ); }

			Interrupted = false; }
	
		sf::sleep( sf::milliseconds( 10 ) ); } }