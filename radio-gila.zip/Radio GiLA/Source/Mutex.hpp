#ifndef RADIO_GILA_MUTEX
#define RADIO_GILA_MUTEX

#include "Config.hpp"

extern sf::Mutex Mutex;

#endif