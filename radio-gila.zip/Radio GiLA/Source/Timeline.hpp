#ifndef RADIO_GILA_TIMELINE
#define RADIO_GILA_TIMELINE

#include "Config.hpp"
#include "Playlist.hpp"

class Timeline {

	public:

		Timeline ( Playlist * PlaylistPointer, Settings * SettingsPointer );

		void SetTracking ( bool Tracking );
		bool GetTracking ( );

		void SetBegin ( UINT64 Time );
		UINT64 GetBegin ( );

		void SetEnd ( UINT64 Time );
		UINT64 GetEnd ( );

		void SetCenter ( UINT64 Time );
		UINT64 GetCenter ( );

		bool SetScope ( std::string Scope );
		std::string GetScope ( );

		Playlist::Element * GetSelectedPlaylistElement ( );

		void Render ( sf::RenderWindow &Window, sf::Vector2f Position, sf::Vector2f Size );

	private:

		void Convert ( UINT64 Value, std::string &Text );
		bool Convert ( std::string Text, UINT64 &Value );

	private:

		Playlist * PlaylistPointer;
		Settings * SettingsPointer;

		bool Tracking;

		UINT64 Begin;
		UINT64 End;

		UINT64 PlaylistTimestamp;

		Playlist::Element * SelectedPlaylistElement;
		std::vector <Playlist::Element*> PlaylistElements;

	};

#endif