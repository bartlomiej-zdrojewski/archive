#ifndef RADIO_GILA_CRC32
#define RADIO_GILA_CRC32

#include "Config.hpp"

class CRC32 { 

	public:

		CRC32 ( );
		~ CRC32 ( );

		std::string Generate ( std::string Data );

	private:

		void GenerateLookupTable ( );

	private:
		
		UINT32 * LookupTable;

	};

#endif