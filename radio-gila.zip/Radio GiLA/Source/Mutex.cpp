#include "Mutex.hpp"

sf::Mutex Mutex;