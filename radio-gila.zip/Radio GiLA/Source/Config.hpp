#ifndef RADIO_GILA_CONFIG
#define RADIO_GILA_CONFIG

#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Network.hpp>

#include <iostream> // TEMP
#include <fstream>
#include <vector>
#include "dirent.h" // <dirent>

typedef signed char INT8;
typedef unsigned char UINT8;
typedef signed short int INT16;
typedef unsigned short int UINT16;
//typedef signed long int INT32;
//typedef unsigned long int UINT32;
typedef signed long long int INT64;
typedef unsigned long long int UINT64;

typedef float REAL32;
typedef double REAL64;

#endif