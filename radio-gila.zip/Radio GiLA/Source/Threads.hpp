#ifndef RADIO_GILA_THREADS
#define RADIO_GILA_THREADS

#include "CRC32.hpp"
#include "Algorithm.hpp"
#include "Config.hpp"
#include "Player.hpp"
#include "Playlist.hpp"
#include "Settings.hpp"
#include "Tracks.hpp"

struct ExternalDataStruct {

	Playlist * PlaylistPointer;
	Tracks * TracksPointer;
	//Player * PlayerPointer;
	Algorithm * AlgorithmPointer; // NOT YET
	Settings * SettingsPointer;

	bool * InterfaceInterrupted;
	sf::String * InterfaceStatus;
	sf::String * InterfaceField;

	sf::Text * FilterText;
	std::vector <Track*> * FilteredTracks;

	Track * TrackCopy;

	};

void CreateTrack ( );
void UpdateSettings ( );

bool FileExists ( std::string Path );
bool FileCopy ( std::string InputPath, std::string OutputPath );
std::string FileExtension ( std::string Path );

extern ExternalDataStruct ExternalData;
extern sf::Thread CreateTrackThread;
extern sf::Thread UpdateSettingsThread;

#endif