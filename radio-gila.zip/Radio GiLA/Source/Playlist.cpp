#include "Playlist.hpp"

Playlist::Playlist ( Settings * SettingsPointer ) {

	this->SettingsPointer = SettingsPointer;

	LoadFromFile( "Playlist" ); }

/*
Playlist::Playlist ( std::string Data, UINT64 Time ) {

	std::vector <std::string> SubData;
	
	for ( size_t Start = 0; Start < Data.size(); Start++ ) {
		
		size_t Size = Data.find( "\n", Start );

		if ( Size == std::string::npos ) {
			
			Size = Data.size(); }

		Size = Size - Start;

		SubData.push_back( Data.substr( Start, Size ) );
		
		Start = Start + Size; }

	for ( size_t i = 0; i < ( SubData.size() / 6 ); i++ ) {

		Element Element;

		if ( SubData[i*6] != "" ) {

			Element.Title = SubData[i*6]; }

		else {

			continue; }

		if ( SubData[i*6+1] != "" ) {

			Element.Artist = SubData[i*6+1]; }

		else {

			continue; }

		if ( SubData[i*6+2] != "" ) {

			Element.Album = SubData[i*6+2]; }

		else {

			continue; }
		
		if ( !Convert( SubData[i*6+3], Element.Lenght ) ) {

			continue; }
		
		if ( !Convert( SubData[i*6+4], Element.Begin ) ) {

			continue; }

		if ( !Convert( SubData[i*6+5], Element.Input ) ) {

			continue; }

		Elements.push_back( Element ); }

	// sort

	for ( size_t i = 0; i < Elements.size(); i++ ) {
		
		if ( Elements[i].Input < Time ) {
			
			continue; }

		if ( Sections.empty() ) {

			if ( Elements[i].Input == Time ) {
				
				Sections.push( Section { 0, 0, &Elements[i] } ); }

			if ( Elements[i].Input > Time ) {
				
				Section DiSection [2];

				DiSection[0].Input = Time;
				DiSection[0].Lenght = Elements[i].Input - Time;
				DiSection[0].Element = NULL;

				DiSection[1].Input = 0;
				DiSection[1].Lenght = 0;
				DiSection[1].Element = &Elements[i];

				Sections.push( DiSection[0] );
				Sections.push( DiSection[1] ); } }

		else {
			
			if ( Elements[i].Input == ( Elements[i-1].Input + Elements[i-1].Lenght ) ) {

				Sections.push( Section { 0, 0, &Elements[i] } ); }

			else {

				Section DiSection [2];

				DiSection[0].Input = ( Elements[i-1].Input + Elements[i-1].Lenght );
				DiSection[0].Lenght = Elements[i].Input - DiSection[0].Input;
				DiSection[0].Element = NULL;

				DiSection[1].Input = 0;
				DiSection[1].Lenght = 0;
				DiSection[1].Element = &Elements[i];

				Sections.push( DiSection[0] );
				Sections.push( DiSection[1] ); } } } }

*/

void Playlist::Clear ( ) {

	SaveToFile( "Playlist [BACKUP]" );

	Mutex.lock();

	Elements.clear();

	Mutex.unlock();

	SaveToFile( "Playlist" ); }

size_t Playlist::GetSize ( ) {

	return Elements.size(); }

/*
Playlist::Element Playlist::GetElement ( ) {

	Element Data;

	if ( !Sections.empty() ) {

		if ( Sections.front().Element != NULL ) {

			Data = *Sections.front().Element;

			Sections.pop(); }

		else {

			Data.Title = "";
			Data.Artist = "";
			Data.Album = "";
			Data.Lenght = Sections.front().Lenght;
			Data.Begin = 0;
			Data.Input = Sections.front().Input;

			Sections.pop(); } }

	else {

		Data.Title = "";
		Data.Artist = "";
		Data.Album = "";
		Data.Lenght = _UI64_MAX;
		Data.Begin = 0;
		Data.Input = 0; }

	return Data; }

*/

bool Playlist::CreateElement ( Element Data ) {

	for ( size_t i = 0; i < Elements.size(); i++ ) {

		if ( ( ( Data.Input < Elements[i].Input ) && ( ( Data.Input + Data.Lenght ) > Elements[i].Input ) ) || ( ( Data.Input < ( Elements[i].Input + Elements[i].Lenght ) ) && ( ( Data.Input + Data.Lenght ) > ( Elements[i].Input + Elements[i].Lenght ) ) ) || ( ( Data.Input >= Elements[i].Input ) && ( ( Data.Input + Data.Lenght ) <= ( Elements[i].Input + Elements[i].Lenght ) ) ) ) {

			return false; } }
	
	Mutex.lock();

	Elements.push_back( Data );
	SortElements();

	Mutex.unlock();

	SaveToFile( "Playlist" );

	return true; }

bool Playlist::CreateElement ( Element Data, size_t &Index ) {

	for ( size_t i = 0; i < Elements.size(); i++ ) {

		if ( ( ( Data.Input < Elements[i].Input ) && ( ( Data.Input + Data.Lenght ) > Elements[i].Input ) ) || ( ( Data.Input < ( Elements[i].Input + Elements[i].Lenght ) ) && ( ( Data.Input + Data.Lenght ) > ( Elements[i].Input + Elements[i].Lenght ) ) ) || ( ( Data.Input >= Elements[i].Input ) && ( ( Data.Input + Data.Lenght ) <= ( Elements[i].Input + Elements[i].Lenght ) ) ) ) {

			Index = i;

			return false; } }
	
	Mutex.lock();

	Elements.push_back( Data );
	SortElements();

	Mutex.unlock();

	SaveToFile( "Playlist" );

	for ( size_t i = 0; i < Elements.size(); i++ ) {

		if ( Data.Input == Elements[i].Input ) {

			Index = i;

			break; } }

	return true; }

void Playlist::DeleteElement ( Element * Data ) {

	Mutex.lock();

	for ( size_t i = 0 ; i < Elements.size(); i++ ) {

		if ( Elements[i].Input == Data->Input ) {

			Elements.erase( Elements.begin() + i );

			break; } }

	SortElements();
	
	Mutex.unlock();

	SaveToFile( "Playlist" ); }

bool Playlist::LoadFromFile ( std::string FilePath ) {

	std::fstream File ( FilePath, std::ios::in );

	if ( File.is_open() ) {

		Mutex.lock();

		Elements.clear();

		while ( !File.eof() ) {
			
			Element Data;

			std::getline( File, Data.Title );
			std::getline( File, Data.Artist );
			std::getline( File, Data.Album );
			
			File >> Data.Lenght;
			File >> Data.Begin;
			File >> Data.Input;

			File.ignore( std::numeric_limits <std::streamsize>::max(), '\n' );

			if ( !File.fail() ) {
				
				bool Conflict = false;

				for ( size_t i = 0; i < Elements.size(); i++ ) {

					if ( ( ( Data.Input < Elements[i].Input ) && ( ( Data.Input + Data.Lenght ) > Elements[i].Input ) ) || ( ( Data.Input < ( Elements[i].Input + Elements[i].Lenght ) ) && ( ( Data.Input + Data.Lenght ) > ( Elements[i].Input + Elements[i].Lenght ) ) ) || ( ( Data.Input >= Elements[i].Input ) && ( ( Data.Input + Data.Lenght ) <= ( Elements[i].Input + Elements[i].Lenght ) ) ) ) {

						Conflict = true;

						break; } }

				if ( !Conflict ) {

					Elements.push_back( Data ); } } }

		SortElements();

		Mutex.unlock();

		File.close();

		return true; }

	return false; }

bool Playlist::SaveToFile ( std::string FilePath ) {

	std::fstream File ( FilePath, std::ios::out );

	if ( File.is_open() ) {

		for ( size_t i = 0; i < Elements.size(); i++ ) {

			File << Elements[i].Title << std::endl;
			File << Elements[i].Artist << std::endl;
			File << Elements[i].Album << std::endl;
			File << Elements[i].Lenght << std::endl;
			File << Elements[i].Begin << std::endl;
			File << Elements[i].Input << std::endl; }

		File.close();

		return true; }

	return false; }

void Playlist::SetTimestamp ( UINT64 Timestamp ) {
	
	SettingsPointer->SetNumericParameter( Settings::PlaylistTimestamp, Timestamp ); }

UINT64 Playlist::GetTimestamp ( ) {

	return SettingsPointer->GetNumericParameter( Settings::PlaylistTimestamp ); }

void Playlist::SortElements ( ) {

	for ( size_t i = 1; i < Elements.size(); i++ ) {

		Element Value = Elements[i];

		for ( size_t j = i; j > 0; j-- ) {

			if ( Elements[j-1].Input > Value.Input ) {

				Elements[j] = Elements[j-1]; }

			else {

				break; }

			Elements[j-1] = Value; } }
	
	SetTimestamp( SettingsPointer->GetTime() ); }

bool Playlist::Convert ( std::string Text, UINT64 &Value ) {

	Value = 0;

	if ( Text.size() == 0 ) {

		return false; }

	for ( size_t i = 0; i < Text.size(); i++ ) {

		if ( Text[i] >= 48 && Text[i] <= 57 ) {

			Value = Value * 10;
			Value = Value + ( Text[i] - 48 ); }

		else {

			return false; } }

	return true; }