#ifndef RADIO_GILA_ALGORITHM
#define RADIO_GILA_ALGORITHM

#include "Config.hpp"
#include "Playlist.hpp"
#include "Settings.hpp"
#include "Tracks.hpp"

class Algorithm {

	public:

		Algorithm ( Playlist * PlaylistPointer, Tracks * TracksPointer, Settings * SettingsPointer );

		void SetActivationTime ( UINT64 Hour, UINT64 Minute, UINT64 Second );
		UINT64 GetActivationTime ( );

		bool IsPerformed ( );
		void Perform ( );

		bool LoadIntervals ( std::string FilePath );

		void SetTimestamp ( UINT64 Timestamp );
		UINT64 GetTimestamp ( );

	private:

		void SortIntervals ( );

	private:

		Playlist * PlaylistPointer;
		Settings * SettingsPointer;
		Tracks * TracksPointer;
		
		std::vector <UINT64> Intervals;

	};

#endif