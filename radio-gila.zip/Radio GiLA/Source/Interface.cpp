#include "Interface.hpp"

Interface::Interface ( sf::Vector2f Size, Playlist * PlaylistPointer, Tracks * TracksPointer, Player * PlayerPointer, Settings * SettingsPointer ) {

	this->Size = Size;
	this->PlaylistPointer = PlaylistPointer;
	this->TracksPointer = TracksPointer;
	this->SettingsPointer = SettingsPointer;
	this->PlayerPointer = PlayerPointer;

	TimelinePointer = new Timeline ( PlaylistPointer, SettingsPointer );
	TimelinePointer->SetCenter( GetTime() );

	Interrupted = false;
	StatusOnline = false;
	StatusOnAir = false;

	ActiveTab = Tab::Playlist;
	TracksTabScroll = 0.00f;

	SelectedTrack = NULL;
	HighlightedTrack = NULL;
	SelectedPlaylistElement = NULL;

	CoverIconSelected = 255;
	PlaylistFieldSelected = 255;
	PlaylistFieldHighlighted = 255;
	NavigationIconSelected = 255;

	PlaylistTimeError = false;
	PlaylistDateError = false;
	NavigationError = false;

	TimelineScope = TimelinePointer->GetScope();
	FilteredTracks = TracksPointer->Search();

	EditMode = false;
	EditModeEntryHighlighted = false;
	
	EditModeFieldSelected = 255;
	EditModeFieldHighlighted = 255;

	EditModeTrackDefault.Rate = 5;
	EditModeTrackDefault.Playcount = 0;
	EditModeTrackDefault.IsPlaylist = true;
	EditModeTrackDefault.DataPath = "";

	SettingsFieldSelected = 255;
	SettingsFieldHighlighted = 255;

	TabsBarPosition.x = 0.00f;
	TabsBarPosition.y = 0.00f;

	TabsBarSize.x = 100.00f;
	TabsBarSize.y = Size.y;

	StatusBarPosition.x = 100.00f;
	StatusBarPosition.y = 0.00f;

	StatusBarSize.x = Size.x - 100.00f;
	StatusBarSize.y = 30.00f;
	
	NavigationBarPosition.x = StatusBarPosition.x;
	NavigationBarPosition.y = TabsBarSize.y * 0.70f;

	NavigationBarSize.x = StatusBarSize.x;
	NavigationBarSize.y = 30.00f;

	SearchBarPosition.x = 100.00f;
	SearchBarPosition.y = Size.y - 30.00f;

	SearchBarSize.x = Size.x - 100.00f;
	SearchBarSize.y = 30.00f;

	Months[0] = L"stycznia";
	Months[1] = L"lutego";
	Months[2] = L"marca";
	Months[3] = L"kwietnia";
	Months[4] = L"maja";
	Months[5] = L"czerwca";
	Months[6] = L"lipca";
	Months[7] = L"sierpnia";
	Months[8] = L"wrze�nia";
	Months[9] = L"pa�dziernika";
	Months[10] = L"listopada";
	Months[11] = L"grudnia";

	EditModeHeaderText[0] = L"Tytu�";
	EditModeHeaderText[1] = L"Artysta";
	EditModeHeaderText[2] = L"Album";
	EditModeHeaderText[3] = L"Gatunek";
	EditModeHeaderText[4] = L"Rok";
	EditModeHeaderText[5] = L"Plik";
	EditModeHeaderText[6] = L"Ok�adka";

	DefaultCover.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "DefaultCover.png" );
	DefaultCover.setSmooth( true );
	
	StarsIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "StarsIcon.png" );
	StarsIconTexture.setSmooth( true );

	GearsIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "GearsIcon.png" );
	GearsIconTexture.setSmooth( true );

	PerviousIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "PerviousIcon.png" );
	PerviousIconTexture.setSmooth( true );

	GoIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "GoIcon.png" );
	GoIconTexture.setSmooth( true );

	NextIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "NextIcon.png" );
	NextIconTexture.setSmooth( true );

	TrackingIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "TrackingIcon.png" );
	TrackingIconTexture.setSmooth( true );

	if ( ThinFont.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "ThinFont.ttf" ) ) {

		StatusSprite.setFont( ThinFont );
		StatusSprite.setCharacterSize( 18 );
		StatusSprite.setString( L"0000" );
		StatusSprite.setPosition( Integral( StatusBarPosition.x + 5.00f ), Integral( StatusBarPosition.y + ( StatusBarSize.y - StatusSprite.getGlobalBounds().height ) / 2.00f - 3.00f ) );

		DateSprite.setFont( ThinFont );
		DateSprite.setCharacterSize( 18 );
		DateSprite.setString( "0000" );
		DateSprite.setPosition( Integral( ( StatusBarPosition.x + StatusBarSize.x ) - ( DateSprite.getGlobalBounds().width + 5.00f ) ), Integral( StatusBarPosition.y + ( StatusBarSize.y - DateSprite.getGlobalBounds().height ) / 2.00f - 3.00f ) );

		SearchSprite.setFont( ThinFont );
		SearchSprite.setCharacterSize( 18 );
		SearchSprite.setString( "0000" );
		SearchSprite.setPosition( Integral( SearchBarPosition.x + 5.00f ), Integral( SearchBarPosition.y + ( SearchBarSize.y - SearchSprite.getGlobalBounds().height ) / 2.00f - 3.00f ) );
		SearchSprite.setString( "" );

		TracksCountSprite.setFont( ThinFont );
		TracksCountSprite.setCharacterSize( 18 );
		TracksCountSprite.setString( "0000" );
		TracksCountSprite.setPosition( Integral( ( SearchBarPosition.x + SearchBarSize.x ) - ( TracksCountSprite.getGlobalBounds().width + 5.00f ) ), Integral( SearchBarPosition.y + ( SearchBarSize.y - TracksCountSprite.getGlobalBounds().height ) / 2.00f - 3.00f ) );

		// ...

		}

	if ( RegularFont.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "RegularFont.ttf" ) ) {

		TimeSprite.setFont( RegularFont );
		TimeSprite.setCharacterSize( 18 );
		TimeSprite.setString( "00 : 00 : 00" );
		TimeSprite.setPosition( ( StatusBarPosition.x + StatusBarSize.x / 2.00f ) - ( TimeSprite.getGlobalBounds().width / 2.00f ), StatusBarPosition.y + ( StatusBarSize.y - TimeSprite.getGlobalBounds().height ) / 2.00f - 3.00f );

		NavigationSprite.setFont( RegularFont );
		NavigationSprite.setCharacterSize( 18 );
		NavigationSprite.setString( "0000" );
		NavigationSprite.setPosition( sf::Vector2f( Integral( NavigationBarPosition.x + 5.00f ), Integral( NavigationBarPosition.y + ( NavigationBarSize.y - NavigationSprite.getGlobalBounds().height ) / 2.00f - 2.00f ) ) );

		// ...

		}

	if ( BoldFont.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "BoldFont.ttf" ) ) {

		// ...

		}

	if ( PlaylistIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "PlaylistIcon.png", sf::IntRect( 0, 0, 90, 90 ) ) ) {

		PlaylistIconTexture.setSmooth( true );
		PlaylistIconSprite.setTexture( PlaylistIconTexture );
		PlaylistIconSprite.setColor( sf::Color( 250, 250, 250 ) );
		PlaylistIconSprite.setPosition( 5.00f, ( ( TabsBarSize.y - 360.00f ) / 2.00f ) + 0.00f ); }
	
	if ( TracksIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "TracksIcon.png", sf::IntRect( 0, 0, 90, 90 ) ) ) {

		TracksIconTexture.setSmooth( true );
		TracksIconSprite.setTexture( TracksIconTexture );
		TracksIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		TracksIconSprite.setPosition( 5.00f, ( ( TabsBarSize.y - 360.00f ) / 2.00f ) + 90.00f ); }

	if ( SettingIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "SettingsIcon.png", sf::IntRect( 0, 0, 90, 90 ) ) ) {

		SettingIconTexture.setSmooth( true );
		SettingsIconSprite.setTexture( SettingIconTexture );
		SettingsIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		SettingsIconSprite.setPosition( 5.00f, ( ( TabsBarSize.y - 360.00f ) / 2.00f ) + 180.00f ); }

	if ( WebIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "WebIcon.png", sf::IntRect( 0, 0, 90, 90 ) ) ) {

		WebIconTexture.setSmooth( true );
		WebIconSprite.setTexture( WebIconTexture );
		WebIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		WebIconSprite.setPosition( 5.00f, ( ( TabsBarSize.y - 360.00f ) / 2.00f ) + 270.00f ); }

	if ( AddIconTexture.loadFromFile( SettingsPointer->GetTextParameter( Settings::GraphicsPath ) + "AddIcon.png" ) ) {

		AddIconTexture.setSmooth( true ); }

	else {

		AddIconTexture = DefaultCover; }

	std::string TimeCorrectionText;
	std::string PlayerVolumeText;
	std::string AlgorithmActivationHourText;
	std::string AlgorithmActivationMinuteText;
	std::string AlgorithmActivationSecondText;

	Convert( abs( (INT64) SettingsPointer->GetNumericParameter( Settings::TimeCorrection ) ), TimeCorrectionText );
	Convert( SettingsPointer->GetNumericParameter( Settings::PlayerVolume ), PlayerVolumeText );
	Convert( SettingsPointer->GetNumericParameter( Settings::AlgorithmActivationHour ), AlgorithmActivationHourText );
	Convert( SettingsPointer->GetNumericParameter( Settings::AlgorithmActivationMinute ), AlgorithmActivationMinuteText );
	Convert( SettingsPointer->GetNumericParameter( Settings::AlgorithmActivationSecond ), AlgorithmActivationSecondText );
				
	SettingsFieldText[0] = ( (INT64) SettingsPointer->GetNumericParameter( Settings::TimeCorrection ) >= 0 ? "+ " : "- " ) + TimeCorrectionText;
	SettingsFieldText[1] = PlayerVolumeText;
	SettingsFieldText[2] = ( "0" + AlgorithmActivationHourText ).substr( AlgorithmActivationHourText.size() - 1 );
	SettingsFieldText[3] = ( "0" + AlgorithmActivationMinuteText ).substr( AlgorithmActivationMinuteText.size() - 1 );
	SettingsFieldText[4] = ( "0" + AlgorithmActivationSecondText ).substr( AlgorithmActivationSecondText.size() - 1 );
	SettingsFieldText[5] = SettingsPointer->GetTextParameter( Settings::DataPath );
	SettingsFieldText[6] = SettingsPointer->GetTextParameter( Settings::TracksPath );
	SettingsFieldText[7] = SettingsPointer->GetTextParameter( Settings::CoversPath );
	SettingsFieldText[8] = SettingsPointer->GetTextParameter( Settings::GraphicsPath );


	ExternalData.PlaylistPointer = PlaylistPointer;
	ExternalData.TracksPointer = TracksPointer;
	//ExternalData.PlayerPointer = PlayerPointer;
	ExternalData.SettingsPointer = SettingsPointer;

	ExternalData.InterfaceInterrupted = &Interrupted;
	ExternalData.InterfaceStatus = &EditModeStatus;
	ExternalData.InterfaceField = EditModeFieldText;

	ExternalData.FilterText = &SearchSprite;
	ExternalData.FilteredTracks = &FilteredTracks;

	ExternalData.TrackCopy = &EditModeTrackCopy;


	}

Interface::~Interface ( ) {

	while ( Interrupted ) {

		sf::sleep( sf::milliseconds( 10 ) ); }

	delete TimelinePointer; }

void Interface::SetSize ( sf::Vector2f Size ) {

	this->Size = Size;
	
	RecalculateLayout(); }

sf::Vector2f Interface::GetSize ( ) {

	return Size; }

void Interface::SetActiveTab ( Tab ActiveTab ) {

	this->ActiveTab = ActiveTab;

	if ( ActiveTab == Tab::Playlist ) {

		PlaylistIconSprite.setColor( sf::Color( 250, 250, 250 ) );
		TracksIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		SettingsIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		WebIconSprite.setColor( sf::Color( 50, 150, 250 ) ); }

	if ( ActiveTab == Tab::Tracks ) {

		PlaylistIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		TracksIconSprite.setColor( sf::Color( 250, 250, 250 ) );
		SettingsIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		WebIconSprite.setColor( sf::Color( 50, 150, 250 ) ); }

	if ( ActiveTab == Tab::Settings ) {

		PlaylistIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		TracksIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		SettingsIconSprite.setColor( sf::Color( 250, 250, 250 ) );
		WebIconSprite.setColor( sf::Color( 50, 150, 250 ) ); }

	if ( ActiveTab == Tab::Web ) {

		PlaylistIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		TracksIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		SettingsIconSprite.setColor( sf::Color( 50, 150, 250 ) );
		WebIconSprite.setColor( sf::Color( 250, 250, 250 ) ); } }

Tab Interface::GetActiveTab ( ) {

	return ActiveTab; }

UINT64 Interface::GetTime ( ) {

	return SettingsPointer->GetTime(); }

std::string Interface::GetTime ( Time Unit ) {

	std::string Result;

	time_t TimeData = GetTime();
	struct tm * TimeStructure = new struct tm;
	
	localtime_s( TimeStructure, &TimeData );

	switch ( Unit ) {

		case Time::Seconds:

			Convert( TimeStructure->tm_sec, Result );

			break;

		case Time::Minutes:

			Convert( TimeStructure->tm_min, Result );

			break;

		case Time::Hours:

			Convert( TimeStructure->tm_hour, Result );

			break;

		case Time::Day:

			Convert( TimeStructure->tm_mday, Result );

			break;

		case Time::Month:

			Convert( TimeStructure->tm_mon + 1, Result );

			break;

		case Time::Year:

			Convert( TimeStructure->tm_year + 1900, Result );

			break;

		default:

			Result = "0";

			break; };

	delete TimeStructure;

	return Result; }

void Interface::Update ( sf::RenderWindow &Window, sf::Event Event ) {

	if ( Interrupted ) {

		return; }

	if ( Event.type == sf::Event::MouseButtonReleased && Event.mouseButton.button == sf::Mouse::Left ) {

		sf::Vector2f Mouse ( (REAL32) sf::Mouse::getPosition( Window ).x, (REAL32) sf::Mouse::getPosition( Window ).y );	

		if ( Mouse.x >= PlaylistIconSprite.getPosition().x && Mouse.x < ( PlaylistIconSprite.getPosition().x + PlaylistIconSprite.getTexture()->getSize().x ) && Mouse.y >= PlaylistIconSprite.getPosition().y && Mouse.y < ( PlaylistIconSprite.getPosition().y + PlaylistIconSprite.getTexture()->getSize().y ) ) {

			SetActiveTab( Tab::Playlist ); }
	
		if ( Mouse.x >= TracksIconSprite.getPosition().x && Mouse.x < ( TracksIconSprite.getPosition().x + TracksIconSprite.getTexture()->getSize().x ) && Mouse.y >= TracksIconSprite.getPosition().y && Mouse.y < ( TracksIconSprite.getPosition().y + TracksIconSprite.getTexture()->getSize().y ) ) {

			SetActiveTab( Tab::Tracks ); }

		if ( Mouse.x >= SettingsIconSprite.getPosition().x && Mouse.x < ( SettingsIconSprite.getPosition().x + SettingsIconSprite.getTexture()->getSize().x ) && Mouse.y >= SettingsIconSprite.getPosition().y && Mouse.y < ( SettingsIconSprite.getPosition().y + SettingsIconSprite.getTexture()->getSize().y ) ) {

			SetActiveTab( Tab::Settings ); }

		if ( Mouse.x >= WebIconSprite.getPosition().x && Mouse.x < ( WebIconSprite.getPosition().x + WebIconSprite.getTexture()->getSize().x ) && Mouse.y >= WebIconSprite.getPosition().y && Mouse.y < ( WebIconSprite.getPosition().y + WebIconSprite.getTexture()->getSize().y ) ) {

			SetActiveTab( Tab::Web ); }

		if ( GetActiveTab() == Tab::Playlist ) {

			if ( CoverIconSelected != 255 ) {

				if ( CoverIconSelected <= 10 ) {

					if ( SelectedTrack ) {

						SelectedTrack->Rate = CoverIconSelected;
						
						TracksPointer->Create( *SelectedTrack ); }

					else if ( SelectedPlaylistElementTrack ) {

						SelectedPlaylistElementTrack->Rate = CoverIconSelected;

						TracksPointer->Create( *SelectedPlaylistElementTrack ); } }

				else if ( CoverIconSelected == 11 ) {

					if ( SelectedTrack ) {

						SelectedTrack->IsPlaylist = !SelectedTrack->IsPlaylist;
						
						TracksPointer->Create( *SelectedTrack ); }

					else if ( SelectedPlaylistElementTrack ) {

						SelectedPlaylistElementTrack->IsPlaylist = !SelectedPlaylistElementTrack->IsPlaylist;

						TracksPointer->Create( *SelectedPlaylistElementTrack ); } } }

			if ( PlaylistFieldHighlighted < 6 ) {

				PlaylistTimeError = false;
				PlaylistDateError = false;

				PlaylistFieldSelected = PlaylistFieldHighlighted; }

			else {

				PlaylistFieldSelected = 255; }

			if ( PlaylistFieldHighlighted == 7 ) {

				if ( !PlayerPointer->IsSingleTrackPlaying() ) {

					if ( SelectedTrack != NULL ) {
						
						PlayerPointer->PlaySingleTrack( SelectedTrack->Title, SelectedTrack->Artist, SelectedTrack->Album ); }

					else if ( SelectedPlaylistElement != NULL ) {

						PlayerPointer->PlaySingleTrack( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album ); } }

				else {

					PlayerPointer->StopSingleTrack(); } }

			else if ( PlaylistFieldHighlighted == 8 ) {

				Playlist::Element PlaylistElement;

				PlaylistElement.Title = SelectedTrack->Title;
				PlaylistElement.Artist = SelectedTrack->Artist;
				PlaylistElement.Album = SelectedTrack->Album;
				
				if ( !ConvertTime( PlaylistFieldText[0], PlaylistElement.Begin, PlaylistElement.Lenght ) ) {

					PlaylistTimeError = true; }

				else if ( !ConvertDate( PlaylistFieldText[1], PlaylistElement.Input ) ) {
		
					PlaylistDateError = true; }
	
				else {

					size_t Index;

					if ( !PlaylistPointer->CreateElement( PlaylistElement, Index ) ) {

						PlaylistDateError = true; }
		
					SelectedTrack = NULL;
					SelectedPlaylistElement = (*PlaylistPointer)[ Index ];
					SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album );

					PlaylistFieldSelected = 255;
					PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
					PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
					NavigationError = false;

					TimelinePointer->SetCenter( SelectedPlaylistElement->Input );
					TimelineScope = TimelinePointer->GetScope(); }
				
				PlayerPointer->StopSingleTrack(); }

			else if ( PlaylistFieldHighlighted == 9 ) {

				PlaylistPointer->DeleteElement( SelectedPlaylistElement );

				SelectedPlaylistElement = NULL;
				SelectedPlaylistElementTrack = NULL;

				PlaylistFieldSelected = 255;
				PlaylistFieldText[0] = "";
				PlaylistFieldText[1] = "";
				PlaylistTimeError = false;
				PlaylistDateError = false;
				
				PlayerPointer->StopSingleTrack(); }

			if ( NavigationIconSelected == 0 ) {

				if ( SelectedPlaylistElement ) {

					for ( size_t i = 0; i < PlaylistPointer->GetSize(); i++ ) {

						if ( (*PlaylistPointer)[i] == SelectedPlaylistElement ) {

							if ( i > 0 ) {

								SelectedPlaylistElement = (*PlaylistPointer)[ i - 1 ];
								SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album ); }

							SelectedTrack = NULL;

							PlaylistFieldSelected = 255;
							PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
							PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
							PlaylistTimeError = false;
							PlaylistDateError = false;
							NavigationError = false;

							TimelinePointer->SetCenter( SelectedPlaylistElement->Input );
							PlayerPointer->StopSingleTrack();

							TimelineScope = TimelinePointer->GetScope();

							break; } } }

				else {

					if ( PlaylistPointer->GetSize() > 0 ) {

						SelectedPlaylistElement = (*PlaylistPointer)[ PlaylistPointer->GetSize() - 1 ];
						SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album );

						SelectedTrack = NULL;

						PlaylistFieldSelected = 255;
						PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
						PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
						PlaylistTimeError = false;
						PlaylistDateError = false;
						NavigationError = false;

						TimelinePointer->SetCenter( SelectedPlaylistElement->Input );
						PlayerPointer->StopSingleTrack();
						
						TimelineScope = TimelinePointer->GetScope(); } } }

			else if ( NavigationIconSelected == 1 ) {

				if ( !TimelinePointer->SetScope( TimelineScope ) ) {

					NavigationError = true; } }

			else if ( NavigationIconSelected == 2 ) {

				if ( SelectedPlaylistElement ) {

					for ( size_t i = 0; i < PlaylistPointer->GetSize(); i++ ) {

						if ( (*PlaylistPointer)[i] == SelectedPlaylistElement ) {

							if ( i < ( PlaylistPointer->GetSize() - 1 ) ) {

								SelectedPlaylistElement = (*PlaylistPointer)[ i + 1 ];
								SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album ); }

							SelectedTrack = NULL;

							PlaylistFieldSelected = 255;
							PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
							PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
							PlaylistTimeError = false;
							PlaylistDateError = false;
							NavigationError = false;

							TimelinePointer->SetCenter( SelectedPlaylistElement->Input );
							PlayerPointer->StopSingleTrack();

							TimelineScope = TimelinePointer->GetScope();

							break; } } }

				else {

					if ( PlaylistPointer->GetSize() > 0 ) {

						SelectedPlaylistElement = (*PlaylistPointer)[ PlaylistPointer->GetSize() - 1 ];
						SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album );

						SelectedTrack = NULL;

						PlaylistFieldSelected = 255;
						PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
						PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
						PlaylistTimeError = false;
						PlaylistDateError = false;
						NavigationError = false;

						TimelinePointer->SetCenter( SelectedPlaylistElement->Input );
						PlayerPointer->StopSingleTrack();

						TimelineScope = TimelinePointer->GetScope(); } } }

			else if ( NavigationIconSelected == 3 ) {

				if ( TimelinePointer->GetTracking() ) {

					if ( !TimelinePointer->SetScope( TimelineScope ) ) {

						NavigationError = true; } }
				
				else {

					TimelinePointer->SetCenter( SettingsPointer->GetTime() );

					NavigationError = false;
					TimelineScope = TimelinePointer->GetScope(); }

				TimelinePointer->SetTracking( !TimelinePointer->GetTracking() ); }

			if ( TimelinePointer->GetSelectedPlaylistElement() ) {

				SelectedTrack = NULL;
				SelectedPlaylistElement = TimelinePointer->GetSelectedPlaylistElement();
				SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album );

				PlaylistFieldSelected = 255;
				PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
				PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
				PlaylistTimeError = false;
				PlaylistDateError = false;
				
				PlayerPointer->StopSingleTrack(); } }

		else if ( GetActiveTab() == Tab::Tracks && !EditMode ) {

			if ( HighlightedTrack ) {

				SelectedTrack = HighlightedTrack;
				SelectedPlaylistElement = NULL;
				SelectedPlaylistElementTrack = NULL;

				PlaylistFieldSelected = 255;
				PlaylistTimeError = false;
				PlaylistDateError = false;
				
				if ( ClockStyle( SelectedTrack->Lenght ).size() == 5 ) {

					PlaylistFieldText[0] = "00:00 - " + ClockStyle( SelectedTrack->Lenght ); }

				else {

					PlaylistFieldText[0] = "00:00:00 - " + ClockStyle( SelectedTrack->Lenght ); }
				
				if ( PlaylistPointer->GetSize() > 0 ) {

					if ( ( GetTime() - (*PlaylistPointer)[ PlaylistPointer->GetSize() - 1 ]->Input ) < ( 3600 * 3 ) ) {

						PlaylistFieldText[1] = DateStyle( (*PlaylistPointer)[ PlaylistPointer->GetSize() - 1 ]->Input + (*PlaylistPointer)[ PlaylistPointer->GetSize() - 1 ]->Lenght ); }

					else {

						PlaylistFieldText[1] = DateStyle( GetTime() ); } }

				else {

					PlaylistFieldText[1] = DateStyle( GetTime() ); }
				
				PlayerPointer->StopSingleTrack(); }

			else if ( EditModeEntryHighlighted ) {

				EditModeTrackCopy = EditModeTrackDefault;

				for ( size_t i = 0; i < 7; i++ ) {

					EditModeFieldText[i] = ""; }

				EditMode = true;
				EditModeStatus = L"Podaj dane nowej �cie�ki.";
				EditModeFieldSelected = 255;
				EditModeFieldHighlighted = 255; } }

		else if ( GetActiveTab() == Tab::Tracks && EditMode ) {

			if ( EditModeFieldHighlighted < 7 ) {

				EditModeFieldSelected = EditModeFieldHighlighted; }

			else {

				EditModeFieldSelected = 255; }
			
			if ( EditModeFieldHighlighted == 8 ) {

				SelectedTrack = NULL;
				SelectedPlaylistElement = NULL;
				SelectedPlaylistElementTrack = NULL;

				PlaylistFieldSelected = 255;
				PlaylistFieldText[0] = "";
				PlaylistFieldText[1] = "";
				PlaylistTimeError = false;
				PlaylistDateError = false;

				PlayerPointer->StopSingleTrack();

				CreateTrackThread.launch(); }

			if ( EditModeFieldHighlighted == 9 ) {

				EditMode = false; } }
		
		else if ( GetActiveTab() == Tab::Settings ) {

			if ( SettingsFieldHighlighted < 9 ) {

				SettingsFieldSelected = SettingsFieldHighlighted; }

			else {

				SettingsFieldSelected = 255; }

			if ( SettingsFieldHighlighted == 10 ) {

				if ( PlayerPointer->IsEnabled() ) {

					if ( PlayerPointer->IsMuted() ) {

						PlayerPointer->Unmute(); }

					else {

						PlayerPointer->Mute(); } }

				else {

					PlayerPointer->Enable();
					PlayerPointer->Unmute(); } }

			if ( SettingsFieldHighlighted == 11 ) {

				SelectedPlaylistElement = NULL;
				SelectedPlaylistElementTrack = NULL;

				PlaylistFieldSelected = 255;
				PlaylistFieldText[0] = "";
				PlaylistFieldText[1] = "";
				PlaylistTimeError = false;
				PlaylistDateError = false;

				PlaylistPointer->Clear(); }

			if ( SettingsFieldHighlighted == 12 ) {

				SettingsFieldText[0] = "+ 0";
				SettingsFieldText[1] = "100";
				SettingsFieldText[2] = "03";
				SettingsFieldText[3] = "00";
				SettingsFieldText[4] = "00";
				SettingsFieldText[5] = "Data/";
				SettingsFieldText[6] = "Tracks/";
				SettingsFieldText[7] = "Covers/";
				SettingsFieldText[8] = "Graphics/";	}

			if ( SettingsFieldHighlighted == 13 ) {
				
				SelectedTrack = NULL;
				SelectedPlaylistElement = NULL;
				SelectedPlaylistElementTrack = NULL;

				PlaylistFieldSelected = 255;
				PlaylistFieldText[0] = "";
				PlaylistFieldText[1] = "";
				PlaylistTimeError = false;
				PlaylistDateError = false;

				if ( SettingsFieldText[0].getSize() > 0 ) {

					if ( SettingsFieldText[0].substring( 0, 2 ) == "+ " ) {

						UINT64 NumericValue;
						std::string NumericPart = SettingsFieldText[0].substring( 2 );					

						if ( !Convert( NumericPart, NumericValue ) ) {

							NumericValue = 0; }

						SettingsPointer->SetNumericParameter( Settings::TimeCorrection, NumericValue ); }

					else {

						UINT64 NumericValue;
						std::string NumericPart = SettingsFieldText[0].substring( 2 );					

						if ( !Convert( NumericPart, NumericValue ) ) {

							NumericValue = 0; }

						SettingsPointer->SetNumericParameter( Settings::TimeCorrection, (UINT64) ( (-1) * (INT64) NumericValue ) ); } }

				else {

					SettingsPointer->SetNumericParameter( Settings::TimeCorrection, 0 ); }

				if ( SettingsFieldText[1].getSize() > 0 ) {

					UINT64 NumericValue;

					if ( !Convert( SettingsFieldText[1], NumericValue ) ) {

						NumericValue = 100; }

					SettingsPointer->SetNumericParameter( Settings::PlayerVolume, NumericValue ); }

				else {

					SettingsPointer->SetNumericParameter( Settings::PlayerVolume, 100 ); }

				if ( SettingsFieldText[2].getSize() > 0 ) {

					UINT64 NumericValue;

					if ( !Convert( SettingsFieldText[2], NumericValue ) ) {

						NumericValue = 3; }

					SettingsPointer->SetNumericParameter( Settings::AlgorithmActivationHour, NumericValue ); }

				else {

					SettingsPointer->SetNumericParameter( Settings::AlgorithmActivationHour, 3 ); }

				if ( SettingsFieldText[3].getSize() > 0 ) {

					UINT64 NumericValue;

					if ( !Convert( SettingsFieldText[3], NumericValue ) ) {

						NumericValue = 0; }

					SettingsPointer->SetNumericParameter( Settings::AlgorithmActivationMinute, NumericValue ); }

				else {

					SettingsPointer->SetNumericParameter( Settings::AlgorithmActivationMinute, 0 ); }

				if ( SettingsFieldText[4].getSize() > 0 ) {

					UINT64 NumericValue;

					if ( !Convert( SettingsFieldText[4], NumericValue ) ) {

						NumericValue = 0; }

					SettingsPointer->SetNumericParameter( Settings::AlgorithmActivationSecond, NumericValue ); }

				else {

					SettingsPointer->SetNumericParameter( Settings::AlgorithmActivationSecond, 0 ); }

				if ( SettingsFieldText[5].getSize() > 0 ) {

					SettingsPointer->SetTextParameter( Settings::DataPath, SettingsFieldText[5] ); }

				else {

					SettingsPointer->SetTextParameter( Settings::DataPath, "Data/" ); }

				if ( SettingsFieldText[6].getSize() > 0 ) {

					SettingsPointer->SetTextParameter( Settings::TracksPath, SettingsFieldText[6] ); }

				else {

					SettingsPointer->SetTextParameter( Settings::TracksPath, "Tracks/" ); }

				if ( SettingsFieldText[7].getSize() > 0 ) {

					SettingsPointer->SetTextParameter( Settings::CoversPath, SettingsFieldText[7] ); }

				else {

					SettingsPointer->SetTextParameter( Settings::CoversPath, "Covers/" ); }

				if ( SettingsFieldText[8].getSize() > 0 ) {

					SettingsPointer->SetTextParameter( Settings::GraphicsPath, SettingsFieldText[8] );}

				else {

					SettingsPointer->SetTextParameter( Settings::GraphicsPath, "Graphics/" ); }
	
				std::string TimeCorrectionText;
				std::string PlayerVolumeText;
				std::string AlgorithmActivationHourText;
				std::string AlgorithmActivationMinuteText;
				std::string AlgorithmActivationSecondText;

				Convert( abs( (INT64) SettingsPointer->GetNumericParameter( Settings::TimeCorrection ) ), TimeCorrectionText );
				Convert( SettingsPointer->GetNumericParameter( Settings::PlayerVolume ), PlayerVolumeText );
				Convert( SettingsPointer->GetNumericParameter( Settings::AlgorithmActivationHour ), AlgorithmActivationHourText );
				Convert( SettingsPointer->GetNumericParameter( Settings::AlgorithmActivationMinute ), AlgorithmActivationMinuteText );
				Convert( SettingsPointer->GetNumericParameter( Settings::AlgorithmActivationSecond ), AlgorithmActivationSecondText );
				
				SettingsFieldText[0] = ( (INT64) SettingsPointer->GetNumericParameter( Settings::TimeCorrection ) >= 0 ? "+ " : "- " ) + TimeCorrectionText;
				SettingsFieldText[1] = PlayerVolumeText;
				SettingsFieldText[2] = ( "0" + AlgorithmActivationHourText ).substr( AlgorithmActivationHourText.size() - 1 );
				SettingsFieldText[3] = ( "0" + AlgorithmActivationMinuteText ).substr( AlgorithmActivationMinuteText.size() - 1 );
				SettingsFieldText[4] = ( "0" + AlgorithmActivationSecondText ).substr( AlgorithmActivationSecondText.size() - 1 );
				SettingsFieldText[5] = SettingsPointer->GetTextParameter( Settings::DataPath );
				SettingsFieldText[6] = SettingsPointer->GetTextParameter( Settings::TracksPath );
				SettingsFieldText[7] = SettingsPointer->GetTextParameter( Settings::CoversPath );
				SettingsFieldText[8] = SettingsPointer->GetTextParameter( Settings::GraphicsPath );

				PlayerPointer->StopSingleTrack();

				UpdateSettingsThread.launch(); } }

		else if ( GetActiveTab() == Tab::Web ) {

			// ...

			} }

	if ( Event.type == sf::Event::MouseButtonReleased && Event.mouseButton.button == sf::Mouse::Right ) {

		if ( GetActiveTab() == Tab::Tracks && !EditMode ) {

			if ( HighlightedTrack ) {

				EditModeTrackCopy = *HighlightedTrack;

				std::string EditModeTrackCopyYear;
				Convert( HighlightedTrack->Year, EditModeTrackCopyYear );

				EditModeFieldText[0] = EditModeTrackCopy.Title;
				EditModeFieldText[1] = EditModeTrackCopy.Artist;
				EditModeFieldText[2] = EditModeTrackCopy.Album;
				EditModeFieldText[3] = EditModeTrackCopy.Genre;
				EditModeFieldText[4] = EditModeTrackCopyYear;
				EditModeFieldText[5] = SettingsPointer->GetTextParameter( Settings::TracksPath ) + EditModeTrackCopy.TrackPath;
				EditModeFieldText[6] = SettingsPointer->GetTextParameter( Settings::CoversPath ) + EditModeTrackCopy.CoverPath;
				
				EditMode = true;
				EditModeStatus = L"Zmie� dane istniej�cej �cie�ki.";
				EditModeFieldSelected = 255;
				EditModeFieldHighlighted = 255; } }

		else if ( GetActiveTab() == Tab::Tracks && EditMode ) {

			if ( EditModeFieldHighlighted < 7 ) {

				EditModeFieldSelected = EditModeFieldHighlighted; }
			
			if ( EditModeFieldHighlighted == 8 ) {

				SelectedTrack = NULL;
				SelectedPlaylistElement = NULL;
				SelectedPlaylistElementTrack = NULL;

				PlaylistFieldSelected = 255;
				PlaylistFieldText[0] = "";
				PlaylistFieldText[1] = "";
				PlaylistTimeError = false;
				PlaylistDateError = false;

				PlayerPointer->StopSingleTrack();

				CreateTrackThread.launch(); }

			if ( EditModeFieldHighlighted == 9 ) {

				EditMode = false; } }

		else if ( GetActiveTab() == Tab::Web ) {

			// ...

			} }

	else if ( Event.type == sf::Event::MouseWheelMoved && Event.mouseWheel.delta > 0 ) {

		if ( GetActiveTab() == Tab::Tracks && !EditMode ) {

			TracksTabScroll -= 100.00f; } }

	else if ( Event.type == sf::Event::MouseWheelMoved && Event.mouseWheel.delta < 0 ) {

		if ( GetActiveTab() == Tab::Tracks && !EditMode ) {

			TracksTabScroll += 100.00f; } }

	else if ( Event.type == sf::Event::KeyPressed ) {

		if ( Event.key.code == sf::Keyboard::F1 ) {

			SetActiveTab( Tab::Playlist ); }

		else if ( Event.key.code == sf::Keyboard::F2 ) {

			SetActiveTab( Tab::Tracks ); }

		else if ( Event.key.code == sf::Keyboard::F3 ) {

			SetActiveTab( Tab::Settings ); }

		else if ( Event.key.code == sf::Keyboard::F4 ) {

			SetActiveTab( Tab::Web ); }

		else if ( Event.key.code == sf::Keyboard::F12 ) {

			Window.close(); }

		else if ( Event.key.code == sf::Keyboard::Tab ) {

			SetActiveTab( Tab( ( (UINT8) GetActiveTab() + 1 ) % 4 ) ); }

		else if ( GetActiveTab() == Tab::Playlist ) {

			if ( Event.key.code == sf::Keyboard::Insert ) {

				if ( SelectedTrack ) {

					Playlist::Element PlaylistElement;

					PlaylistElement.Title = SelectedTrack->Title;
					PlaylistElement.Artist = SelectedTrack->Artist;
					PlaylistElement.Album = SelectedTrack->Album;
				
					if ( !ConvertTime( PlaylistFieldText[0], PlaylistElement.Begin, PlaylistElement.Lenght ) ) {

						PlaylistTimeError = true; }

					else if ( !ConvertDate( PlaylistFieldText[1], PlaylistElement.Input ) ) {
		
						PlaylistDateError = true; }
	
					else {

						size_t Index;

						if ( !PlaylistPointer->CreateElement( PlaylistElement, Index ) ) {

							PlaylistDateError = true; }
		
						SelectedTrack = NULL;
						SelectedPlaylistElement = (*PlaylistPointer)[ Index ];
						SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album );

						PlaylistFieldSelected = 255;
						PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
						PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
						NavigationError = false;

						TimelinePointer->SetCenter( SelectedPlaylistElement->Input );
						TimelineScope = TimelinePointer->GetScope(); }
				
					PlayerPointer->StopSingleTrack(); } }

			else if ( Event.key.code == sf::Keyboard::Delete ) {

				if ( SelectedPlaylistElement ) {

					PlaylistPointer->DeleteElement( SelectedPlaylistElement );

					SelectedPlaylistElement = NULL;
					SelectedPlaylistElementTrack = NULL;

					PlaylistFieldSelected = 255;
					PlaylistFieldText[0] = "";
					PlaylistFieldText[1] = "";
					PlaylistTimeError = false;
					PlaylistDateError = false;
				
					PlayerPointer->StopSingleTrack(); } }

			else if ( Event.key.code == sf::Keyboard::PageDown ) {

				if ( SelectedPlaylistElement ) {

					for ( size_t i = 0; i < PlaylistPointer->GetSize(); i++ ) {

						if ( (*PlaylistPointer)[i] == SelectedPlaylistElement ) {

							if ( i > 0 ) {

								SelectedPlaylistElement = (*PlaylistPointer)[ i - 1 ];
								SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album ); }

							SelectedTrack = NULL;

							PlaylistFieldSelected = 255;
							PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
							PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
							PlaylistTimeError = false;
							PlaylistDateError = false;
							NavigationError = false;

							TimelinePointer->SetCenter( SelectedPlaylistElement->Input );
							PlayerPointer->StopSingleTrack();

							TimelineScope = TimelinePointer->GetScope();

							break; } } }

				else {

					if ( PlaylistPointer->GetSize() > 0 ) {

						SelectedPlaylistElement = (*PlaylistPointer)[ PlaylistPointer->GetSize() - 1 ];
						SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album );

						SelectedTrack = NULL;

						PlaylistFieldSelected = 255;
						PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
						PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
						PlaylistTimeError = false;
						PlaylistDateError = false;
						NavigationError = false;

						TimelinePointer->SetCenter( SelectedPlaylistElement->Input );
						PlayerPointer->StopSingleTrack();
						
						TimelineScope = TimelinePointer->GetScope(); } } }

			else if ( Event.key.code == sf::Keyboard::PageUp ) {

				if ( SelectedPlaylistElement ) {

					for ( size_t i = 0; i < PlaylistPointer->GetSize(); i++ ) {

						if ( (*PlaylistPointer)[i] == SelectedPlaylistElement ) {

							if ( i < ( PlaylistPointer->GetSize() - 1 ) ) {

								SelectedPlaylistElement = (*PlaylistPointer)[ i + 1 ];
								SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album ); }

							SelectedTrack = NULL;

							PlaylistFieldSelected = 255;
							PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
							PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
							PlaylistTimeError = false;
							PlaylistDateError = false;
							NavigationError = false;

							TimelinePointer->SetCenter( SelectedPlaylistElement->Input );
							PlayerPointer->StopSingleTrack();

							TimelineScope = TimelinePointer->GetScope();

							break; } } }

				else {

					if ( PlaylistPointer->GetSize() > 0 ) {

						SelectedPlaylistElement = (*PlaylistPointer)[ PlaylistPointer->GetSize() - 1 ];
						SelectedPlaylistElementTrack = TracksPointer->Search( SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album );

						SelectedTrack = NULL;

						PlaylistFieldSelected = 255;
						PlaylistFieldText[0] = ClockStyle( SelectedPlaylistElement->Begin ) + " - " + ClockStyle( SelectedPlaylistElement->Begin + SelectedPlaylistElement->Lenght );
						PlaylistFieldText[1] = DateStyle( SelectedPlaylistElement->Input );
						PlaylistTimeError = false;
						PlaylistDateError = false;
						NavigationError = false;

						TimelinePointer->SetCenter( SelectedPlaylistElement->Input );
						PlayerPointer->StopSingleTrack();

						TimelineScope = TimelinePointer->GetScope(); } } }

			else if ( Event.key.code == sf::Keyboard::Home ) {

				if ( TimelinePointer->GetTracking() ) {

					if ( !TimelinePointer->SetScope( TimelineScope ) ) {

						NavigationError = true; } }
				
				else {

					TimelinePointer->SetCenter( SettingsPointer->GetTime() );

					NavigationError = false;
					TimelineScope = TimelinePointer->GetScope(); }

				TimelinePointer->SetTracking( !TimelinePointer->GetTracking() ); }

			else if ( Event.key.code == sf::Keyboard::Return ) {

				if ( PlaylistFieldSelected == 4 || PlaylistFieldSelected == 5 ) {

					PlaylistFieldSelected++; }
				
				else {

					if ( !TimelinePointer->SetScope( TimelineScope ) ) {

						NavigationError = true; } } }

			else if ( Event.key.code == sf::Keyboard::BackSpace ) {

				if ( PlaylistFieldSelected == 4 || PlaylistFieldSelected == 5 ) {

					PlaylistTimeError = false;
					PlaylistDateError = false;
					
					PlaylistFieldText[PlaylistFieldSelected-4] = PlaylistFieldText[PlaylistFieldSelected-4].substring( 0, PlaylistFieldText[PlaylistFieldSelected-4].getSize() - 1 ); }

				else {

					NavigationError = false;

					TimelineScope = TimelineScope.substring( 0, TimelineScope.getSize() - 1 ); } } }

		else if ( GetActiveTab() == Tab::Tracks && !EditMode ) {

			if ( Event.key.code == sf::Keyboard::BackSpace ) {

				SearchSprite.setString( SearchSprite.getString().substring( 0, SearchSprite.getString().getSize() - 1 ) );
				
				FilteredTracks = TracksPointer->Search( SearchSprite.getString() ); }

			else if ( Event.key.code == sf::Keyboard::PageUp ) {

				TracksTabScroll -= 100.00f; }

			else if ( Event.key.code == sf::Keyboard::PageDown ) {

				TracksTabScroll += 100.00f; } }

		else if ( GetActiveTab() == Tab::Tracks && EditMode ) {

			if ( Event.key.code == sf::Keyboard::Escape ) {

				EditMode = false; }

			else if ( Event.key.code == sf::Keyboard::Return ) {

				if ( EditModeFieldSelected < 7 ) {

					EditModeFieldSelected++; } }

			else if ( Event.key.code == sf::Keyboard::BackSpace ) {

				if ( EditModeFieldSelected < 7 ) {

					EditModeFieldText[EditModeFieldSelected] = EditModeFieldText[EditModeFieldSelected].substring( 0, EditModeFieldText[EditModeFieldSelected].getSize() - 1 ); } } }

		else if ( GetActiveTab() == Tab::Settings ) {

			if ( Event.key.code == sf::Keyboard::Return ) {

				if ( SettingsFieldSelected < 9 ) {

					SettingsFieldSelected++; } }

			else if ( Event.key.code == sf::Keyboard::BackSpace ) {

				if ( SettingsFieldSelected < 9 ) {

					if ( SettingsFieldSelected != 0 ) {

						SettingsFieldText[SettingsFieldSelected] = SettingsFieldText[SettingsFieldSelected].substring( 0, SettingsFieldText[SettingsFieldSelected].getSize() - 1 ); }

					else {

						if ( SettingsFieldText[0].getSize() == 2 ) {

							SettingsFieldText[0] = ""; }

						else {

							SettingsFieldText[0] = SettingsFieldText[0].substring( 0, SettingsFieldText[0].getSize() - 1 ); } } } } }

		else if ( GetActiveTab() == Tab::Web ) {

			if ( Event.key.code == sf::Keyboard::BackSpace ) {

				// ...

				} } }

	else if ( Event.type == sf::Event::TextEntered ) {
		
		if ( GetActiveTab() == Tab::Playlist ) {

			if ( SelectedTrack != NULL ) {

				if ( PlaylistFieldSelected == 4 ) {

					if ( Event.text.unicode == 32 || Event.text.unicode == 45 || ( Event.text.unicode > 47 && Event.text.unicode < 59 ) ) {

						PlaylistTimeError = false;

						if ( PlaylistFieldText[0].getSize() < 256 ) {

							PlaylistFieldText[0] = PlaylistFieldText[0] + (char) Event.text.unicode; } } }

				else if ( PlaylistFieldSelected == 5 ) {

					if ( Event.text.unicode == 32 || Event.text.unicode == 46 || ( Event.text.unicode > 47 && Event.text.unicode < 59 ) ) {

						PlaylistDateError = false;
						
						if ( PlaylistFieldText[1].getSize() < 256 ) {

							PlaylistFieldText[1] = PlaylistFieldText[1] + (char) Event.text.unicode; } } }
					
				else {

					if ( Event.text.unicode == 32 || Event.text.unicode == 45 || Event.text.unicode == 46 || ( Event.text.unicode > 47 && Event.text.unicode < 59 ) ) {

						NavigationError = false;

						if ( TimelineScope.getSize() < 256 ) {

							TimelineScope = TimelineScope + (char) Event.text.unicode; } } } }
			
			else {

				if ( Event.text.unicode == 32 || Event.text.unicode == 45 || Event.text.unicode == 46 || ( Event.text.unicode > 47 && Event.text.unicode < 59 ) ) {

					NavigationError = false;

					if ( TimelineScope.getSize() < 256 ) {

						TimelineScope = TimelineScope + (char) Event.text.unicode; } } } }

		else if ( GetActiveTab() == Tab::Tracks && !EditMode ) {

			if ( Event.text.unicode > 31 && Event.text.unicode < 127 ) {

				if ( SearchSprite.getString().getSize() < 256 ) {

					SearchSprite.setString( SearchSprite.getString() + Event.text.unicode );
					
					FilteredTracks = TracksPointer->Search( SearchSprite.getString() ); } } }

		else if ( GetActiveTab() == Tab::Tracks && EditMode ) {

			if ( Event.text.unicode > 31 && Event.text.unicode < 127 ) {

				if ( EditModeFieldSelected < 7 ) {

					if ( EditModeFieldText[EditModeFieldSelected].getSize() < 256 ) {

						EditModeFieldText[EditModeFieldSelected] = EditModeFieldText[EditModeFieldSelected] + (char) Event.text.unicode; } } } }

		else if ( GetActiveTab() == Tab::Settings ) {

			if ( SettingsFieldSelected < 9 ) {

				if ( SettingsFieldSelected < 5 ) {

					if ( SettingsFieldSelected != 0 ) {

						if ( SettingsFieldSelected == 1 ) {

							if ( Event.text.unicode > 47 && Event.text.unicode < 58 ) {

								if ( SettingsFieldText[1].getSize() < 3 ) {

									SettingsFieldText[1] = SettingsFieldText[1] + (char) Event.text.unicode; } } }

						else {

							if ( Event.text.unicode > 47 && Event.text.unicode < 58 ) {

								if ( SettingsFieldText[SettingsFieldSelected].getSize() < 2 ) {

									SettingsFieldText[SettingsFieldSelected] = SettingsFieldText[SettingsFieldSelected] + (char) Event.text.unicode; } } } }

					else {

						if ( SettingsFieldText[0].getSize() >= 2 ) {

							if ( SettingsFieldText[0].getSize() < 21 ) {

								if ( Event.text.unicode > 47 && Event.text.unicode < 58 ) {

									SettingsFieldText[0] = SettingsFieldText[0] + (char) Event.text.unicode; } } }

						else {

							if ( Event.text.unicode == 43 ) {

								SettingsFieldText[0] = "+ "; }

							else if ( Event.text.unicode == 45 ) {

								SettingsFieldText[0] = "- "; }

							else if ( Event.text.unicode > 47 && Event.text.unicode < 58 ) {

								SettingsFieldText[0] = "+ ";
								SettingsFieldText[0] = SettingsFieldText[0] + (char) Event.text.unicode; } } } }

				else {

					if ( Event.text.unicode > 31 && Event.text.unicode < 127 ) {
						
						if ( SettingsFieldText[SettingsFieldSelected].getSize() < 256 ) {

							SettingsFieldText[SettingsFieldSelected] = SettingsFieldText[SettingsFieldSelected] + (char) Event.text.unicode; } } } } }

		else if ( GetActiveTab() == Tab::Web ) {

			if ( Event.text.unicode > 31 && Event.text.unicode < 127 ) {
				
				// ...

				} } } }

void Interface::Render ( sf::RenderWindow &Window ) {
	
	if ( false ) {

		StatusOnline = true; }

	else {

		StatusOnline = false; }

	if ( PlayerPointer->IsEnabled() && !PlayerPointer->IsMuted() ) {

		StatusOnAir = true; }

	else {

		StatusOnAir = false; }

	switch ( GetActiveTab() ) {

		case Tab::Playlist:

			RenderPlaylistTab( Window );

			break;

		case Tab::Tracks:

			if ( !EditMode ) {

				RenderTracksTab( Window ); }

			else {

				RenderTracksTabSpecialMode( Window ); }

			break;

		case Tab::Settings:

			RenderSettingsTab( Window );

			break;

		case Tab::Web:

			RenderWebTab( Window );
			
			break; };

	RenderTabsBar( Window );
	RenderStatusBar( Window ); }

void Interface::Render ( sf::RenderWindow &Window, sf::Vector2f Position, sf::Vector2f Size, sf::Color Color ) {

	sf::Vertex Vertexes [4] = {

		sf::Vertex( sf::Vector2f( Position.x, Position.y ), Color ),
		sf::Vertex( sf::Vector2f( Position.x + Size.x, Position.y ), Color ),
		sf::Vertex( sf::Vector2f( Position.x + Size.x, Position.y + Size.y ), Color ),
		sf::Vertex( sf::Vector2f( Position.x, Position.y + Size.y ), Color )

		};

	Window.draw( Vertexes, 4, sf::Quads ); }

void Interface::RenderPlaylistTab ( sf::RenderWindow &Window ) {

	sf::Vector2f CoverPosition ( StatusBarPosition.x + 15.00f, StatusBarPosition.y + StatusBarSize.y + 15.00f );
	sf::Vector2f CoverSize ( StatusBarSize.x * 0.40f, StatusBarSize.x * 0.40f );

	if ( ( CoverPosition.y + CoverSize.y ) > ( NavigationBarPosition.y - 15.00f ) ) {

		CoverSize.x = CoverSize.y = NavigationBarPosition.y - ( CoverPosition.y + 15.00f ); }

	sf::Vector2f StarsBlockPosition ( CoverPosition.x + CoverSize.x - ( CoverSize.x * 0.40f ) - 10.00f, CoverPosition.y + CoverSize.y - ( CoverSize.x * 0.40f * 0.18f ) - 10.00f );
	sf::Vector2f StarsBlockSize ( CoverSize.x * 0.40f, CoverSize.x * 0.40f * 0.18f );
	sf::Vector2f GearsBlockPosition ( CoverPosition.x + 10.00f, CoverPosition.y + CoverSize.y - ( CoverSize.x * 0.15f * 0.72f ) - 10.00f );
	sf::Vector2f GearsBlockSize ( CoverSize.x * 0.15f, CoverSize.x * 0.15f * 0.72f );
	sf::Vector2f ValueBlockPosition ( CoverPosition.x + CoverSize.x + 15.00f, CoverPosition.y );
	sf::Vector2f ValueBlockSize ( ( StatusBarPosition.x + StatusBarSize.x ) - ( ValueBlockPosition.x + 15.00f ), 30.00f );
	sf::Vector2f PlayBlockPosition ( ( ValueBlockPosition.x + ValueBlockSize.x ) - 330.00f, StatusBarPosition.y + StatusBarSize.y + 285.00f );
	sf::Vector2f PlayBlockSize ( 100.00f, 30.00f );
	sf::Vector2f AddBlockPosition ( ( ValueBlockPosition.x + ValueBlockSize.x ) - 215.00f, StatusBarPosition.y + StatusBarSize.y + 285.00f );
	sf::Vector2f AddBlockSize ( 100.00f, 30.00f );
	sf::Vector2f DeleteBlockPosition ( ( ValueBlockPosition.x + ValueBlockSize.x ) - 100.00f, StatusBarPosition.y + StatusBarSize.y + 285.00f );
	sf::Vector2f DeleteBlockSize ( 100.00f, 30.00f );
	sf::Vector2f TimelinePosition ( StatusBarPosition.x, NavigationBarPosition.y + NavigationBarSize.y );
	sf::Vector2f TimelineSize ( StatusBarSize.x, TabsBarSize.y - TimelinePosition.y );
	sf::Vector2f Mouse ( (REAL32) sf::Mouse::getPosition( Window ).x, (REAL32) sf::Mouse::getPosition( Window ).y );	

	CoverIconSelected = 255;
	PlaylistFieldHighlighted = 255;

	for ( size_t i = 0; i < 6; i++ ) {

		if ( SelectedTrack != NULL ) {

			if ( i < 4 ) {

				Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 50, 150, 250 ) ); }

			else {

				if ( Mouse.x > ValueBlockPosition.x && Mouse.x < ( ValueBlockPosition.x + ValueBlockSize.x ) && Mouse.y > ( ValueBlockPosition.y ) && Mouse.y < ( ValueBlockPosition.y + ValueBlockSize.y ) ) {

					PlaylistFieldHighlighted = i; }

				if ( i == PlaylistFieldSelected ) {

					Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 100, 250, 100 ) ); }

				else if ( i == PlaylistFieldHighlighted ) {

					Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 100, 250, 100 ) ); }

				else {

					if ( !( i == 4 && PlaylistTimeError ) && !( i == 5 && PlaylistDateError ) ) {

						Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 50, 150, 250 ) ); }

					else {
						
						Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 250, 150, 50 ) ); } } } }

		else if ( SelectedPlaylistElement != NULL ) {

			if ( i != 6 && i != 8 ) {

				Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 50, 150, 250 ) ); }

			else {

				if ( Mouse.x > ValueBlockPosition.x && Mouse.x < ( ValueBlockPosition.x + ValueBlockSize.x ) && Mouse.y > ( ValueBlockPosition.y ) && Mouse.y < ( ValueBlockPosition.y + ValueBlockSize.y ) ) {

					PlaylistFieldHighlighted = i; }

				if ( i == PlaylistFieldHighlighted ) {

					Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 100, 250, 100 ) ); }

				else {

					Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 50, 150, 250 ) ); } } }

		else {

			Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 50, 150, 250 ) ); }

		if ( SelectedTrack != NULL ) {

			std::string Year;
			Convert( SelectedTrack->Year, Year );

			sf::Text Value;
			sf::String Values [] = { SelectedTrack->Title, SelectedTrack->Artist, SelectedTrack->Album, SelectedTrack->Genre + " " + Year, PlaylistFieldText[0], PlaylistFieldText[1] };

			Value.setFont( ThinFont );
			Value.setCharacterSize( 18 );
			Value.setPosition( sf::Vector2f( Integral( ValueBlockPosition.x + 10.00f ), Integral( ValueBlockPosition.y + 4.00f ) ) );
			Value.setString( Values[i] );

			if ( i < 4 ) {

				while ( Value.getGlobalBounds().width > ( ValueBlockSize.x - 20.00f ) ) {

					Value.setString( Value.getString().substring( 0, Value.getString().getSize() - 1 ) ); } }

			else {

				while ( Value.getGlobalBounds().width > ( ValueBlockSize.x - 20.00f ) ) {

					Value.setString( Value.getString().substring( 1 ) ); } }

			Window.draw( Value ); }

		else if ( SelectedPlaylistElement != NULL ) {

			if ( SelectedPlaylistElementTrack ) {

				std::string Year;
				Convert( SelectedPlaylistElementTrack->Year, Year );

				sf::Text Value;
				sf::String Values [] = { SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album, SelectedPlaylistElementTrack->Genre + " " + Year, PlaylistFieldText[0], PlaylistFieldText[1] };

				Value.setFont( ThinFont );
				Value.setCharacterSize( 18 );
				Value.setPosition( sf::Vector2f( Integral( ValueBlockPosition.x + 10.00f ), Integral( ValueBlockPosition.y + 4.00f ) ) );
				Value.setString( Values[i] );

				while ( Value.getGlobalBounds().width > ( ValueBlockSize.x - 20.00f ) ) {

					Value.setString( Value.getString().substring( 0, Value.getString().getSize() - 1 ) ); }

				Window.draw( Value ); }

			else {

				sf::Text Value;
				sf::String Values [] = { SelectedPlaylistElement->Title, SelectedPlaylistElement->Artist, SelectedPlaylistElement->Album, "", PlaylistFieldText[0], PlaylistFieldText[1] };

				Value.setFont( ThinFont );
				Value.setCharacterSize( 18 );
				Value.setPosition( sf::Vector2f( Integral( ValueBlockPosition.x + 10.00f ), Integral( ValueBlockPosition.y + 4.00f ) ) );
				Value.setString( Values[i] );

				while ( Value.getGlobalBounds().width > ( ValueBlockSize.x - 20.00f ) ) {

					Value.setString( Value.getString().substring( 0, Value.getString().getSize() - 1 ) ); }

				Window.draw( Value ); } }
		
		ValueBlockPosition.y += 45.00f; }

	if ( Mouse.x >= StarsBlockPosition.x && Mouse.x <= ( StarsBlockPosition.x + StarsBlockSize.x ) && Mouse.y >= ( StarsBlockPosition.y ) && Mouse.y <= ( StarsBlockPosition.y + StarsBlockSize.y ) && ( SelectedPlaylistElement || SelectedTrack ) ) {

		CoverIconSelected = (UINT64) ( 11.00f * ( ( Mouse.x - StarsBlockPosition.x ) / StarsBlockSize.x ) ); }

	if ( Mouse.x >= GearsBlockPosition.x && Mouse.x <= ( GearsBlockPosition.x + GearsBlockSize.x ) && Mouse.y >= ( GearsBlockPosition.y ) && Mouse.y <= ( GearsBlockPosition.y + GearsBlockSize.y ) && ( SelectedPlaylistElement || SelectedTrack ) ) {

		CoverIconSelected = 11; }

	if ( Mouse.x > PlayBlockPosition.x && Mouse.x < ( PlayBlockPosition.x + PlayBlockSize.x ) && Mouse.y > ( PlayBlockPosition.y ) && Mouse.y < ( PlayBlockPosition.y + PlayBlockSize.y ) && ( SelectedPlaylistElement || SelectedTrack ) ) {

		PlaylistFieldHighlighted = 7; }

	if ( Mouse.x > AddBlockPosition.x && Mouse.x < ( AddBlockPosition.x + AddBlockSize.x ) && Mouse.y > ( AddBlockPosition.y ) && Mouse.y < ( AddBlockPosition.y + AddBlockSize.y ) && SelectedTrack ) {

		PlaylistFieldHighlighted = 8; }

	if ( Mouse.x > DeleteBlockPosition.x && Mouse.x < ( DeleteBlockPosition.x + DeleteBlockSize.x ) && Mouse.y > ( DeleteBlockPosition.y ) && Mouse.y < ( DeleteBlockPosition.y + DeleteBlockSize.y ) && SelectedPlaylistElement ) {

		PlaylistFieldHighlighted = 9; }

	if ( PlaylistFieldHighlighted == 7 ) {

		Render( Window, PlayBlockPosition, PlayBlockSize, sf::Color( 50, 200, 50 ) ); }

	else if ( SelectedPlaylistElement || SelectedTrack ) {

		Render( Window, PlayBlockPosition, PlayBlockSize, sf::Color( 0, 100, 200 ) ); }

	else {

		Render( Window, PlayBlockPosition, PlayBlockSize, sf::Color( 50, 150, 250 ) ); }

	if ( PlaylistFieldHighlighted == 8 ) {

		Render( Window, AddBlockPosition, AddBlockSize, sf::Color( 50, 200, 50 ) ); }

	else if ( SelectedTrack ) {

		Render( Window, AddBlockPosition, AddBlockSize, sf::Color( 0, 100, 200 ) ); }

	else {

		Render( Window, AddBlockPosition, AddBlockSize, sf::Color( 50, 150, 250 ) ); }

	if ( PlaylistFieldHighlighted == 9 ) {

		Render( Window, DeleteBlockPosition, DeleteBlockSize, sf::Color( 50, 200, 50 ) ); }

	else if ( SelectedPlaylistElement ) {

		Render( Window, DeleteBlockPosition, DeleteBlockSize, sf::Color( 0, 100, 200 ) ); }

	else {

		Render( Window, DeleteBlockPosition, DeleteBlockSize, sf::Color( 50, 150, 250 ) ); }

	sf::Sprite Cover;
	sf::Sprite StarsDisabled;
	sf::Sprite StarsEnabled;
	sf::Sprite Gears;
	sf::Text PlayBlockText;
	sf::Text AddBlockText;
	sf::Text DeleteBlockText;

	if ( SelectedTrack ) {

		Cover.setTexture( SelectedTrack->Cover );
		Cover.setPosition( CoverPosition );
		Cover.setScale( CoverSize.x / Cover.getTexture()->getSize().x, CoverSize.y / Cover.getTexture()->getSize().y );
		
		StarsDisabled.setTexture( StarsIconTexture );
		StarsDisabled.setColor( sf::Color( 0, 0, 0 ) );
		StarsDisabled.setPosition( StarsBlockPosition );
		StarsDisabled.setScale( StarsBlockSize.x / StarsDisabled.getTexture()->getSize().x, StarsBlockSize.y / StarsDisabled.getTexture()->getSize().y );

		StarsEnabled.setTexture( StarsIconTexture );
		StarsEnabled.setColor( sf::Color( 255, 215, 0 ) );
		StarsEnabled.setTextureRect( sf::IntRect( 0, 0, (int) ( StarsEnabled.getTexture()->getSize().x * ( ( CoverIconSelected <= 10 ? CoverIconSelected : SelectedTrack->Rate ) / 10.00f ) ), StarsEnabled.getTexture()->getSize().y ) );
		StarsEnabled.setPosition( StarsBlockPosition );
		StarsEnabled.setScale( StarsBlockSize.x / StarsEnabled.getTexture()->getSize().x, StarsBlockSize.y / StarsEnabled.getTexture()->getSize().y );
		
		Gears.setTexture( GearsIconTexture );
		Gears.setColor( SelectedTrack->IsPlaylist ? sf::Color( 255, 255, 255 ) : sf::Color( 0, 0, 0 ) );
		Gears.setPosition( GearsBlockPosition );
		Gears.setScale( GearsBlockSize.x / Gears.getTexture()->getSize().x, GearsBlockSize.y / Gears.getTexture()->getSize().y ); }

	else if ( SelectedPlaylistElementTrack ) {

		Cover.setTexture( SelectedPlaylistElementTrack->Cover );
		Cover.setPosition( CoverPosition );
		Cover.setScale( CoverSize.x / Cover.getTexture()->getSize().x, CoverSize.y / Cover.getTexture()->getSize().y );
		
		StarsDisabled.setTexture( StarsIconTexture );
		StarsDisabled.setColor( sf::Color( 0, 0, 0 ) );
		StarsDisabled.setPosition( StarsBlockPosition );
		StarsDisabled.setScale( StarsBlockSize.x / StarsDisabled.getTexture()->getSize().x, StarsBlockSize.y / StarsDisabled.getTexture()->getSize().y );

		StarsEnabled.setTexture( StarsIconTexture );
		StarsEnabled.setColor( sf::Color( 255, 215, 0 ) );
		StarsEnabled.setTextureRect( sf::IntRect( 0, 0, (int) ( StarsEnabled.getTexture()->getSize().x * ( ( CoverIconSelected <= 10 ? CoverIconSelected : SelectedPlaylistElementTrack->Rate ) / 10.00f ) ), StarsEnabled.getTexture()->getSize().y ) );
		StarsEnabled.setPosition( StarsBlockPosition );
		StarsEnabled.setScale( StarsBlockSize.x / StarsEnabled.getTexture()->getSize().x, StarsBlockSize.y / StarsEnabled.getTexture()->getSize().y );
		
		Gears.setTexture( GearsIconTexture );
		Gears.setColor( SelectedPlaylistElementTrack->IsPlaylist ? sf::Color( 255, 255, 255 ) : sf::Color( 0, 0, 0 ) );
		Gears.setPosition( GearsBlockPosition );
		Gears.setScale( GearsBlockSize.x / Gears.getTexture()->getSize().x, GearsBlockSize.y / Gears.getTexture()->getSize().y ); }

	else {

		Cover.setTexture( DefaultCover );
		Cover.setPosition( CoverPosition );
		Cover.setScale( CoverSize.x / Cover.getTexture()->getSize().x, CoverSize.y / Cover.getTexture()->getSize().y ); }

	PlayBlockText.setFont( BoldFont );
	PlayBlockText.setCharacterSize( 16 );
	PlayBlockText.setString( PlayerPointer->IsSingleTrackPlaying() ? L"Zatrzymaj" : L"Odtw�rz" );
	PlayBlockText.setPosition( sf::Vector2f( Integral( PlayBlockPosition.x + ( ( PlayBlockSize.x - PlayBlockText.getGlobalBounds().width ) / 2.00f ) ), Integral( PlayBlockPosition.y + 5.00f ) ) );

	AddBlockText.setFont( BoldFont );
	AddBlockText.setCharacterSize( 16 );
	AddBlockText.setString( L"Dodaj" );
	AddBlockText.setPosition( sf::Vector2f( Integral( AddBlockPosition.x + ( ( AddBlockSize.x - AddBlockText.getGlobalBounds().width ) / 2.00f ) ), Integral( AddBlockPosition.y + 5.00f ) ) );

	DeleteBlockText.setFont( BoldFont );
	DeleteBlockText.setCharacterSize( 16 );
	DeleteBlockText.setString( L"Usu�" );
	DeleteBlockText.setPosition( sf::Vector2f( Integral( DeleteBlockPosition.x + ( ( DeleteBlockSize.x - DeleteBlockText.getGlobalBounds().width ) / 2.00f ) ), Integral( DeleteBlockPosition.y + 5.00f ) ) );

	Render( Window, CoverPosition, CoverSize, sf::Color( 50, 150, 250 ) );
	
	Window.draw( Cover );
	Window.draw( StarsDisabled );
	Window.draw( StarsEnabled );
	Window.draw( Gears );
	Window.draw( PlayBlockText );
	Window.draw( AddBlockText );
	Window.draw( DeleteBlockText );

	if ( !TimelinePointer->GetTracking() ) {

		if ( Mouse.x >= TimelinePosition.x && Mouse.x <= ( TimelinePosition.x + ( TimelineSize.x * 0.20f ) ) && Mouse.y >= TimelinePosition.y && Mouse.y <= ( TimelinePosition.y + TimelineSize.y ) ) {

			TimelinePointer->SetBegin( TimelinePointer->GetBegin() - (UINT64) ( ( ( TimelinePosition.x + ( TimelineSize.x * 0.20f ) ) - Mouse.x ) / ( TimelineSize.x * 0.02f ) ) );
			TimelinePointer->SetEnd( TimelinePointer->GetEnd() - (UINT64) ( ( ( TimelinePosition.x + ( TimelineSize.x * 0.20f ) ) - Mouse.x ) / ( TimelineSize.x * 0.02f ) ) );
			
			NavigationError = false;
			TimelineScope = TimelinePointer->GetScope(); }

		if ( Mouse.x >= ( TimelinePosition.x + TimelineSize.x - ( TimelineSize.x * 0.20f ) ) && Mouse.x <= ( TimelinePosition.x + TimelineSize.x ) && Mouse.y >= TimelinePosition.y && Mouse.y <= ( TimelinePosition.y + TimelineSize.y ) ) {

			TimelinePointer->SetBegin( TimelinePointer->GetBegin() + (UINT64) ( ( Mouse.x - ( TimelinePosition.x + TimelineSize.x - ( TimelineSize.x * 0.20f ) ) ) / ( TimelineSize.x * 0.02f ) ) );
			TimelinePointer->SetEnd( TimelinePointer->GetEnd() + (UINT64) ( ( Mouse.x - ( TimelinePosition.x + TimelineSize.x - ( TimelineSize.x * 0.20f ) ) ) / ( TimelineSize.x * 0.02f ) ) );
			
			NavigationError = false;
			TimelineScope = TimelinePointer->GetScope(); } }
	
	Render( Window, TimelinePosition, TimelineSize, sf::Color( 50, 100, 250 ) );
	TimelinePointer->Render( Window, TimelinePosition, TimelineSize );

	RenderNavigationBar( Window ); }

void Interface::RenderTracksTab ( sf::RenderWindow &Window ) {

	sf::Vector2f BlockPosition ( StatusBarPosition.x, StatusBarPosition.y + StatusBarSize.y );
	sf::Vector2f BlockSize ( 125.00f, 200.00f );
	sf::Vector2f Margin ( fmod( StatusBarSize.x, BlockSize.x ) / (UINT64) ( StatusBarSize.x / BlockSize.x + 1.00f ), fmod( StatusBarSize.x, BlockSize.x ) / (UINT64) ( StatusBarSize.x / BlockSize.x + 1.00f ) );
	sf::Vector2f Mouse ( (REAL32) sf::Mouse::getPosition( Window ).x, (REAL32) sf::Mouse::getPosition( Window ).y );
	
	if ( Margin.x < 10.00f || Margin.y < 10.00f ) {

		Margin = sf::Vector2f( ( fmod( StatusBarSize.x, BlockSize.x ) + BlockSize.x ) / (UINT64) ( StatusBarSize.x / BlockSize.x ), ( fmod( StatusBarSize.x, BlockSize.x ) + BlockSize.x ) / (UINT64) ( StatusBarSize.x / BlockSize.x ) ); }
		
	if ( TracksTabScroll > ( ( FilteredTracks.size() / ( (UINT64) ( StatusBarSize.x / BlockSize.x ) ) + 1 ) * ( BlockSize.y + Margin.y ) - ( SearchBarPosition.y - ( StatusBarPosition.y + StatusBarSize.y ) ) + Margin.y ) ) {

		TracksTabScroll = ( ( FilteredTracks.size() / ( (UINT64) ( StatusBarSize.x / BlockSize.x ) ) + 1 ) * ( BlockSize.y + Margin.y ) - ( SearchBarPosition.y - ( StatusBarPosition.y + StatusBarSize.y ) ) + Margin.y ); }

	if ( TracksTabScroll < 0.00f ) {

		TracksTabScroll = 0.00f; }

	BlockPosition.x = BlockPosition.x + Margin.x;
	BlockPosition.y = BlockPosition.y + Margin.y - TracksTabScroll;

	HighlightedTrack = NULL;
	EditModeEntryHighlighted = false;

	for ( size_t i = 0; i < ( FilteredTracks.size() + 1 ) && BlockPosition.y < ( SearchBarPosition.y ); i++ ) {

		if ( ( BlockPosition.y + BlockSize.y ) > ( StatusBarPosition.y + StatusBarSize.y ) ) {
			
			if ( i > 0 ) {
				
				if ( Mouse.x > BlockPosition.x && Mouse.x < ( BlockPosition.x + BlockSize.x ) && Mouse.y > BlockPosition.y && Mouse.y < ( BlockPosition.y + BlockSize.y ) ) {

					HighlightedTrack = FilteredTracks[i-1]; }	

				if ( FilteredTracks[i-1] == SelectedTrack ) {

					Render( Window, BlockPosition, BlockSize, sf::Color( 50, 200, 50 ) ); }

				else if ( FilteredTracks[i-1] == HighlightedTrack ) {

					Render( Window, BlockPosition, BlockSize, sf::Color( 100, 250, 100 ) ); }

				else {

					Render( Window, BlockPosition, BlockSize, sf::Color( 0, 150, 250 ) ); }

				sf::Sprite Cover;
				sf::Sprite StarsDisabled;
				sf::Sprite StarsEnabled;
				sf::Text Title;
				sf::Text Artist;
				sf::Text Album;
				sf::Text GenreAndYear;
				sf::Text LenghtAndQuality;

				std::string YearText;
				std::string QualityText;

				Convert( FilteredTracks[i-1]->Year, YearText );
				Convert( FilteredTracks[i-1]->Quality / 1000, QualityText );

				Cover.setTexture( FilteredTracks[i-1]->Cover );
				Cover.setPosition( sf::Vector2f( BlockPosition.x + 12.50f, BlockPosition.y + 12.50f ) );
				Cover.setScale( 100.00f / FilteredTracks[i-1]->Cover.getSize().x, 100.00f / FilteredTracks[i-1]->Cover.getSize().y );

				StarsDisabled.setTexture( StarsIconTexture );
				StarsDisabled.setColor( sf::Color( 0, 0, 0 ) );
				StarsDisabled.setPosition( sf::Vector2f( BlockPosition.x + 12.50f + 10.00f, BlockPosition.y + 112.50f - 20.00f ) );
				StarsDisabled.setScale( 80.00f / StarsDisabled.getTexture()->getSize().x, 80.00f / StarsDisabled.getTexture()->getSize().x );

				StarsEnabled.setTexture( StarsIconTexture );
				StarsEnabled.setColor( sf::Color( 255, 215, 0 ) );
				StarsEnabled.setTextureRect( sf::IntRect( 0, 0, (int) ( StarsEnabled.getTexture()->getSize().x * ( FilteredTracks[i-1]->Rate / 10.00f ) ), StarsEnabled.getTexture()->getSize().y ) );
				StarsEnabled.setPosition( sf::Vector2f( BlockPosition.x + 12.50f + 10.00f, BlockPosition.y + 112.50f - 20.00f ) );
				StarsEnabled.setScale( 80.00f / StarsDisabled.getTexture()->getSize().x, 80.00f / StarsDisabled.getTexture()->getSize().x );

				Title.setFont( RegularFont );
				Title.setCharacterSize( 12 );
				Title.setPosition( sf::Vector2f( Integral( BlockPosition.x + 8.00f ), Integral( BlockPosition.y + 100.00f + 19.00f ) ) );
				Title.setString( FilteredTracks[i-1]->Title );

				Artist.setFont( RegularFont );
				Artist.setCharacterSize( 12 );
				Artist.setPosition( sf::Vector2f( Integral( BlockPosition.x + 8.00f ), Integral( BlockPosition.y + 115.00f + 19.00f ) ) );
				Artist.setString( FilteredTracks[i-1]->Artist );

				Album.setFont( RegularFont );
				Album.setCharacterSize( 12 );
				Album.setPosition( sf::Vector2f( Integral( BlockPosition.x + 8.00f ), Integral( BlockPosition.y + 130.00f + 19.00f ) ) );
				Album.setString( FilteredTracks[i-1]->Album );

				GenreAndYear.setFont( RegularFont );
				GenreAndYear.setCharacterSize( 12 );
				GenreAndYear.setPosition( sf::Vector2f( Integral( BlockPosition.x + 8.00f ), Integral( BlockPosition.y + 145.00f + 19.00f ) ) );
				GenreAndYear.setString( FilteredTracks[i-1]->Genre + " " + YearText );

				LenghtAndQuality.setFont( RegularFont );
				LenghtAndQuality.setCharacterSize( 12 );
				LenghtAndQuality.setPosition( sf::Vector2f( Integral( BlockPosition.x + 8.00f ), Integral( BlockPosition.y + 160.00f + 19.00f ) ) );
				LenghtAndQuality.setString( ClockStyle( FilteredTracks[i-1]->Lenght ) + ", " + QualityText + " kHz" );

				Window.draw( Cover );
				Window.draw( StarsDisabled );
				Window.draw( StarsEnabled );
				Window.draw( Title );
				Window.draw( Artist );
				Window.draw( Album );
				Window.draw( GenreAndYear );
				Window.draw( LenghtAndQuality );

				if ( FilteredTracks[i-1] == SelectedTrack ) {

					Render( Window, sf::Vector2f( BlockPosition.x + BlockSize.x - 8.00f, BlockPosition.y ), sf::Vector2f( 8.00f, BlockSize.y ), sf::Color( 50, 200, 50 ) ); }

				else if ( FilteredTracks[i-1] == HighlightedTrack ) {

					Render( Window, sf::Vector2f( BlockPosition.x + BlockSize.x - 8.00f, BlockPosition.y ), sf::Vector2f( 8.00f, BlockSize.y ), sf::Color( 100, 250, 100 ) ); }

				else {

					Render( Window, sf::Vector2f( BlockPosition.x + BlockSize.x - 8.00f, BlockPosition.y ), sf::Vector2f( 8.00f, BlockSize.y ), sf::Color( 0, 150, 250 ) ); } }
				
			else {

				if ( Mouse.x > BlockPosition.x && Mouse.x < ( BlockPosition.x + BlockSize.x ) && Mouse.y > BlockPosition.y && Mouse.y < ( BlockPosition.y + BlockSize.y ) ) {

					Render( Window, BlockPosition, BlockSize, sf::Color( 100, 250, 100 ) );
					
					EditModeEntryHighlighted = true; }

				else {

					Render( Window, BlockPosition, BlockSize, sf::Color( 0, 150, 250 ) ); }

				sf::Sprite Icon;
				sf::Text TopText;
				sf::Text BottomText;
				
				Icon.setTexture( AddIconTexture );
				Icon.setPosition( sf::Vector2f( BlockPosition.x + 12.50f, BlockPosition.y + 12.50f ) );
				Icon.setScale( 100.00f / AddIconTexture.getSize().x, 100.00f / AddIconTexture.getSize().y );

				TopText.setFont( BoldFont );
				TopText.setCharacterSize( 24 );
				TopText.setString( L"NOWA" );
				TopText.setPosition( sf::Vector2f( Integral( BlockPosition.x + ( BlockSize.x - TopText.getGlobalBounds().width ) / 2.00f ), Integral( BlockPosition.y + 127.00f ) ) );

				BottomText.setFont( BoldFont );
				BottomText.setCharacterSize( 24 );
				BottomText.setString( L"�CIE�KA" );
				BottomText.setPosition( sf::Vector2f( Integral( BlockPosition.x + ( BlockSize.x - BottomText.getGlobalBounds().width ) / 2.00f ), Integral( BlockPosition.y + 157.00f ) ) );
				
				Window.draw( Icon );
				Window.draw( TopText );
				Window.draw( BottomText ); } }

		BlockPosition.x = BlockPosition.x + BlockSize.x + Margin.x;

		if ( ( BlockPosition.x + BlockSize.x ) > ( StatusBarPosition.x + StatusBarSize.x ) ) {

			BlockPosition.x = StatusBarPosition.x + Margin.x;
			BlockPosition.y = BlockPosition.y + BlockSize.y + Margin.y; } }

	RenderSearchBar( Window ); }

void Interface::RenderTracksTabSpecialMode ( sf::RenderWindow &Window ) {
	
	sf::Vector2f HeaderBlockPosition ( StatusBarPosition.x + 15.00f, StatusBarPosition.y + StatusBarSize.y + 15.00f );
	sf::Vector2f HeaderBlockSize ( 120.00f, 30.00f );
	sf::Vector2f ValueBlockPosition ( StatusBarPosition.x + 135.00f, StatusBarPosition.y + StatusBarSize.y + 15.00f );
	sf::Vector2f ValueBlockSize ( StatusBarSize.x - 150.00f, 30.00f );
	sf::Vector2f SaveBlockPosition ( ( ValueBlockPosition.x + ValueBlockSize.x ) - 315.00f, StatusBarPosition.y + StatusBarSize.y + 330.00f );
	sf::Vector2f SaveBlockSize ( 150.00f, 30.00f );
	sf::Vector2f CloseBlockPosition ( ( ValueBlockPosition.x + ValueBlockSize.x ) - 150.00f, StatusBarPosition.y + StatusBarSize.y + 330.00f );
	sf::Vector2f CloseBlockSize ( 150.00f, 30.00f );
	sf::Vector2f StatusBlockPosition ( SearchBarPosition.x, SearchBarPosition.y );
	sf::Vector2f StatusBlockSize ( SearchBarSize.x, SearchBarSize.y );
	sf::Vector2f Mouse ( (REAL32) sf::Mouse::getPosition( Window ).x, (REAL32) sf::Mouse::getPosition( Window ).y );

	EditModeFieldHighlighted = 255;

	for ( size_t i = 0; i < 7; i++ ) {
		
		if ( Mouse.x > HeaderBlockPosition.x && Mouse.x < ( HeaderBlockPosition.x + HeaderBlockSize.x + ValueBlockSize.x ) && Mouse.y > ( HeaderBlockPosition.y ) && Mouse.y < ( HeaderBlockPosition.y + HeaderBlockSize.y ) ) {

			EditModeFieldHighlighted = i; }

		if ( i == EditModeFieldSelected ) {

			Render( Window, HeaderBlockPosition, HeaderBlockSize, sf::Color( 50, 200, 50 ) );
			Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 100, 250, 100 ) ); }

		else if ( i == EditModeFieldHighlighted ) {

			Render( Window, HeaderBlockPosition, HeaderBlockSize, sf::Color( 50, 200, 50 ) );
			Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 100, 250, 100 ) ); }

		else {

			Render( Window, HeaderBlockPosition, HeaderBlockSize, sf::Color( 0, 100, 200 ) );
			Render( Window, ValueBlockPosition, ValueBlockSize, sf::Color( 50, 150, 250 ) ); }
		
		sf::Text Header;
		sf::Text Value;

		Header.setFont( BoldFont );
		Header.setCharacterSize( 18 );
		Header.setString( EditModeHeaderText[i] );
		Header.setPosition( sf::Vector2f( Integral( HeaderBlockPosition.x + ( ( HeaderBlockSize.x - Header.getGlobalBounds().width ) / 2.00f ) ), Integral( HeaderBlockPosition.y + 4.00f ) ) );

		Value.setFont( ThinFont );
		Value.setCharacterSize( 18 );
		Value.setString( EditModeFieldText[i] );
		Value.setPosition( sf::Vector2f( Integral( ValueBlockPosition.x + 10.00f ), Integral( ValueBlockPosition.y + 4.00f ) ) );

		while ( Value.getGlobalBounds().width > ( ValueBlockSize.x - 20.00f ) ) {

			Value.setString( Value.getString().substring( 1 ) ); }

		HeaderBlockPosition.y = HeaderBlockPosition.y + 45.00f;
		ValueBlockPosition.y = ValueBlockPosition.y + 45.00f;
		
		Window.draw( Header );
		Window.draw( Value ); }

	if ( Mouse.x > SaveBlockPosition.x && Mouse.x < ( SaveBlockPosition.x + SaveBlockSize.x ) && Mouse.y > ( SaveBlockPosition.y ) && Mouse.y < ( SaveBlockPosition.y + SaveBlockSize.y ) ) {

			EditModeFieldHighlighted = 8; }

	else if ( Mouse.x > CloseBlockPosition.x && Mouse.x < ( CloseBlockPosition.x + CloseBlockSize.x ) && Mouse.y > ( CloseBlockPosition.y ) && Mouse.y < ( CloseBlockPosition.y + CloseBlockSize.y ) ) {

			EditModeFieldHighlighted = 9; }

	if ( EditModeFieldHighlighted == 8 ) {

		Render( Window, SaveBlockPosition, SaveBlockSize, sf::Color( 50, 200, 50 ) ); }

	else {

		Render( Window, SaveBlockPosition, SaveBlockSize, sf::Color( 0, 100, 200 ) ); }

	if ( EditModeFieldHighlighted == 9 ) {

		Render( Window, CloseBlockPosition, CloseBlockSize, sf::Color( 50, 200, 50 ) ); }

	else {

		Render( Window, CloseBlockPosition, CloseBlockSize, sf::Color( 0, 100, 200 ) ); }
	
	Render( Window, StatusBlockPosition, StatusBlockSize, sf::Color( 50, 150, 250 ) );
	
	sf::Text SaveBlockText;
	sf::Text CloseBlockText;
	sf::Text StatusBlockText;

	SaveBlockText.setFont( BoldFont );
	SaveBlockText.setCharacterSize( 18 );
	SaveBlockText.setString( L"Zapisz" );
	SaveBlockText.setPosition( sf::Vector2f( Integral( SaveBlockPosition.x + ( ( SaveBlockSize.x - SaveBlockText.getGlobalBounds().width ) / 2.00f ) ), Integral( SaveBlockPosition.y + 4.00f ) ) );

	CloseBlockText.setFont( BoldFont );
	CloseBlockText.setCharacterSize( 18 );
	CloseBlockText.setString( L"Zamknij" );
	CloseBlockText.setPosition( sf::Vector2f( Integral( CloseBlockPosition.x + ( ( CloseBlockSize.x - CloseBlockText.getGlobalBounds().width ) / 2.00f ) ), Integral( CloseBlockPosition.y + 4.00f ) ) );

	StatusBlockText.setFont( ThinFont );
	StatusBlockText.setCharacterSize( 18 );
	StatusBlockText.setString( "0000" );
	StatusBlockText.setPosition( sf::Vector2f( Integral( StatusBlockPosition.x + 5.00f ), Integral( StatusBlockPosition.y + ( StatusBlockSize.y - StatusBlockText.getGlobalBounds().height ) / 2.00f - 3.00f ) ) );
	StatusBlockText.setString( EditModeStatus );
	
	Window.draw( SaveBlockText );
	Window.draw( CloseBlockText );
	Window.draw( StatusBlockText ); }

void Interface::RenderSettingsTab ( sf::RenderWindow &Window ) {
	
	sf::Text TimeHeader;
	sf::Text TimeValue;
	sf::Text PlayerHeader;
	sf::Text PlayerValue [2];
	sf::Text AlgorithmHeader;
	sf::Text AlgorithmValue;
	sf::Text DirectoriesHeader;
	sf::Text DirectoriesValue [4];
	sf::Text TasksHeader;
	sf::Text TasksValue [3];

	sf::Vector2f BlockPosition [9];
	sf::Vector2f BlockSize [9];
	sf::Vector2f Mouse ( (REAL32) sf::Mouse::getPosition( Window ).x, (REAL32) sf::Mouse::getPosition( Window ).y );

	TimeHeader.setFont( RegularFont );
	TimeHeader.setCharacterSize( 18 );
	TimeHeader.setColor( sf::Color( 0, 0, 0 ) );
	TimeHeader.setString( L"Czas" );
	TimeHeader.setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 15.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 15.00f ) ) );

	TimeValue.setFont( ThinFont );
	TimeValue.setCharacterSize( 18 );
	TimeValue.setColor( sf::Color( 0, 0, 0 ) );
	TimeValue.setString( L"Wprowad� korekt� czasow� r�wn�                        sekund." );
	TimeValue.setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 45.00f ) ) );

	PlayerHeader.setFont( RegularFont );
	PlayerHeader.setCharacterSize( 18 );
	PlayerHeader.setColor( sf::Color( 0, 0, 0 ) );
	PlayerHeader.setString( L"Odtwarzacz" );
	PlayerHeader.setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 15.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 90.00f ) ) );

	PlayerValue[0].setFont( ThinFont );
	PlayerValue[0].setCharacterSize( 18 );
	PlayerValue[0].setColor( sf::Color( 50, 150, 250 ) );
	PlayerValue[0].setString( PlayerPointer->IsEnabled() && !PlayerPointer->IsMuted() ? L"Wy��cz odtwarzacz" : L"W��cz odtwarzacz" );
	PlayerValue[0].setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 120.00f ) ) );
	
	PlayerValue[1].setFont( ThinFont );
	PlayerValue[1].setCharacterSize( 18 );
	PlayerValue[1].setColor( sf::Color( 0, 0, 0 ) );
	PlayerValue[1].setString( L"Ustal g�o�no�� odtwarzacza na                        g�o�no�ci �cie�ek." );
	PlayerValue[1].setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 150.00f ) ) );

	AlgorithmHeader.setFont( RegularFont );
	AlgorithmHeader.setCharacterSize( 18 );
	AlgorithmHeader.setColor( sf::Color( 0, 0, 0 ) );
	AlgorithmHeader.setString( L"Algorytm" );
	AlgorithmHeader.setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 15.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 195.00f ) ) );

	AlgorithmValue.setFont( ThinFont );
	AlgorithmValue.setCharacterSize( 18 );
	AlgorithmValue.setColor( sf::Color( 0, 0, 0 ) );
	AlgorithmValue.setString( L"Wykonaj algorytm wybierania �cie�ek codziennie o              :             :             ." );
	AlgorithmValue.setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 225.00f ) ) );

	DirectoriesHeader.setFont( RegularFont );
	DirectoriesHeader.setCharacterSize( 18 );
	DirectoriesHeader.setColor( sf::Color( 0, 0, 0 ) );
	DirectoriesHeader.setString( L"Foldery" );
	DirectoriesHeader.setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 15.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 270.00f ) ) );

	DirectoriesValue[0].setFont( ThinFont );
	DirectoriesValue[0].setCharacterSize( 18 );
	DirectoriesValue[0].setColor( sf::Color( 0, 0, 0 ) );
	DirectoriesValue[0].setString( L"Ustal folder z danymi na                                                     ." );
	DirectoriesValue[0].setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 300.00f ) ) );

	DirectoriesValue[1].setFont( ThinFont );
	DirectoriesValue[1].setCharacterSize( 18 );
	DirectoriesValue[1].setColor( sf::Color( 0, 0, 0 ) );
	DirectoriesValue[1].setString( L"Ustal folder ze �cie�kami na                                                     ." );
	DirectoriesValue[1].setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 330.00f ) ) );

	DirectoriesValue[2].setFont( ThinFont );
	DirectoriesValue[2].setCharacterSize( 18 );
	DirectoriesValue[2].setColor( sf::Color( 0, 0, 0 ) );
	DirectoriesValue[2].setString( L"Ustal folder z ok�adkami na                                                     ." );
	DirectoriesValue[2].setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 360.00f ) ) );

	DirectoriesValue[3].setFont( ThinFont );
	DirectoriesValue[3].setCharacterSize( 18 );
	DirectoriesValue[3].setColor( sf::Color( 0, 0, 0 ) );
	DirectoriesValue[3].setString( L"Ustal folder z grafik� na                                                     ." );
	DirectoriesValue[3].setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 390.00f ) ) );

	TasksHeader.setFont( RegularFont );
	TasksHeader.setCharacterSize( 18 );
	TasksHeader.setColor( sf::Color( 0, 0, 0 ) );
	TasksHeader.setString( L"Zadania" );
	TasksHeader.setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 15.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 435.00f ) ) );

	TasksValue[0].setFont( ThinFont );
	TasksValue[0].setCharacterSize( 18 );
	TasksValue[0].setColor( sf::Color( 50, 150, 250 ) );
	TasksValue[0].setString( L"Wyczy�� playlist� ( przyspiesza dzia�anie programu )" );
	TasksValue[0].setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 465.00f ) ) );

	TasksValue[1].setFont( ThinFont );
	TasksValue[1].setCharacterSize( 18 );
	TasksValue[1].setColor( sf::Color( 50, 150, 250 ) );
	TasksValue[1].setString( L"Przywr�� ustawienia domy�lne" );
	TasksValue[1].setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 495.00f ) ) );

	TasksValue[2].setFont( ThinFont );
	TasksValue[2].setCharacterSize( 18 );
	TasksValue[2].setColor( sf::Color( 50, 150, 250 ) );
	TasksValue[2].setString( L"Zapisz ustawienia" );
	TasksValue[2].setPosition( sf::Vector2f( Integral( StatusBarPosition.x + 20.00f ), Integral( StatusBarPosition.y + StatusBarSize.y + 525.00f ) ) );

	BlockPosition[0] = sf::Vector2f( Integral( StatusBarPosition.x + TimeValue.getGlobalBounds().width * 0.701f ), Integral( StatusBarPosition.y + StatusBarSize.y + 46.00f ) );
	BlockPosition[1] = sf::Vector2f( Integral( StatusBarPosition.x + PlayerValue[1].getGlobalBounds().width * 0.563f ), Integral( StatusBarPosition.y + StatusBarSize.y + 151.00f ) );
	BlockPosition[2] = sf::Vector2f( Integral( StatusBarPosition.x + AlgorithmValue.getGlobalBounds().width * 0.748f ), Integral( StatusBarPosition.y + StatusBarSize.y + 226.00f ) );
	BlockPosition[3] = sf::Vector2f( Integral( StatusBarPosition.x + AlgorithmValue.getGlobalBounds().width * 0.847f ), Integral( StatusBarPosition.y + StatusBarSize.y + 226.00f ) );
	BlockPosition[4] = sf::Vector2f( Integral( StatusBarPosition.x + AlgorithmValue.getGlobalBounds().width * 0.945f ), Integral( StatusBarPosition.y + StatusBarSize.y + 226.00f ) );
	BlockPosition[5] = sf::Vector2f( Integral( StatusBarPosition.x + AlgorithmValue.getGlobalBounds().width * 0.376f ), Integral( StatusBarPosition.y + StatusBarSize.y + 300.00f ) );
	BlockPosition[6] = sf::Vector2f( Integral( StatusBarPosition.x + AlgorithmValue.getGlobalBounds().width * 0.432f ), Integral( StatusBarPosition.y + StatusBarSize.y + 330.00f ) );
	BlockPosition[7] = sf::Vector2f( Integral( StatusBarPosition.x + AlgorithmValue.getGlobalBounds().width * 0.415f ), Integral( StatusBarPosition.y + StatusBarSize.y + 360.00f ) );
	BlockPosition[8] = sf::Vector2f( Integral( StatusBarPosition.x + AlgorithmValue.getGlobalBounds().width * 0.369f ), Integral( StatusBarPosition.y + StatusBarSize.y + 390.00f ) );

	BlockSize[0] = sf::Vector2f( 81, 22 );
	BlockSize[1] = sf::Vector2f( 81, 22 );
	BlockSize[2] = sf::Vector2f( 41, 22 );
	BlockSize[3] = sf::Vector2f( 41, 22 );
	BlockSize[4] = sf::Vector2f( 41, 22 );
	BlockSize[5] = sf::Vector2f( 198, 22 );
	BlockSize[6] = sf::Vector2f( 198, 22 );
	BlockSize[7] = sf::Vector2f( 198, 22 );
	BlockSize[8] = sf::Vector2f( 198, 22 );

	SettingsFieldHighlighted = 255;

	for ( size_t i = 0; i < 9; i++ ) {

		if ( Mouse.x >= BlockPosition[i].x && Mouse.x <= ( BlockPosition[i].x + BlockSize[i].x ) && Mouse.y >= BlockPosition[i].y && Mouse.y <= ( BlockPosition[i].y + BlockSize[i].y ) ) {

			SettingsFieldHighlighted = i; }

		if ( i == SettingsFieldSelected ) {

			Render( Window, BlockPosition[i], BlockSize[i], sf::Color( 100, 250, 100 ) ); }

		else if ( i == SettingsFieldHighlighted ) {

			Render( Window, BlockPosition[i], BlockSize[i], sf::Color( 100, 250, 100 ) ); }

		else {

			Render( Window, BlockPosition[i], BlockSize[i], sf::Color( 50, 150, 250 ) ); }
		
		sf::Text BlockText;

		BlockText.setFont( ThinFont );
		BlockText.setCharacterSize( 18 );
		BlockText.setColor( sf::Color( 255, 255, 255 ) );
		BlockText.setString( i == 1 ? SettingsFieldText[i] + " %" : SettingsFieldText[i] );
		BlockText.setPosition( sf::Vector2f( Integral( BlockPosition[i].x + 5.00f ), Integral( BlockPosition[i].y ) ) );
		
		if ( BlockText.getGlobalBounds().width <= ( BlockSize[i].x - 10.00f ) ) {

			BlockText.setPosition( sf::Vector2f( Integral( BlockPosition[i].x + ( BlockSize[i].x - BlockText.getGlobalBounds().width ) / 2.00f ), Integral( BlockPosition[i].y ) ) ); }

		while ( BlockText.getGlobalBounds().width > ( BlockSize[i].x - 10.00f ) ) {

			BlockText.setString( BlockText.getString().substring( 1, BlockText.getString().getSize() - 1 ) ); }

		Window.draw( BlockText ); }

	if ( Mouse.x >= PlayerValue[0].getGlobalBounds().left && Mouse.x <= ( PlayerValue[0].getGlobalBounds().left + PlayerValue[0].getGlobalBounds().width ) && Mouse.y >= PlayerValue[0].getGlobalBounds().top && Mouse.y <= ( PlayerValue[0].getGlobalBounds().top + PlayerValue[0].getGlobalBounds().height ) ) {

		PlayerValue[0].setColor( sf::Color( 100, 250, 100 ) );

		SettingsFieldHighlighted = 10; }

	if ( Mouse.x >= TasksValue[0].getGlobalBounds().left && Mouse.x <= ( TasksValue[0].getGlobalBounds().left + TasksValue[0].getGlobalBounds().width ) && Mouse.y >= TasksValue[0].getGlobalBounds().top && Mouse.y <= ( TasksValue[0].getGlobalBounds().top + TasksValue[0].getGlobalBounds().height ) ) {

		TasksValue[0].setColor( sf::Color( 100, 250, 100 ) );

		SettingsFieldHighlighted = 11; }

	if ( Mouse.x >= TasksValue[1].getGlobalBounds().left && Mouse.x <= ( TasksValue[1].getGlobalBounds().left + TasksValue[1].getGlobalBounds().width ) && Mouse.y >= TasksValue[1].getGlobalBounds().top && Mouse.y <= ( TasksValue[1].getGlobalBounds().top + TasksValue[1].getGlobalBounds().height ) ) {

		TasksValue[1].setColor( sf::Color( 100, 250, 100 ) );

		SettingsFieldHighlighted = 12; }

	if ( Mouse.x >= TasksValue[2].getGlobalBounds().left && Mouse.x <= ( TasksValue[2].getGlobalBounds().left + TasksValue[2].getGlobalBounds().width ) && Mouse.y >= TasksValue[2].getGlobalBounds().top && Mouse.y <= ( TasksValue[2].getGlobalBounds().top + TasksValue[2].getGlobalBounds().height ) ) {

		TasksValue[2].setColor( sf::Color( 100, 250, 100 ) );

		SettingsFieldHighlighted = 13; }

	Window.draw( TimeHeader );
	Window.draw( TimeValue );
	Window.draw( PlayerHeader );
	Window.draw( PlayerValue[0] );
	Window.draw( PlayerValue[1] );
	Window.draw( AlgorithmHeader );
	Window.draw( AlgorithmValue );
	Window.draw( DirectoriesHeader );
	Window.draw( DirectoriesValue[0] );
	Window.draw( DirectoriesValue[1] );
	Window.draw( DirectoriesValue[2] );
	Window.draw( DirectoriesValue[3] );
	Window.draw( TasksHeader );
	Window.draw( TasksValue[0] );
	Window.draw( TasksValue[1] );
	Window.draw( TasksValue[2] ); }

void Interface::RenderWebTab ( sf::RenderWindow &Window ) {

	}

void Interface::RenderTabsBar ( sf::RenderWindow &Window ) {

	Render( Window, TabsBarPosition, TabsBarSize, sf::Color( 0, 100, 200 ) );

	if ( PlaylistIconSprite.getTexture() != NULL ) {
		
		Window.draw( PlaylistIconSprite ); }

	if ( TracksIconSprite.getTexture() != NULL ) {
		
		Window.draw( TracksIconSprite ); }

	if ( SettingsIconSprite.getTexture() != NULL ) {
		
		Window.draw( SettingsIconSprite ); }

	if ( WebIconSprite.getTexture() != NULL ) {
		
		Window.draw( WebIconSprite ); } }

void Interface::RenderStatusBar ( sf::RenderWindow &Window ) {

	Render( Window, StatusBarPosition, StatusBarSize, sf::Color( 50, 150, 250 ) );

	if ( StatusSprite.getFont() != NULL ) {

		StatusSprite.setString( "" );

		if ( StatusOnline && StatusOnAir ) {

			StatusSprite.setString( "online on-air" ); }

		else if ( StatusOnline && !StatusOnAir ) {

			StatusSprite.setString( "online off-air" ); }

		else if ( !StatusOnline && StatusOnAir ) {

			StatusSprite.setString( "offline on-air" ); }

		else {

			StatusSprite.setString( "offline off-air" ); }

		Window.draw( StatusSprite ); }

	if ( TimeSprite.getFont() != NULL ) {

		std::string Hours = "0" + GetTime( Time::Hours );
		std::string Minutes = "0" + GetTime( Time::Minutes );
		std::string Seconds = "0" + GetTime( Time::Seconds );

		Hours = Hours.substr( Hours.size() - 2 );
		Minutes = Minutes.substr( Minutes.size() - 2 );
		Seconds = Seconds.substr( Seconds.size() - 2 );

		TimeSprite.setString( Hours + " : " + Minutes + " : " + Seconds );
		
		Window.draw( TimeSprite ); }

	if ( DateSprite.getFont() != NULL ) {

		UINT64 Month = 0;
		std::string Day = "0" + GetTime( Time::Day );
		std::string Year = GetTime( Time::Year );

		Day = Day.substr( Day.size() - 2 );
		Convert( GetTime( Time::Month ), Month );

		DateSprite.setString( Day + " " + Months[ Month - 1 ] + " " + Year );
		DateSprite.setPosition( Integral( ( StatusBarPosition.x + StatusBarSize.x ) - ( DateSprite.getGlobalBounds().width + 5.00f ) ), DateSprite.getPosition().y );

		Window.draw( DateSprite ); } }

void Interface::RenderNavigationBar ( sf::RenderWindow &Window ) {

	if ( !NavigationError ) {

		Render( Window, NavigationBarPosition, NavigationBarSize, sf::Color( 50, 150, 250 ) ); }

	else {

		Render( Window, NavigationBarPosition, NavigationBarSize, sf::Color( 250, 150, 50 ) ); }
	
	sf::Sprite PerviousIcon;
	sf::Sprite GoIcon;
	sf::Sprite NextIcon;
	sf::Sprite TrackingIcon;
	sf::Vector2f Mouse ( (REAL32) sf::Mouse::getPosition( Window ).x, (REAL32) sf::Mouse::getPosition( Window ).y );

	NavigationIconSelected = 255;

	if ( Mouse.x >= ( NavigationBarPosition.x + NavigationBarSize.x - 150.00f ) && Mouse.x <= ( NavigationBarPosition.x + NavigationBarSize.x - 120.00f ) && Mouse.y >= NavigationBarPosition.y && Mouse.y <= ( NavigationBarPosition.y + 30.00f ) ) {

		NavigationIconSelected = 0; }

	else if ( Mouse.x >= ( NavigationBarPosition.x + NavigationBarSize.x - 120.00f ) && Mouse.x <= ( NavigationBarPosition.x + NavigationBarSize.x - 90.00f ) && Mouse.y >= NavigationBarPosition.y && Mouse.y <= ( NavigationBarPosition.y + 30.00f ) ) {

		NavigationIconSelected = 1; }

	else if ( Mouse.x >= ( NavigationBarPosition.x + NavigationBarSize.x - 90.00f ) && Mouse.x <= ( NavigationBarPosition.x + NavigationBarSize.x - 60.00f ) && Mouse.y >= NavigationBarPosition.y && Mouse.y <= ( NavigationBarPosition.y + 30.00f ) ) {

		NavigationIconSelected = 2; }

	else if ( Mouse.x >= ( NavigationBarPosition.x + NavigationBarSize.x - 45.00f ) && Mouse.x <= ( NavigationBarPosition.x + NavigationBarSize.x - 15.00f ) && Mouse.y >= NavigationBarPosition.y && Mouse.y <= ( NavigationBarPosition.y + 30.00f ) ) {

		NavigationIconSelected = 3; }

	PerviousIcon.setTexture( PerviousIconTexture );
	PerviousIcon.setColor( NavigationIconSelected == 0 ? sf::Color( 255, 255, 255 ) : ( !NavigationError ? sf::Color( 0, 100, 200 ) : sf::Color( 200, 100, 0 ) ) );
	PerviousIcon.setPosition( sf::Vector2f( NavigationBarPosition.x + NavigationBarSize.x - 150.00f, NavigationBarPosition.y ) );
	PerviousIcon.setScale( 30.00f / PerviousIconTexture.getSize().x, 30.00f / PerviousIconTexture.getSize().y );

	GoIcon.setTexture( GoIconTexture );
	GoIcon.setColor( NavigationIconSelected == 1 ? sf::Color( 255, 255, 255 ) : ( !NavigationError ? sf::Color( 0, 100, 200 ) : sf::Color( 200, 100, 0 ) ) );
	GoIcon.setPosition( sf::Vector2f( NavigationBarPosition.x + NavigationBarSize.x - 120.00f, NavigationBarPosition.y ) );
	GoIcon.setScale( 30.00f / GoIconTexture.getSize().x, 30.00f / GoIconTexture.getSize().y );

	NextIcon.setTexture( NextIconTexture );
	NextIcon.setColor( NavigationIconSelected == 2 ? sf::Color( 255, 255, 255 ) : ( !NavigationError ? sf::Color( 0, 100, 200 ) : sf::Color( 200, 100, 0 ) ) );
	NextIcon.setPosition( sf::Vector2f( NavigationBarPosition.x + NavigationBarSize.x - 90.00f, NavigationBarPosition.y ) );
	NextIcon.setScale( 30.00f / NextIconTexture.getSize().x, 30.00f / NextIconTexture.getSize().y );

	TrackingIcon.setTexture( TrackingIconTexture );
	TrackingIcon.setColor( TimelinePointer->GetTracking() ? sf::Color( 255, 255, 255 ) : ( !NavigationError ? sf::Color( 0, 100, 200 ) : sf::Color( 200, 100, 0 ) ) );
	TrackingIcon.setPosition( sf::Vector2f( NavigationBarPosition.x + NavigationBarSize.x - 45.00f, NavigationBarPosition.y ) );
	TrackingIcon.setScale( 30.00f / TrackingIconTexture.getSize().x, 30.00f / TrackingIconTexture.getSize().y );

	NavigationSprite.setString( TimelineScope );

	while ( NavigationSprite.getGlobalBounds().width > ( NavigationBarSize.x / 2.00f ) ) {

		NavigationSprite.setString( NavigationSprite.getString().substring( 1 ) ); }

	Window.draw( NavigationSprite );
	Window.draw( PerviousIcon );
	Window.draw( GoIcon );
	Window.draw( NextIcon );
	Window.draw( TrackingIcon ); }

void Interface::RenderSearchBar ( sf::RenderWindow &Window ) {

	Render( Window, SearchBarPosition, SearchBarSize, sf::Color( 50, 150, 250 ) );
	
	if ( SearchSprite.getFont() != NULL ) {
		
		sf::String OriginalString = SearchSprite.getString();
		
		if ( SearchSprite.getString() != "" ) {
			
			while ( SearchSprite.getGlobalBounds().width > ( SearchBarSize.x / 2.00f ) ) {

				SearchSprite.setString( SearchSprite.getString().substring( 1 ) ); }
			
			Window.draw( SearchSprite ); }
		
		else {
			
			SearchSprite.setString( L"U�yj klawiatury, aby wyszuka�..." );
			
			Window.draw( SearchSprite ); }
		
		SearchSprite.setString( OriginalString ); }
		
	if ( TracksCountSprite.getFont() != NULL ) {

		std::string TracksCount;
		Convert( FilteredTracks.size(), TracksCount );

		if ( FilteredTracks.size() == 1 ) {

			TracksCountSprite.setString( sf::String( TracksCount ) + sf::String( L" �cie�ka" ) ); }

		else if ( FilteredTracks.size() % 10 >= 2 && FilteredTracks.size() % 10 <= 4 ) {

			TracksCountSprite.setString( sf::String( TracksCount ) + sf::String( L" �cie�ki" ) ); }

		else {

			TracksCountSprite.setString( sf::String( TracksCount ) + sf::String( L" �cie�ek" ) ); }
		
		TracksCountSprite.setPosition( Integral( ( SearchBarPosition.x + SearchBarSize.x ) - ( TracksCountSprite.getGlobalBounds().width + 5.00f ) ), TracksCountSprite.getPosition().y );

		Window.draw( TracksCountSprite ); } }

void Interface::RecalculateLayout ( ) {

	sf::String StatusOriginalString = StatusSprite.getString();
	sf::String DateOriginalString = DateSprite.getString();
	sf::String SearchOriginalString = SearchSprite.getString();
	sf::String TrackCountOriginalString = TracksCountSprite.getString();
	sf::String TimeOriginalString = TimeSprite.getString();

	StatusSprite.setString( "0000" );
	TimeSprite.setString( "00 : 00 : 00" );
	DateSprite.setString( "0000" );
	NavigationSprite.setString( "0000" );
	SearchSprite.setString( "0000" );
	TracksCountSprite.setString( "0000" );

	TabsBarPosition.x = 0.00f;
	TabsBarPosition.y = 0.00f;

	TabsBarSize.x = 100.00f;
	TabsBarSize.y = Size.y;

	StatusBarPosition.x = 100.00f;
	StatusBarPosition.y = 0.00f;

	StatusBarSize.x = Size.x - 100.00f;
	StatusBarSize.y = 30.00f;
	
	NavigationBarPosition.x = StatusBarPosition.x;
	NavigationBarPosition.y = TabsBarSize.y * 0.70f;

	NavigationBarSize.x = StatusBarSize.x;
	NavigationBarSize.y = 30.00f;

	SearchBarPosition.x = 100.00f;
	SearchBarPosition.y = Size.y - 30.00f;

	SearchBarSize.x = Size.x - 100.00f;
	SearchBarSize.y = 30.00f;

	StatusSprite.setPosition( Integral( StatusBarPosition.x + 5.00f ), Integral( StatusBarPosition.y + ( StatusBarSize.y - StatusSprite.getGlobalBounds().height ) / 2.00f - 3.00f ) );
	TimeSprite.setPosition( Integral( ( StatusBarPosition.x + StatusBarSize.x / 2.00f ) - ( TimeSprite.getGlobalBounds().width / 2.00f ) ), Integral( StatusBarPosition.y + ( StatusBarSize.y - TimeSprite.getGlobalBounds().height ) / 2.00f - 3.00f ) );
	DateSprite.setPosition( Integral( ( StatusBarPosition.x + StatusBarSize.x ) - ( DateSprite.getGlobalBounds().width + 5.00f ) ), Integral( StatusBarPosition.y + ( StatusBarSize.y - DateSprite.getGlobalBounds().height ) / 2.00f - 3.00f ) );
	SearchSprite.setPosition( Integral( SearchBarPosition.x + 5.00f ), Integral( SearchBarPosition.y + ( SearchBarSize.y - SearchSprite.getGlobalBounds().height ) / 2.00f - 3.00f ) );
	TracksCountSprite.setPosition( Integral( ( SearchBarPosition.x + SearchBarSize.x ) - ( TracksCountSprite.getGlobalBounds().width + 5.00f ) ), Integral( SearchBarPosition.y + ( SearchBarSize.y - TracksCountSprite.getGlobalBounds().height ) / 2.00f - 3.00f ) );

	PlaylistIconSprite.setPosition( 5.00f, ( ( TabsBarSize.y - 360.00f ) / 2.00f ) + 0.00f );
	TracksIconSprite.setPosition( 5.00f, ( ( TabsBarSize.y - 360.00f ) / 2.00f ) + 90.00f );
	SettingsIconSprite.setPosition( 5.00f, ( ( TabsBarSize.y - 360.00f ) / 2.00f ) + 180.00f );
	WebIconSprite.setPosition( 5.00f, ( ( TabsBarSize.y - 360.00f ) / 2.00f ) + 270.00f );

	StatusSprite.setString( StatusOriginalString );
	TimeSprite.setString( TimeOriginalString );
	DateSprite.setString( DateOriginalString );
	NavigationSprite.setPosition( sf::Vector2f( Integral( NavigationBarPosition.x + 5.00f ), Integral( NavigationBarPosition.y + ( NavigationBarSize.y - NavigationSprite.getGlobalBounds().height ) / 2.00f - 2.00f ) ) );
	SearchSprite.setString( SearchOriginalString );
	TracksCountSprite.setString( TrackCountOriginalString ); }

REAL32 Interface::Integral ( REAL32 Value ) {

	REAL32 Result;

	modf( Value, &Result );

	return Result; }

std::string Interface::ClockStyle ( UINT64 Time ) {

    if ( Time >= 3600 ) {

		std::string Hours;
		std::string Minutes;
		std::string Seconds;
		
		Convert( Time / 3600, Hours );
		Convert( ( Time % 3600 ) / 60, Minutes );
		Convert( Time % 60, Seconds );
		
		Hours = "0" + Hours;
		Minutes = "0" + Minutes;
		Seconds = "0" + Seconds;

		Hours = Hours.substr( Hours.size() - 2 );
		Minutes = Minutes.substr( Minutes.size() - 2 );
		Seconds = Seconds.substr( Seconds.size() - 2 );

		return ( Hours + ":" + Minutes + ":" + Seconds ); }

	else {

		std::string Seconds;
		std::string Minutes;

		Convert( Time / 60, Minutes );
		Convert( Time % 60, Seconds );

		Minutes = "0" + Minutes;
		Seconds = "0" + Seconds;

		Minutes = Minutes.substr( Minutes.size() - 2 );
		Seconds = Seconds.substr( Seconds.size() - 2 );

		return ( Minutes + ":" + Seconds ); } }

std::string Interface::DateStyle ( UINT64 Time ) {

	std::string Buffer;
	std::string Result;

	struct tm * TimeStructure = new struct tm;
	time_t TimeHandle = Time;

	localtime_s( TimeStructure, &TimeHandle );

	Convert( TimeStructure->tm_hour, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + ":";

	Convert( TimeStructure->tm_min, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + ":";

	Convert( TimeStructure->tm_sec, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + " ";

	Convert( TimeStructure->tm_mday, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + ".";

	Convert( TimeStructure->tm_mon + 1, Buffer );
	Result = Result + ( "0" + Buffer ).substr( Buffer.size() - 1 ) + ".";

	Convert( TimeStructure->tm_year + 1900, Buffer );
	Result = Result + Buffer;

	delete TimeStructure;

	return Result; }

void Interface::Convert ( UINT64 Value, std::string &Text ) {

	Text.clear();

	do {

		Text = (char) ( Value % 10 + 48 ) + Text;
		Value = Value / 10; }

	while ( Value != 0 ); }

bool Interface::Convert ( std::string Text, UINT64 &Value ) {

	Value = 0;

	if ( Text.size() == 0 ) {

		return false; }

	for ( size_t i = 0; i < Text.size(); i++ ) {

		if ( Text[i] >= 48 && Text[i] <= 57 ) {

			Value = Value * 10;
			Value = Value + ( Text[i] - 48 ); }

		else {

			return false; } }

	return true; }

bool Interface::ConvertDate ( std::string Text, UINT64 &Value ) {

	std::string DateBuffer;
	std::vector <UINT64> Date;
	
	UINT64 MonthLength [12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	
	Text = Text + " ";

	for ( size_t i = 0; i < Text.size(); i++ ) {

		if ( Text[i] != ' ' && Text[i] != ':' && Text[i] != '.' ) {

			DateBuffer = DateBuffer + Text[i]; }

		else {

			UINT64 Number;

			if ( !Convert( DateBuffer, Number ) ) {

				return false; }

			DateBuffer.clear();
			Date.push_back( Number ); } }
	
	if ( Date.size() != 6 ) {

		return false; }
	
	if ( Date[5] < 1970 || Date[5] > 10000 || Date[4] == 0 || Date[4] > 12 ) {

        return false; }

    if ( Date[5] % 400 == 0 || ( Date[5] % 100 != 0 && Date[5] % 4 == 0 ) ) {

        MonthLength[1] = 29; }
              
    if ( Date[3] > MonthLength[ Date[4] - 1 ] ) {
               
        return false; }

	if ( Date[0] > 23 || Date[1] > 59 || Date[2] > 59 ) {

		return false; }

	struct tm * TimeStructure = new struct tm;

	TimeStructure->tm_hour = (int) Date[0];
	TimeStructure->tm_min = (int) Date[1];
	TimeStructure->tm_sec = (int) Date[2];
	TimeStructure->tm_mday = (int) Date[3];
	TimeStructure->tm_mon = (int) Date[4] - 1;
	TimeStructure->tm_year = (int) Date[5] - 1900;
	TimeStructure->tm_isdst = -1;

	Value = (UINT64) mktime( TimeStructure );
	
	delete TimeStructure;

	return true; }

bool Interface::ConvertTime ( std::string Text, UINT64 &ValueBegin, UINT64 &ValueLength ) {

	std::string TimeLeft;
	std::string TimeRight;
	std::string TimeBuffer;
	std::vector <UINT64> TimeBegin;
	std::vector <UINT64> TimeEnd;

	size_t Dash = Text.find( "-" );

	if ( Dash == std::string::npos ) {

		return false; }
	
	TimeLeft = Text.substr( 0, Dash );
	TimeRight = Text.substr( Dash + 1 );
	
	for ( size_t i = 0; i < TimeLeft.size(); i++ ) {

		if ( TimeLeft[i] != ':' && TimeLeft[i] != ' ' ) {

			TimeBuffer = TimeBuffer + TimeLeft[i]; }

		else {

			UINT64 Number;
			
			if ( !Convert( TimeBuffer, Number ) ) {
				
				return false; }

			TimeBuffer.clear();
			TimeBegin.push_back( Number ); } }
	
	if ( TimeBegin.size() != 2 && TimeBegin.size() != 3 ) {

		return false; }
	
	if ( TimeRight.size() > 0 ) {

		if ( TimeRight[0] != ' ' ) {

			return false; }

		TimeRight = ( TimeRight + " " ).substr( 1 ); }

	for ( size_t i = 0; i < TimeRight.size(); i++ ) {

		if ( TimeRight[i] != ':' && TimeRight[i] != ' ' ) {

			TimeBuffer = TimeBuffer + TimeRight[i]; }

		else {

			UINT64 Number;

			if ( !Convert( TimeBuffer, Number ) ) {

				return false; }

			TimeBuffer.clear();
			TimeEnd.push_back( Number ); } }
	
	if ( TimeEnd.size() != 2 && TimeEnd.size() != 3 ) {

		return false; }

	if ( TimeBegin.size() != TimeEnd.size() ) {

		return false; }

	if ( TimeBegin.size() == 2 ) {

		if ( TimeBegin[0] > TimeEnd[0] ) {

			return false; }

		if ( TimeBegin[0] == TimeEnd[0] && TimeBegin[1] >= TimeEnd[1] ) {

			return false; }

		if ( TimeBegin[0] > 59 || TimeBegin[1] > 59 || TimeEnd[0] > 59 || TimeEnd[1] > 59 ) {

			return false; }
		
		ValueBegin = TimeBegin[0] * 60 + TimeBegin[1];
		ValueLength = TimeEnd[0] * 60 + TimeEnd[1] - ValueBegin; }

	if ( TimeBegin.size() == 3 ) {

		if ( TimeBegin[0] > TimeEnd[0] ) {

			return false; }

		if ( TimeBegin[0] == TimeEnd[0] && TimeBegin[1] > TimeEnd[1] ) {

			return false; }

		if ( TimeBegin[0] == TimeEnd[0] && TimeBegin[1] == TimeEnd[1] && TimeBegin[2] >= TimeEnd[2] ) {

			return false; }

		if ( TimeBegin[1] > 59 || TimeBegin[2] > 59 || TimeEnd[1] > 59 || TimeEnd[2] > 59 ) {

			return false; }
		
		ValueBegin = TimeBegin[0] * 3600 + TimeBegin[1] * 60 + TimeBegin[2];
		ValueLength = TimeEnd[0] * 3600 + TimeEnd[1] + TimeBegin[2] - ValueBegin; }
	
	return true; }