#ifndef RADIO_GILA_TRACKS
#define RADIO_GILA_TRACKS

#include "Config.hpp"
#include "Mutex.hpp"
#include "Settings.hpp"

struct Track {

	std::string Title;
	std::string Artist;
	std::string Album;
	std::string Genre;
	UINT64 Year;
	UINT64 Lenght;
	UINT64 Quality;
	UINT64 Rate;
	UINT64 Playcount;
	bool IsPlaylist;
	std::string TrackPath;
	std::string CoverPath;
	
	sf::Texture Cover;
	std::string DataPath;

	};

class Tracks {
		
	public:

		Tracks ( Settings * SettingsPointer );

		Track * operator [] ( size_t i ) {

			return &List[i]; }

		size_t GetSize ( );

		bool Reload ( );
		bool Create ( Track Data );

		std::vector <Track*> Search ( std::string Filter = "" );
		Track * Search ( std::string Title, std::string Artist, std::string Album );

		void SetTimestamp ( UINT64 Timestamp );
		UINT64 GetTimestamp ( );

	private:

		std::string ToUpper ( std::string Text );
		std::string ToLower ( std::string Text );

		void Convert ( UINT64 Value, std::string &Text );
		bool Convert ( std::string Text, UINT64 &Value );

	private:

		Settings * SettingsPointer;

		sf::Texture DefaultCover;
		std::vector <Track> List;

	};

#endif