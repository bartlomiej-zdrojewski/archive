#ifndef RADIO_GILA_SETTINGS
#define RADIO_GILA_SETTINGS

#include "Config.hpp"

class Settings {
	
	public:

		enum NumericParameter {
			
			AlgorithmActivationHour,
			AlgorithmActivationMinute,
			AlgorithmActivationSecond,

			PlayerMuted,
			PlayerVolume,

			ServerRefresh,
			ServerTimeout,
			ServerSynchronization,

			AlgorithmTimestamp,
			PlaylistTimestamp,
			TracksTimestamp,
			SettingsTimestamp,

			TimeCorrection,

			NumericParametersCount

			};

		enum TextParameter {

			DataPath,
			TracksPath,
			CoversPath,
			GraphicsPath,

			ServerURL,

			TextParametersCount

			};

	public:

		Settings ( );

		UINT64 GetTime ( );

		void SetNumericParameter ( NumericParameter Parameter, UINT64 Value );
		UINT64 GetNumericParameter ( NumericParameter Parameter );

		void SetTextParameter ( TextParameter Parameter, std::string Value );
		std::string GetTextParameter ( TextParameter Parameter );

		bool SaveToFile ( std::string FilePath );
		bool LoadFromFile ( std::string FilePath );

	private:

		std::vector <UINT64> NumericParameters;
		std::vector <std::string> TextParameters;

	};

#endif